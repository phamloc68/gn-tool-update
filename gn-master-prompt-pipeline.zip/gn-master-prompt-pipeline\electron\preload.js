// Minimal preload. The UI talks to the local API over HTTP; here we expose a
// tiny, safe surface plus the one-click updater.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('gnDesktop', {
  isDesktop: true,
  platform: process.platform,
  update: (opts) => ipcRenderer.invoke('app-update', opts || {}),
});
