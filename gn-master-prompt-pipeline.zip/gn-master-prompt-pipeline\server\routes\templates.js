// Template CRUD — each template has 4 explicit prompts.
const express = require('express');
const { templates } = require('../db');
const router = express.Router();

router.get('/', (req, res) => res.json(templates.all()));

router.get('/:id', (req, res) => {
  const t = templates.get(req.params.id);
  if (!t) return res.status(404).json({ error: 'Template not found' });
  res.json(t);
});

router.post('/', (req, res) => {
  const b = req.body || {};
  if (!b.name || !b.name.trim())
    return res.status(400).json({ error: 'Cần nhập tên mẫu (Template Name).' });
  res.status(201).json(
    templates.create({
      name: b.name.trim(),
      niche: b.niche,
      title_prompt: b.title_prompt,
      content_prompt: b.content_prompt,
      visual_prompt: b.visual_prompt,
      thumbnail_prompt: b.thumbnail_prompt,
    })
  );
});

router.put('/:id', (req, res) => {
  const updated = templates.update(req.params.id, req.body || {});
  if (!updated) return res.status(404).json({ error: 'Template not found' });
  res.json(updated);
});

router.delete('/:id', (req, res) => {
  templates.remove(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
