import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './index.css';

// Catch render errors so a crash shows a readable message instead of a blank page.
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    // eslint-disable-next-line no-console
    console.error('UI error:', error, info);
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{ padding: 24, fontFamily: 'system-ui, sans-serif', color: '#1f2937' }}>
          <h2 style={{ color: '#b91c1c' }}>Giao diện gặp lỗi</h2>
          <p>Vui lòng chụp màn hình này gửi để được hỗ trợ.</p>
          <pre style={{ whiteSpace: 'pre-wrap', background: '#f1f5f9', padding: 12, borderRadius: 8, fontSize: 12 }}>
            {String(this.state.error && (this.state.error.stack || this.state.error.message || this.state.error))}
          </pre>
          <button
            onClick={() => location.reload()}
            style={{ marginTop: 12, padding: '8px 16px', background: '#4f46e5', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer' }}
          >
            Tải lại
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// Surface unexpected runtime errors visibly too.
window.addEventListener('error', (e) => {
  const root = document.getElementById('root');
  if (root && !root.firstChild) {
    root.innerHTML =
      '<div style="padding:24px;font-family:sans-serif;color:#b91c1c"><h2>Lỗi tải ứng dụng</h2><pre style="white-space:pre-wrap;color:#1f2937;background:#f1f5f9;padding:12px;border-radius:8px">' +
      String(e.message || e) +
      '</pre></div>';
  }
});

ReactDOM.createRoot(document.getElementById('root')).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
