# Building the Windows app (.exe) — for the admin / IT, once

Goal: a clickable application so staff **just double-click an icon** and the tool
opens in its own window — no terminal, no `npm`, no browser.

You do this **once** (and again when the code changes). Staff never see any of this.

## What you need (build machine)
- A **Windows 10/11 PC**
- **Node.js 18 or newer** — https://nodejs.org (pick the "LTS" installer)

> No Visual Studio, no build tools, no admin rights required. The app has **no
> native modules** (SQLite runs as pure JS/WASM) and the packager does **not**
> code-sign, so the build is clean and simple.

## Easiest way: double-click the build script
1. Unzip this project somewhere (e.g. `C:\gn-pipeline`).
2. Double-click **`build-exe.bat`**.
3. Wait a few minutes (it downloads Electron the first time).

When it finishes, your app is in:
```
release\GN Master Prompt Pipeline-win32-x64\
```
Inside that folder is the program:
```
GN Master Prompt Pipeline.exe   <-- double-click to run
```

**Easy access:** `build-exe.bat` automatically puts a shortcut named
**"GN Master Prompt Pipeline"** on your **Desktop** — just double-click that.
(If you ever need to recreate it, run **`make-desktop-shortcut.bat`**.)

## Give it to staff
The app is the **whole folder** `GN Master Prompt Pipeline-win32-x64` (the `.exe`
needs the files next to it). Two easy options:

- **Zip & share:** ZIP that folder, send it. Staff unzip anywhere and double-click
  `GN Master Prompt Pipeline.exe`. Nothing to install.
- **Shared drive:** copy the folder to a network/shared drive; staff run the `.exe`
  from there or make a desktop shortcut to it.

> Want a true single-file installer with a Start-menu shortcut instead? See
> "Optional: installer" below.

## Manual way (equivalent to the .bat)
```bat
npm install
npm --prefix client install
npm --prefix client run build
npx electron-packager . "GN Master Prompt Pipeline" --platform=win32 --arch=x64 --out=release --overwrite --prune=true --ignore="/client/node_modules" --ignore="/client/src" --ignore="^/release"
```

## First run: add the API key
When the app opens, click **Settings** (top-right) and paste the **Claude** and/or
**Gemini** API key, then Save. The key is stored locally on that PC (in the user's
app-data folder) and is never shown again. To pre-configure before distributing,
open the app once and save the keys, or ship a `.env` file next to the project.

## Where the data lives (per user)
Templates, history and settings are saved in:
```
C:\Users\<name>\AppData\Roaming\GN Master Prompt Pipeline\data\
```

## Optional: installer (single Setup .exe)
If you prefer a classic installer that creates a Desktop/Start-menu shortcut:
```bat
npm run dist
```
This uses **electron-builder**. On some PCs it fails while extracting its
code-signing helper with:
`Cannot create symbolic link : A required privilege is not held by the client`.
That is a Windows permission for symlinks. Fix it one of two ways, then re-run:
- **Enable Developer Mode:** Settings → Privacy & security → For developers →
  turn **Developer Mode** ON, or
- Run the command in a terminal opened **as Administrator**.

The packager method above (`build-exe.bat`) avoids this entirely, so use it unless
you specifically need the installer.

## Optional: custom icon
See `build/README-icon.txt`.


## Đóng gói gửi nhân viên (máy nhân viên KHÔNG cần Node.js)

1. Trên máy admin (đã cài Node.js 18+), double-click **`pack-for-staff.bat`**.
2. Chờ vài phút. Xong sẽ có file **`GN-Content-Tool-NhanVien.zip`** ngay trong thư mục dự án.
3. Gửi file zip đó cho nhân viên.
4. Nhân viên: giải nén → mở thư mục `GN Content Tool-win32-x64` → double-click **`GN Content Tool.exe`**.
   - Không cần cài Node.js hay gì cả (app đã gói sẵn mọi thứ).
   - Lần đầu vào **Cài đặt** nhập API key (mỗi máy nhập 1 lần, lưu lại).
   - Đặt **Link cập nhật tự động** (nếu có) để sau này bấm ⬆ Cập nhật là lên bản mới.
