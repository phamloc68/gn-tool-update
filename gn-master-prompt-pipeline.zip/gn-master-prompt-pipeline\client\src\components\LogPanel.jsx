// Diagnostics log: shows each step run with the exact prompt sent + result/error.
import React, { useEffect, useState } from 'react';
import { api } from '../api';
import { Button, Card, Badge } from './ui.jsx';

const STEP_LABEL = {
  title: 'Tiêu đề', content: 'Content', visual_image: 'Prompt ảnh',
  visual_veo: 'Prompt Veo 3', thumbnail: 'Thumbnail',
};

export default function LogPanel({ notify }) {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(null); // full entry
  const [openId, setOpenId] = useState(null);

  async function load() {
    try { setItems(await api.listLogs()); } catch (e) { notify(e.message, 'error'); }
  }
  useEffect(() => { load(); }, []);

  async function view(id) {
    if (openId === id) { setOpenId(null); setOpen(null); return; }
    try { const full = await api.getLog(id); setOpen(full); setOpenId(id); } catch (e) { notify(e.message, 'error'); }
  }
  async function clearAll() {
    if (!confirm('Xoá toàn bộ nhật ký?')) return;
    try { await api.clearLogs(); setItems([]); setOpen(null); setOpenId(null); } catch (e) { notify(e.message, 'error'); }
  }

  return (
    <Card
      title="Nhật ký chạy (chẩn đoán lỗi)"
      subtitle="Mỗi lần bấm nút ở các bước sẽ ghi lại prompt đã gửi + kết quả/lỗi."
      right={<div className="flex gap-2"><Button variant="ghost" onClick={load}>Làm mới</Button><Button variant="ghost" onClick={clearAll}>Xoá nhật ký</Button></div>}
    >
      {items.length === 0 && <p className="text-sm text-slate-500">Chưa có nhật ký. Hãy chạy một bước (vd Viết content) rồi quay lại đây.</p>}
      <div className="space-y-2.5">
        {items.map((h) => (
          <div key={h.id} className="rounded-xl border border-slate-200 p-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="indigo">{STEP_LABEL[h.step] || h.step}</Badge>
              <Badge tone={h.ok ? 'green' : 'red'}>{h.ok ? 'OK' : 'LỖI'}</Badge>
              <span className="text-xs text-slate-500">{h.provider}{h.model ? ` · ${h.model}` : ''}</span>
              <span className="text-xs text-slate-400">{(h.ms / 1000).toFixed(1)}s</span>
              <span className="text-xs text-slate-400">· gửi {h.promptChars} ký tự → nhận {h.outputChars} ký tự</span>
              <span className="ml-auto text-xs text-slate-400">{new Date(h.ts).toLocaleString('vi-VN')}</span>
            </div>
            {!h.ok && h.error && <div className="mt-2 rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">Lỗi: {h.error}</div>}
            <div className="mt-2">
              <Button variant="ghost" onClick={() => view(h.id)}>{openId === h.id ? 'Ẩn chi tiết' : 'Xem chi tiết (prompt + kết quả)'}</Button>
            </div>
            {openId === h.id && open && (
              <div className="mt-2 grid gap-3 lg:grid-cols-2">
                <div>
                  <div className="mb-1 text-xs font-bold uppercase tracking-wide text-slate-500">Prompt đã gửi cho AI</div>
                  <pre className="max-h-80 overflow-auto whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-xs text-slate-700">{open.prompt}</pre>
                </div>
                <div>
                  <div className="mb-1 text-xs font-bold uppercase tracking-wide text-slate-500">{open.ok ? 'Kết quả AI trả về' : 'Lỗi'}</div>
                  <pre className="max-h-80 overflow-auto whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-xs text-slate-700">{open.ok ? open.output : open.error}</pre>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
}
