// Editable output + Copy / TXT / MD / DOCX export. Reused by every step.
import React, { useState } from 'react';
import { api } from '../api';
import { Button, Spinner } from './ui.jsx';

export default function OutputBox({ value, onChange, title = 'output', rows = 12, placeholder }) {
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState('');

  async function copy() {
    try {
      await navigator.clipboard.writeText(value || '');
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch (_) {}
  }
  async function exp(format) {
    if (!value?.trim()) return;
    setBusy(format);
    try {
      await api.exportPart({ text: value, format, title });
    } catch (_) {} finally {
      setBusy('');
    }
  }

  return (
    <div>
      <textarea
        value={value || ''}
        onChange={(e) => onChange?.(e.target.value)}
        rows={rows}
        placeholder={placeholder || 'Kết quả sẽ hiện ở đây…'}
        className="w-full rounded-xl border border-slate-300 bg-slate-50 px-4 py-3 font-mono text-[14px] leading-relaxed text-slate-800 outline-none focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-100"
      />
      <div className="mt-2 flex flex-wrap gap-2">
        <Button variant="secondary" onClick={copy} disabled={!value}>{copied ? '✓ Đã copy' : '📋 Copy'}</Button>
        <Button variant="ghost" onClick={() => exp('txt')} disabled={!value || busy === 'txt'}>TXT</Button>
        <Button variant="ghost" onClick={() => exp('md')} disabled={!value || busy === 'md'}>MD</Button>
        <Button variant="ghost" onClick={() => exp('docx')} disabled={!value || busy === 'docx'}>DOCX</Button>
        {value && <span className="ml-auto self-center text-xs text-slate-400">{value.length.toLocaleString()} ký tự</span>}
      </div>
    </div>
  );
}
