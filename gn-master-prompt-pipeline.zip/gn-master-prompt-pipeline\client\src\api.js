// API client for the project-based backend.
const BASE = '/api';

async function req(path, opts = {}) {
  const res = await fetch(BASE + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const ct = res.headers.get('content-type') || '';
  if (!ct.includes('application/json')) {
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res;
  }
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

async function download(path, opts) {
  const res = await fetch(BASE + path, opts);
  if (!res.ok) {
    const d = await res.json().catch(() => ({}));
    throw new Error(d.error || 'Tải file thất bại');
  }
  const blob = await res.blob();
  const cd = res.headers.get('Content-Disposition') || '';
  const m = cd.match(/filename="(.+?)"/);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = m ? m[1] : 'download';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export const api = {
  providers: () => req('/providers'),
  getSettings: () => req('/settings'),
  testProvider: (provider) => req('/test', { method: 'POST', body: JSON.stringify({ provider }) }),
  saveSettings: (b) => req('/settings', { method: 'POST', body: JSON.stringify(b) }),

  listTemplates: () => req('/templates'),
  getTemplate: (id) => req(`/templates/${id}`),
  createTemplate: (b) => req('/templates', { method: 'POST', body: JSON.stringify(b) }),
  updateTemplate: (id, b) => req(`/templates/${id}`, { method: 'PUT', body: JSON.stringify(b) }),
  deleteTemplate: (id) => req(`/templates/${id}`, { method: 'DELETE' }),

  listProjects: () => req('/projects'),
  getProject: (id) => req(`/projects/${id}`),
  createProject: (b) => req('/projects', { method: 'POST', body: JSON.stringify(b) }),
  updateProject: (id, b) => req(`/projects/${id}`, { method: 'PUT', body: JSON.stringify(b) }),
  deleteProject: (id) => req(`/projects/${id}`, { method: 'DELETE' }),
  runStep: (id, b) => req(`/projects/${id}/run`, { method: 'POST', body: JSON.stringify(b) }),
  llmCall: (id, b) => req(`/projects/${id}/llm`, { method: 'POST', body: JSON.stringify(b) }),

  listLogs: () => req('/logs'),
  getLog: (id) => req(`/logs/${id}`),
  clearLogs: () => req('/logs', { method: 'DELETE' }),

  exportPart: ({ text, format, title }) =>
    download('/projects/export/part', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, format, title }),
    }),
  exportFull: (id) => download(`/projects/${id}/export/full`),
};
