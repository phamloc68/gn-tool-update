// Frontend variable replacement. Supports BOTH {{VAR}} and [VAR] placeholder
// styles, so raw pasted master prompts (which use [TOPIC], [X], [Paste Script],
// [CHARACTER ACTION], ...) work too. The resolved prompt is sent to the backend.

const VARS = {
  TOPIC: 'topic',
  TITLE: 'title',
  LANGUAGE: 'language',
  LENGTH: 'length',
  NOTES: 'notes',
  SCRIPT: 'script',
  VISUAL_TYPE: 'visualType',
  PROMPT_COUNT: 'promptCount',
  CHARACTER_ACTION: 'characterAction',
};

// Extra bracket-style tokens (case-insensitive, whitespace tolerant).
const BRACKET_TOKENS = {
  TOPIC: 'topic',
  TITLE: 'title',
  LANGUAGE: 'language',
  LENGTH: 'length',
  NOTES: 'notes',
  SCRIPT: 'script',
  'PASTE SCRIPT': 'script',
  PASTE_SCRIPT: 'script',
  'SCRIPT SECTION': 'script',
  'VISUAL TYPE': 'visualType',
  VISUAL_TYPE: 'visualType',
  PROMPT_COUNT: 'promptCount',
  'PROMPT COUNT': 'promptCount',
  X: 'promptCount',
  'CHARACTER ACTION': 'characterAction',
  CHARACTER_ACTION: 'characterAction',
};

function esc(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function resolveVars(text, ctx = {}) {
  let out = String(text || '');
  // {{VAR}} style
  for (const [token, key] of Object.entries(VARS)) {
    const v = ctx[key] != null ? String(ctx[key]) : '';
    out = out.replace(new RegExp(`\\{\\{\\s*${token}\\s*\\}\\}`, 'g'), v);
  }
  // [VAR] style (longer tokens first to avoid partial clashes)
  const tokens = Object.keys(BRACKET_TOKENS).sort((a, b) => b.length - a.length);
  for (const token of tokens) {
    const key = BRACKET_TOKENS[token];
    const v = ctx[key] != null ? String(ctx[key]) : '';
    out = out.replace(new RegExp(`\\[\\s*${esc(token)}\\s*\\]`, 'gi'), v);
  }
  return out;
}

export function findUnresolved(text) {
  return [...new Set([...String(text).matchAll(/\{\{\s*[^}]+\s*\}\}/g)].map((m) => m[0].trim()))];
}

export const VAR_LIST = Object.keys(VARS).map((v) => `{{${v}}}`);
