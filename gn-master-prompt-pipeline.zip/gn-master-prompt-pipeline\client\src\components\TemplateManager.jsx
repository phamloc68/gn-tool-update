// Manage master prompt templates — each has 4 explicit prompts.
import React, { useEffect, useState } from 'react';
import { api } from '../api';
import { VAR_LIST } from '../resolve';
import { Button, Card, Field, Input, Textarea, Modal, Spinner, Badge } from './ui.jsx';

const EMPTY = { name: '', niche: '', title_prompt: '', content_prompt: '', visual_prompt: '', thumbnail_prompt: '' };

function Editor({ open, onClose, editing, onSaved, notify }) {
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  useEffect(() => { if (open) setForm(editing ? { ...EMPTY, ...editing } : EMPTY); }, [open, editing]);

  async function save() {
    if (!form.name.trim()) return notify('Cần nhập Template Name.', 'error');
    setSaving(true);
    try {
      const saved = editing ? await api.updateTemplate(editing.id, form) : await api.createTemplate(form);
      notify(editing ? 'Đã cập nhật mẫu.' : 'Đã thêm mẫu.', 'success');
      onSaved(saved); onClose();
    } catch (e) { notify(e.message, 'error'); } finally { setSaving(false); }
  }

  return (
    <Modal open={open} onClose={onClose} title={editing ? 'Sửa mẫu content' : 'Thêm mẫu content'} maxWidth="max-w-3xl">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Template Name"><Input value={form.name} onChange={set('name')} placeholder="VD: Boring History for Sleep" /></Field>
        <Field label="Niche / Channel"><Input value={form.niche} onChange={set('niche')} placeholder="VD: Sleep history" /></Field>
      </div>
      <div className="my-3 rounded-lg bg-indigo-50 px-3 py-2 text-xs text-indigo-700">
        Biến dùng được trong các prompt: {VAR_LIST.join('  ')}
      </div>
      <div className="space-y-3">
      </div>
      <div className="mt-5 flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>Huỷ</Button>
        <Button onClick={save} disabled={saving}>{saving && <Spinner light />} Lưu mẫu</Button>
      </div>
    </Modal>
  );
}

export default function TemplateManager({ notify, onChanged }) {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  async function load() { try { setItems(await api.listTemplates()); onChanged?.(); } catch (e) { notify(e.message, 'error'); } }
  useEffect(() => { load(); }, []);

  async function remove(id, name) {
    if (!confirm(`Xoá mẫu "${name}"?`)) return;
    try { await api.deleteTemplate(id); load(); notify('Đã xoá mẫu.', 'success'); } catch (e) { notify(e.message, 'error'); }
  }
  const has = (t, k) => Boolean((t[k] || '').trim());

  return (
    <Card title="Mẫu content (Master Prompt Templates)" right={<Button onClick={() => { setEditing(null); setOpen(true); }}>+ Thêm mẫu</Button>}>
      {items.length === 0 && <p className="text-sm text-slate-500">Chưa có mẫu nào. Bấm “+ Thêm mẫu” để tạo (gồm 2 prompt: Content và Thumbnail).</p>}
      <div className="space-y-2.5">
        {items.map((t) => (
          <div key={t.id} className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 p-4">
            <div className="min-w-0">
              <div className="font-semibold text-slate-800">{t.name}</div>
              <div className="text-xs text-slate-500">{t.niche || '—'}</div>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {[['content_prompt', 'Content'], ['thumbnail_prompt', 'Thumbnail']].map(([k, lbl]) => (
                  <Badge key={k} tone={has(t, k) ? 'green' : 'red'}>{lbl}</Badge>
                ))}
              </div>
            </div>
            <div className="flex shrink-0 gap-2">
              <Button variant="secondary" onClick={() => { setEditing(t); setOpen(true); }}>Sửa</Button>
              <Button variant="ghost" onClick={() => remove(t.id, t.name)}>Xoá</Button>
            </div>
          </div>
        ))}
      </div>
      <Editor open={open} onClose={() => setOpen(false)} editing={editing} onSaved={load} notify={notify} />
    </Card>
  );
}
