// Electron main process.
// Starts the embedded Express server, then opens a desktop window pointing at it.
const { app, BrowserWindow, Menu, shell, dialog, ipcMain } = require('electron');
const { execFile, spawnSync } = require('child_process');
const path = require('path');
const fs = require('fs');

// Persist the SQLite DB + settings.json in the per-user app data folder so the
// packaged .exe can write even when installed under Program Files.
app.setName('GN Content Tool'); // keep data dir consistent across packaged + direct run
const userData = app.getPath('userData');
process.env.DATA_DIR = path.join(userData, 'data');
process.env.NODE_ENV = process.env.NODE_ENV || 'production';

let mainWindow = null;
let serverInfo = null;

async function startServer() {
  // server/app.js exports { createApp, start }
  const { start } = require(path.join(__dirname, '..', 'server', 'app.js'));
  // Port 0 = let the OS pick a free port (avoids clashes on the user's machine).
  serverInfo = await start({ port: process.env.PORT ? Number(process.env.PORT) : 0 });
  return serverInfo.port;
}

function createWindow(port) {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 960,
    minHeight: 640,
    backgroundColor: '#0f1115',
    title: 'GN Content Tool',
    ...(function () {
      const ico = path.join(__dirname, '..', 'build', 'icon.png');
      return fs.existsSync(ico) ? { icon: ico } : {};
    })(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  // Open external links in the user's browser, not inside the app window.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.loadURL(`http://localhost:${port}/`);

  // If the page fails to load, show the reason instead of a blank window.
  mainWindow.webContents.on('did-fail-load', (e, code, desc, url, isMainFrame) => {
    if (!isMainFrame) return;
    const html =
      '<body style="font-family:sans-serif;padding:24px;color:#1f2937">' +
      '<h2 style="color:#b91c1c">Không tải được giao diện</h2>' +
      '<p>Mã lỗi: ' + code + ' — ' + desc + '</p>' +
      '<p>URL: ' + url + '</p>' +
      '<p>Hãy đóng app và chạy lại Start.bat. Nếu vẫn lỗi, chụp màn hình này gửi hỗ trợ.</p>' +
      '<button onclick="location.reload()" style="padding:8px 16px;background:#4f46e5;color:#fff;border:none;border-radius:8px">Thử lại</button>' +
      '</body>';
    mainWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
  });
  mainWindow.webContents.on('render-process-gone', (e, details) => {
    dialog.showErrorBox('GN Content Tool', 'Giao diện bị dừng: ' + (details && details.reason));
  });
  mainWindow.on('closed', () => (mainWindow = null));
}

function buildMenu() {
  const template = [
    {
      label: 'File',
      submenu: [{ role: 'reload' }, { role: 'forceReload' }, { type: 'separator' }, { role: 'quit' }],
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' }, { role: 'redo' }, { type: 'separator' },
        { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' },
      ],
    },
    {
      label: 'View',
      submenu: [{ role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' }, { role: 'toggleDevTools' }],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ---------- One-click in-app updater ----------
function extractZip(zip, dest) {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(dest, { recursive: true });
    execFile(
      'powershell.exe',
      ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command',
        `Expand-Archive -LiteralPath \'${zip}\' -DestinationPath \'${dest}\' -Force`],
      (err) => (err ? reject(err) : resolve()),
    );
  });
}

function copyOver(src, dst, skip) {
  for (const name of fs.readdirSync(src)) {
    if (skip.includes(name)) continue;
    const sp = path.join(src, name);
    const dp = path.join(dst, name);
    const st = fs.statSync(sp);
    if (st.isDirectory()) {
      fs.mkdirSync(dp, { recursive: true });
      copyOver(sp, dp, skip);
    } else {
      try { fs.copyFileSync(sp, dp); } catch (_) {}
    }
  }
}

function newestZipInDownloads() {
  try {
    const dir = app.getPath('downloads');
    const cands = fs.readdirSync(dir)
      .filter((n) => /gn-master-prompt-pipeline.*\.zip$/i.test(n) || /gn[-_].*content.*\.zip$/i.test(n))
      .map((n) => ({ p: path.join(dir, n), t: fs.statSync(path.join(dir, n)).mtimeMs }))
      .sort((a, b) => b.t - a.t);
    return cands.length ? cands[0].p : null;
  } catch (_) { return null; }
}

ipcMain.handle('app-update', async (_evt, opts) => {
  opts = opts || {};
  try {
    let zip = null;

    // 1) If an Update URL is configured, download the zip from it.
    if (opts.url && /^https?:\/\//i.test(opts.url)) {
      let res;
      try { res = await fetch(opts.url); } catch (e) {
        return { ok: false, error: 'Không tải được bản cập nhật từ link: ' + e.message };
      }
      if (!res || !res.ok) return { ok: false, error: 'Link cập nhật lỗi (HTTP ' + (res && res.status) + ').' };
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length < 1000 || buf.slice(0, 2).toString() !== 'PK') {
        return { ok: false, error: 'Link không trả về file zip hợp lệ. Hãy dùng link TẢI TRỰC TIẾP file .zip.' };
      }
      zip = path.join(app.getPath('temp'), 'gn-update-dl-' + Date.now() + '.zip');
      fs.writeFileSync(zip, buf);
    }

    // 2) Otherwise use the newest matching zip in Downloads (no prompt).
    if (!zip) zip = newestZipInDownloads();

    // 3) Otherwise let the user pick a zip.
    if (!zip) {
      const r = await dialog.showOpenDialog(mainWindow, {
        title: 'Chọn file cập nhật (.zip)', properties: ['openFile'],
        filters: [{ name: 'Zip', extensions: ['zip'] }],
      });
      if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
      zip = r.filePaths[0];
    }

    const appRoot = path.join(__dirname, '..');
    const tmp = path.join(app.getPath('temp'), 'gn-update-' + Date.now());
    await extractZip(zip, tmp);

    let src = tmp;
    if (fs.existsSync(path.join(tmp, 'gn-master-prompt-pipeline'))) {
      src = path.join(tmp, 'gn-master-prompt-pipeline');
    } else {
      const dirs = fs.readdirSync(tmp).filter((n) => fs.statSync(path.join(tmp, n)).isDirectory());
      if (dirs.length === 1) src = path.join(tmp, dirs[0]);
    }
    if (!fs.existsSync(path.join(src, 'server', 'app.js'))) {
      return { ok: false, error: 'File zip không đúng (thiếu server/app.js).' };
    }

    let needInstall = false;
    try {
      const oldPkg = JSON.parse(fs.readFileSync(path.join(appRoot, 'package.json'), 'utf8'));
      const newPkg = JSON.parse(fs.readFileSync(path.join(src, 'package.json'), 'utf8'));
      needInstall = JSON.stringify(oldPkg.dependencies || {}) !== JSON.stringify(newPkg.dependencies || {});
    } catch (_) {}

    copyOver(src, appRoot, ['node_modules', 'data', 'release', '.env', '.git']);

    if (needInstall) {
      try {
        spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm',
          ['install', '--omit=dev', '--no-audit', '--no-fund'],
          { cwd: appRoot, stdio: 'ignore' });
      } catch (_) {}
    }

    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (_) {}

    app.relaunch();
    app.exit(0);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
});

// Ensure only one instance runs.
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });

  app.whenReady().then(async () => {
    try {
      const port = await startServer();
      buildMenu();
      createWindow(port);
    } catch (err) {
      dialog.showErrorBox(
        'GN Content Tool - startup error',
        'The internal server failed to start:\n\n' + (err && err.stack ? err.stack : String(err))
      );
      app.quit();
    }

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0 && serverInfo) createWindow(serverInfo.port);
    });
  });

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });
}
