@echo off
REM ============================================================
REM  GN Content Tool - one-click Windows .exe builder
REM  Run ONCE on a Windows PC with Node.js 18+.
REM  The user interface is PRE-BUILT and bundled, so this script
REM  does NOT need to compile the frontend (no vite step) - it just
REM  installs the runtime, packages the app, and makes a Desktop shortcut.
REM  No admin, no Visual Studio, no code-signing.
REM ============================================================
setlocal

echo.
echo [1/4] Tim Node.js...
where node >nul 2>nul
if not errorlevel 1 goto :node_ok
for %%P in ("%ProgramFiles%\nodejs" "%ProgramFiles(x86)%\nodejs" "%LOCALAPPDATA%\Programs\nodejs" "%ProgramW6432%\nodejs") do (
  if exist "%%~P\node.exe" set "PATH=%%~P;%PATH%"
)
where node >nul 2>nul
if not errorlevel 1 goto :node_ok
echo.
echo   KHONG TIM THAY Node.js. Vua cai thi KHOI DONG LAI MAY; chua cai thi tai LTS o https://nodejs.org/
pause
exit /b 1
:node_ok
node -v

echo.
echo [2/4] Installing runtime dependencies...
call npm install || goto :error

echo.
echo [3/4] Preparing the user interface...
if exist "client\dist\index.html" (
  echo   Using the pre-built interface ^(client\dist^). Skipping the frontend build.
) else (
  echo   No pre-built interface found - building it now...
  call npm --prefix client install || goto :error
  call npm --prefix client run build || goto :error
)

echo.
echo [4/4] Packaging the Windows app ^(downloads Electron the first time^)...
call npx --no-install electron-packager . "GN Content Tool" --platform=win32 --arch=x64 --out=release --overwrite --prune=true --ignore="/client/node_modules" --ignore="/client/src" --ignore="^/release" || goto :error

echo.
echo Creating Desktop shortcut...
set "APPDIR=%CD%\release\GN Content Tool-win32-x64"
set "APPEXE=%APPDIR%\GN Content Tool.exe"
if exist "%APPEXE%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $d=[Environment]::GetFolderPath('Desktop'); $s=$w.CreateShortcut((Join-Path $d 'GN Content Tool.lnk')); $s.TargetPath='%APPEXE%'; $s.WorkingDirectory='%APPDIR%'; $s.IconLocation='%APPEXE%,0'; $s.Save()"
)

echo.
echo ============================================================
echo  DONE!  A "GN Content Tool" shortcut is on your DESKTOP.
echo  Double-click it to open the app.
echo
echo  Program folder: release\GN Content Tool-win32-x64\
echo  To share with staff: ZIP that folder and send it.
echo ============================================================
echo.
pause
exit /b 0

:error
echo.
echo BUILD FAILED. Scroll up to see the first error message.
pause
exit /b 1
