# GN Master Prompt Pipeline Tool

A **desktop application** for staff to produce video content through a clear
**4-step project workflow: TITLE → CONTENT → VISUAL → THUMBNAIL**, using
**Claude / Gemini / any OpenAI-compatible** provider.

Staff just **double-click the app icon** — it opens in its own window. Each video is
a **Project** that uses a **Master Prompt Template** made of 4 explicit prompts
(Title / Content / Visual / Thumbnail). The tool fills the variables and runs each
step; the selected title flows into Content, Content into Visual & Thumbnail.

> Built with Electron (desktop shell) + React/Tailwind (UI) + Node/Express + SQLite (sql.js).

---

## For staff (daily use)

1. Open the app (Desktop shortcut, or the portable `.exe`).
2. First time only: click **Settings** → paste the Claude / Gemini API key → Save.
3. Add a template (Upload `.md`/`.txt` or Paste), fill **CONFIG**, pick the provider.
4. Click a button: **Generate Titles**, **Generate Script / Outline**
   (then **Continue Section**), **Generate Image Prompts**, **Generate Thumbnail Prompt**.
5. Edit the output, then **Copy** or **Export** to `.txt` / `.md` / `.docx`.
6. Everything is saved under **History**.

No terminal, no browser, no setup beyond the key.

---

## For the admin: make the .exe

See **[BUILD-WINDOWS.md](./BUILD-WINDOWS.md)**. Short version, run once on a Windows PC with Node.js 18+:

- Double-click **`build-exe.bat`** (no Visual Studio, no admin, no code-signing).
- The app appears in **`release\GN Master Prompt Pipeline-win32-x64\`**.
- Inside is **`GN Master Prompt Pipeline.exe`** — staff double-click it to run.
  To distribute, ZIP that folder and send it (they unzip + double-click; nothing to install).

A classic single-file installer is optional via `npm run dist` (electron-builder) — see BUILD-WINDOWS.md for the one Windows setting it needs.

---

## Features

- Double-click desktop app (Electron) — packaged with @electron/packager (no native build, no code-signing).
- Template management — upload `.md`/`.txt` or paste; stores name, brand, niche, notes, full content.
- Auto module detection — TOPIC / SCRIPT / IMAGES / THUMBNAIL.
- CONFIG form — BRAND, LANE, TOPIC, ERA/REGION, RUNTIME, X, VISUAL STYLE, THUMBNAIL STYLE.
- Variable replacement — `{{BRAND}} {{LANE}} {{TOPIC}} {{ERA}} {{RUNTIME}} {{X}} {{VISUAL_STYLE}} {{THUMB_STYLE}}`
  plus `[TOPIC]` (SCRIPT), `[PASTE SCRIPT]` (IMAGES), `[CHARACTER ACTION]` (THUMBNAIL).
- 4 run buttons + the SCRIPT outline → **Continue Section** workflow (sends `CONTINUE` + prior context).
- Output editor — copy, edit, export `.txt` / `.md` / `.docx`.
- History — employee, template, module, config, output, model, provider, timestamp.
- Claude + Gemini — keys entered in-app Settings, stored locally, never shown in the UI or bundled in code.

---

## Project structure

```
gn-master-prompt-pipeline/
├── package.json            # desktop app + build config (electron-builder)
├── build-exe.bat           # one-click Windows build
├── BUILD-WINDOWS.md        # how to produce the .exe
├── .env.example            # optional: keys via file instead of the Settings UI
├── sample-master-prompt.md # example 4-module master prompt
├── electron/
│   ├── main.js             # starts embedded server, opens the window
│   └── preload.js
├── server/                 # Express + SQLite API (embedded in the app)
│   ├── app.js              # createApp() / start()  (no auto-listen)
│   ├── index.js            # CLI entry (npm run dev / start)
│   ├── db.js               # SQLite via sql.js (WASM, no native build); DATA_DIR configurable
│   ├── routes/             # templates, generate, history, settings
│   └── lib/                # parser, replacer, llm (Claude+Gemini), exporter, settings
└── client/                 # React + Vite + Tailwind UI -> built into client/dist
    └── src/...
```

---

## Run from source (developers, optional)

```bash
npm run setup     # installs root + client deps
npm run dev       # API on :3001, Vite UI on http://localhost:5173
```

Run it as a desktop window without packaging:
```bash
npm run app       # builds the UI then launches the Electron window
```

API keys for source/dev mode: either use the in-app **Settings**, or copy
`.env.example` to `.env` and fill the keys.

---

## Providers & custom (OpenAI-compatible) endpoints

In **Settings** you can configure three providers:
- **Claude** (Anthropic) — needs `ANTHROPIC_API_KEY`.
- **Gemini** (Google) — needs `GEMINI_API_KEY`.
- **Custom (OpenAI-compatible)** — for any endpoint that speaks the OpenAI API,
  e.g. `https://llm.chiasegpu.vn/v1`. Set the **Base URL**, **API key**, and **Model**.
  The tool calls `POST {BaseURL}/chat/completions` with `Authorization: Bearer <key>`.

Pick the active provider from the dropdown in the header.

## Shared preamble (CONFIG / LANE LIBRARY)

If your master prompt keeps shared text **before module 1** (a CONFIG block, a
"LANE LIBRARY", shared DNA, etc.) and each module says things like
`[PASTE CONFIG HERE]` or "see LANE LIBRARY", enable **"Include shared preamble"**
in the CONFIG panel (on by default). The tool auto-prepends that preamble to every
module and fills `[PASTE CONFIG HERE]` from your CONFIG form. The bundled
`examples/BoringHistory_Universal_Master_Prompt.md` is exactly this style.

### Multiple keys & parallel script (custom provider)

The OpenAI-compatible provider supports a **key pool**: a primary key plus
**secondary keys** (Settings → "Secondary keys", one per line). The
**"⚡ Write full script in parallel (multi-key)"** button generates the outline,
splits it into sections, and expands **all sections at once** — one worker per
key. With 2 keys it runs roughly twice as fast. Sections are reassembled in order
and saved like a normal script run (you can still use "Continue Section").
Trade-off: parallel sections don't read each other while writing, so cross-section
callbacks are looser than the sequential CONTINUE flow.

---

## Variables reference

| Placeholder            | CONFIG field        | Used in          |
|------------------------|---------------------|------------------|
| `{{BRAND}}`            | Brand               | all              |
| `{{LANE}}`             | Lane                | all              |
| `{{TOPIC}}`            | Topic               | all              |
| `{{ERA}}` / `{{REGION}}` | Era / Region      | all              |
| `{{RUNTIME}}`          | Runtime target      | all              |
| `{{X}}`                | X                   | all              |
| `{{VISUAL_STYLE}}`     | Visual style        | all              |
| `{{THUMB_STYLE}}`      | Thumbnail style     | all              |
| `[TOPIC]`              | Topic               | SCRIPT module    |
| `[PASTE SCRIPT]`       | assembled script    | IMAGES module    |
| `[CHARACTER ACTION]`   | Character action    | THUMBNAIL module |

---

## Data & privacy
- Per-user data (templates, history, settings/keys) lives in the OS app-data folder:
  `…/AppData/Roaming/GN Master Prompt Pipeline/data/`.
- API keys are sent only to the chosen AI provider; they are never returned to the UI.
