// Settings API: report which keys are configured (booleans only) and save new
// keys/models. The actual key values are never returned to the frontend.
const express = require('express');
const settings = require('../lib/settings');

const router = express.Router();

router.get('/', (req, res) => {
  res.json(settings.publicView());
});

router.post('/', (req, res) => {
  try {
    settings.save(req.body || {});
    res.json({ ok: true, ...settings.publicView() });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Could not save settings' });
  }
});

module.exports = router;
