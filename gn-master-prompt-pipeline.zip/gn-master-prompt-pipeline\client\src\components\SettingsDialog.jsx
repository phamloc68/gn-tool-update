// Settings: choose active provider + keys/models. Keys stay on this machine.
import React, { useEffect, useState } from 'react';
import { api } from '../api';
import { Button, Field, Input, Textarea, Select, Badge, Spinner, Modal } from './ui.jsx';

export default function SettingsDialog({ open, onClose, provider, onProviderChange, notify }) {
  const [status, setStatus] = useState(null);
  const [prov, setProv] = useState(provider || 'claude');
  const [form, setForm] = useState({
    ANTHROPIC_API_KEY: '', CLAUDE_MODEL: '',
    GEMINI_API_KEY: '', GEMINI_MODEL: '',
    OPENAI_API_KEY: '', OPENAI_API_KEYS_EXTRA: '', OPENAI_BASE_URL: '', OPENAI_MODEL: '',
    MAX_TOKENS: '', TEMPERATURE: '', UPDATE_URL: '',
  });
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function applyForm() {
    const patch = { ...form };
    ['ANTHROPIC_API_KEY', 'GEMINI_API_KEY', 'OPENAI_API_KEY', 'OPENAI_API_KEYS_EXTRA'].forEach((k) => { if (!patch[k]) delete patch[k]; });
    await api.saveSettings(patch);
  }

  async function testConnection() {
    setTesting(true); setTestResult(null);
    try {
      await applyForm(); // save current keys/base/model first
      const r = await api.testProvider(prov);
      setTestResult({ ok: true, msg: `Kết nối OK (model: ${r.model}). Trả lời: ${r.text || '(rỗng)'}` });
      onProviderChange?.(prov);
    } catch (e) {
      setTestResult({ ok: false, msg: e.message });
    } finally { setTesting(false); }
  }

  async function load() {
    try {
      const s = await api.getSettings();
      setStatus(s);
      setForm((f) => ({
        ...f,
        CLAUDE_MODEL: s.claudeModel || '', GEMINI_MODEL: s.geminiModel || '',
        OPENAI_BASE_URL: s.openaiBase || '', OPENAI_MODEL: s.openaiModel || '',
        MAX_TOKENS: s.maxTokens || '', TEMPERATURE: s.temperature || '', UPDATE_URL: s.updateUrl || '',
        ANTHROPIC_API_KEY: '', GEMINI_API_KEY: '', OPENAI_API_KEY: '', OPENAI_API_KEYS_EXTRA: '',
      }));
    } catch (e) { notify(e.message, 'error'); }
  }
  useEffect(() => { if (open) { setProv(provider || 'claude'); load(); } /* eslint-disable-next-line */ }, [open]);

  async function save() {
    setSaving(true);
    try {
      const patch = { ...form };
      ['ANTHROPIC_API_KEY', 'GEMINI_API_KEY', 'OPENAI_API_KEY', 'OPENAI_API_KEYS_EXTRA'].forEach((k) => { if (!patch[k]) delete patch[k]; });
      await api.saveSettings(patch);
      onProviderChange?.(prov);
      notify('Đã lưu cài đặt.', 'success');
      onClose();
    } catch (e) { notify(e.message, 'error'); } finally { setSaving(false); }
  }

  return (
    <Modal open={open} onClose={onClose} title="Cài đặt (chỉ admin)" maxWidth="max-w-xl">
      <div className="mb-3 flex flex-wrap gap-2">
        <Badge tone={status?.hasClaudeKey ? 'green' : 'red'}>Claude {status?.hasClaudeKey ? '✓' : 'chưa có key'}</Badge>
        <Badge tone={status?.hasGeminiKey ? 'green' : 'red'}>Gemini {status?.hasGeminiKey ? '✓' : 'chưa có key'}</Badge>
        <Badge tone={status?.hasOpenAIKey ? 'green' : 'red'}>Custom {status?.openaiKeyCount ? `(${status.openaiKeyCount} key)` : 'chưa có key'}</Badge>
      </div>

      <Field label="Nhà cung cấp AI đang dùng">
        <Select value={prov} onChange={(e) => setProv(e.target.value)}>
          <option value="claude">Claude (Anthropic)</option>
          <option value="gemini">Gemini (Google)</option>
          <option value="openai">Custom (OpenAI-compatible)</option>
        </Select>
      </Field>
      <div className="mt-2">
        <Button variant="secondary" onClick={testConnection} disabled={testing}>
          {testing && <Spinner />} Kiểm tra kết nối
        </Button>
        {testResult && (
          <div className={`mt-2 rounded-lg border px-3 py-2 text-sm ${testResult.ok ? 'border-emerald-300 bg-emerald-50 text-emerald-700' : 'border-rose-300 bg-rose-50 text-rose-700'}`}>
            {testResult.ok ? '✓ ' : '✕ '}{testResult.msg}
          </div>
        )}
      </div>

      <div className="mt-4 space-y-3 rounded-xl border border-slate-200 p-4">
        <div className="text-xs font-bold uppercase tracking-wide text-slate-500">Custom (OpenAI-compatible)</div>
        <Field label="Base URL" hint="VD: https://llm.chiasegpu.vn/v1">
          <Input value={form.OPENAI_BASE_URL} onChange={set('OPENAI_BASE_URL')} placeholder="https://llm.chiasegpu.vn/v1" />
        </Field>
        <Field label="API key" hint="Để trống nếu giữ key cũ.">
          <Input type="password" autoComplete="off" value={form.OPENAI_API_KEY} onChange={set('OPENAI_API_KEY')} placeholder={status?.hasOpenAIKey ? '•••••••• (đã lưu)' : 'sk-...'} />
        </Field>
        <Field label="Model" hint="VD: ant/claude-opus-4-6, qwen2.5-72b…">
          <Input value={form.OPENAI_MODEL} onChange={set('OPENAI_MODEL')} placeholder="ant/claude-opus-4-6" />
        </Field>
        <Field label="Key phụ (mỗi dòng 1 key)" hint="Để trống nếu chỉ dùng 1 key.">
          <Textarea rows={2} value={form.OPENAI_API_KEYS_EXTRA} onChange={set('OPENAI_API_KEYS_EXTRA')} placeholder={'sk-key2...\nsk-key3...'} />
        </Field>
      </div>

      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <Field label="Claude key"><Input type="password" autoComplete="off" value={form.ANTHROPIC_API_KEY} onChange={set('ANTHROPIC_API_KEY')} placeholder={status?.hasClaudeKey ? '•••••••• (đã lưu)' : 'sk-ant-...'} /></Field>
        <Field label="Claude model"><Input value={form.CLAUDE_MODEL} onChange={set('CLAUDE_MODEL')} placeholder="claude-sonnet-4-6" /></Field>
        <Field label="Gemini key"><Input type="password" autoComplete="off" value={form.GEMINI_API_KEY} onChange={set('GEMINI_API_KEY')} placeholder={status?.hasGeminiKey ? '•••••••• (đã lưu)' : 'AIza...'} /></Field>
        <Field label="Gemini model"><Input value={form.GEMINI_MODEL} onChange={set('GEMINI_MODEL')} placeholder="gemini-2.0-flash" /></Field>
        <Field label="Max tokens"><Input type="number" value={form.MAX_TOKENS} onChange={set('MAX_TOKENS')} placeholder="8000" /></Field>
        <Field label="Temperature"><Input type="number" step="0.1" value={form.TEMPERATURE} onChange={set('TEMPERATURE')} placeholder="0.8" /></Field>
      </div>

      <Field label="Link cập nhật tự động (tùy chọn)" hint="Dán link TẢI TRỰC TIẾP file .zip bản mới (GitHub / Google Drive direct / server). Có link rồi thì bấm ⬆ Cập nhật là app tự tải và cài.">
        <Input value={form.UPDATE_URL} onChange={set('UPDATE_URL')} placeholder="https://.../gn-master-prompt-pipeline.zip" />
      </Field>

      <p className="mt-3 text-xs text-slate-500">Key được lưu cục bộ trên máy này, không hiển thị lại và chỉ gửi tới nhà cung cấp AI đã chọn.</p>

      <div className="mt-5 flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>Đóng</Button>
        <Button onClick={save} disabled={saving}>{saving && <Spinner light />} Lưu</Button>
      </div>
    </Modal>
  );
}
