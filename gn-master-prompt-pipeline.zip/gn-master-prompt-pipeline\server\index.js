// CLI entry point: `npm run dev` / `npm start`. Loads .env then starts the API.
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const { start } = require('./app');

const PORT = process.env.PORT || 3001;
start({ port: PORT })
  .then(({ port }) => {
    console.log(`\n  GN Master Prompt Pipeline API running on http://localhost:${port}`);
    console.log(`  Health: http://localhost:${port}/api/health\n`);
  })
  .catch((err) => {
    console.error('Failed to start server:', err.message);
    process.exit(1);
  });
