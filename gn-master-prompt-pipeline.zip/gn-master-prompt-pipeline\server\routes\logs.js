const express = require('express');
const runlog = require('../lib/runlog');
const router = express.Router();

router.get('/', (req, res) => res.json(runlog.list()));
router.get('/:id', (req, res) => {
  const e = runlog.get(req.params.id);
  if (!e) return res.status(404).json({ error: 'Not found' });
  res.json(e);
});
router.delete('/', (req, res) => { runlog.clear(); res.json({ ok: true }); });

module.exports = router;
