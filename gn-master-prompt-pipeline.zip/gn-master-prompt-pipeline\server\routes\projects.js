// Projects: CRUD, run a step (LLM call with a pre-resolved prompt), exports.
const express = require('express');
const { projects } = require('../db');
const { exportBuffer, projectDocx } = require('../lib/exporter');
const llm = require('../lib/llm');
const runlog = require('../lib/runlog');

const router = express.Router();

// stepName -> { output column, status column }
const STEP_MAP = {
  title: { out: 'titles_output', status: 'status_title' },
  content: { out: 'content', status: 'status_content' },
  visual_image: { out: 'visual_image', status: 'status_visual' },
  visual_veo: { out: 'visual_veo', status: 'status_visual' },
  thumbnail: { out: 'thumbnail_prompt', status: 'status_thumbnail' },
};

router.get('/', (req, res) => res.json(projects.all()));

router.get('/:id', (req, res) => {
  const p = projects.get(req.params.id);
  if (!p) return res.status(404).json({ error: 'Project not found' });
  res.json(p);
});

router.post('/', (req, res) => {
  const b = req.body || {};
  if (!b.name || !b.name.trim())
    return res.status(400).json({ error: 'Cần nhập tên project.' });
  res.status(201).json(projects.create(b));
});

// Generic save (edited inputs/outputs, selected title, statuses, etc.)
router.put('/:id', (req, res) => {
  const updated = projects.update(req.params.id, req.body || {});
  if (!updated) return res.status(404).json({ error: 'Project not found' });
  res.json(updated);
});

router.delete('/:id', (req, res) => {
  projects.remove(req.params.id);
  res.json({ ok: true });
});

// Run a step: backend receives projectId, stepName, resolvedPrompt -> LLM -> save.
router.post('/:id/run', async (req, res) => {
  try {
    const { stepName, resolvedPrompt, provider = 'claude', model, config = {} } = req.body || {};
    const map = STEP_MAP[stepName];
    if (!map) return res.status(400).json({ error: `Unknown stepName "${stepName}"` });

    const project = projects.get(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    if (!resolvedPrompt || !resolvedPrompt.trim())
      return res.status(400).json({ error: 'resolvedPrompt rỗng (prompt của bước này chưa được cấu hình trong template).' });

    const t0 = Date.now();
    let result;
    try {
      result = await llm.generate({
        provider,
        model,
        prompt: resolvedPrompt,
        temperature: config.temperature,
        maxTokens: config.maxTokens,
      });
    } catch (genErr) {
      runlog.add({ step: stepName, provider, model, ok: false, ms: Date.now() - t0, prompt: resolvedPrompt, output: '', error: genErr.message });
      throw genErr;
    }
    runlog.add({ step: stepName, provider, model: result.model, ok: true, ms: Date.now() - t0, prompt: resolvedPrompt, output: result.text });

    const patch = { [map.out]: result.text, [map.status]: 'done' };
    const updated = projects.update(project.id, patch);

    res.json({ output: result.text, stepName, provider, model: result.model, project: updated });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message || 'Run failed' });
  }
});

// Generic single LLM call for a project (used by chunked content generation).
// Returns the output; does NOT save to a fixed column.
router.post('/:id/llm', async (req, res) => {
  try {
    const { resolvedPrompt, provider = 'claude', model, step = 'content-part' } = req.body || {};
    const project = projects.get(req.params.id);
    if (!project) return res.status(404).json({ error: 'Project not found' });
    if (!resolvedPrompt || !resolvedPrompt.trim())
      return res.status(400).json({ error: 'resolvedPrompt rỗng.' });
    const t0 = Date.now();
    let result;
    try {
      result = await llm.generate({ provider, model, prompt: resolvedPrompt });
    } catch (e) {
      runlog.add({ step, provider, model, ok: false, ms: Date.now() - t0, prompt: resolvedPrompt, output: '', error: e.message });
      throw e;
    }
    runlog.add({ step, provider, model: result.model, ok: true, ms: Date.now() - t0, prompt: resolvedPrompt, output: result.text });
    res.json({ output: result.text, model: result.model });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message || 'Run failed' });
  }
});

// Export one piece of text (txt/md/docx) — used by per-output buttons.
router.post('/export/part', async (req, res) => {
  try {
    const { text, format = 'txt', title = 'output' } = req.body || {};
    if (text == null) return res.status(400).json({ error: 'text is required' });
    const safe = String(title).replace(/[^\w\-]+/g, '_').slice(0, 80) || 'output';
    const { buffer, mime, ext } = await exportBuffer(format, text, title);
    res.setHeader('Content-Type', mime);
    res.setHeader('Content-Disposition', `attachment; filename="${safe}.${ext}"`);
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ error: err.message || 'Export failed' });
  }
});

// Export the full project package (.docx).
router.get('/:id/export/full', async (req, res) => {
  try {
    const p = projects.get(req.params.id);
    if (!p) return res.status(404).json({ error: 'Project not found' });
    const buffer = await projectDocx(p);
    const safe = String(p.name || 'project').replace(/[^\w\-]+/g, '_').slice(0, 80) || 'project';
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', `attachment; filename="${safe}_full.docx"`);
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ error: err.message || 'Export failed' });
  }
});

module.exports = router;
