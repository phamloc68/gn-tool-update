@echo off
REM ============================================================
REM  GN Content Tool - RUN (always rebuilds a fresh interface)
REM  Runs straight from these files, rebuilding the UI so you can
REM  never get a stale/blank screen. No "release", no old .exe.
REM ============================================================
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed. Get it from https://nodejs.org/ (LTS) and re-run.
  pause
  exit /b 1
)

if not exist "node_modules\electron" (
  echo Installing app dependencies (first time)...
  call npm install || (echo Install failed & pause & exit /b 1)
)
if not exist "client\node_modules\vite" (
  echo Installing UI dependencies (first time)...
  call npm --prefix client install || (echo Install failed & pause & exit /b 1)
)

echo Building the interface...
call npm --prefix client run build || (echo UI build failed & pause & exit /b 1)

echo Opening GN Content Tool...
call npx --no-install electron .
exit /b 0
