@echo off
REM Creates a Desktop shortcut to the already-built app.
setlocal
set "APPDIR=%CD%\release\GN Content Tool-win32-x64"
set "APPEXE=%APPDIR%\GN Content Tool.exe"
if not exist "%APPEXE%" (
  echo Could not find the app yet. Run build-exe.bat first.
  echo Looked for: %APPEXE%
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $d=[Environment]::GetFolderPath('Desktop'); $s=$w.CreateShortcut((Join-Path $d 'GN Content Tool.lnk')); $s.TargetPath='%APPEXE%'; $s.WorkingDirectory='%APPDIR%'; $s.IconLocation='%APPEXE%,0'; $s.Save()"
echo Done. A "GN Content Tool" shortcut is on your Desktop.
pause
exit /b 0
