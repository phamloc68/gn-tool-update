import React, { useEffect, useState } from 'react';
import { api } from './api';
import { Button, Input, Toast } from './components/ui.jsx';
import ProjectList from './components/ProjectList.jsx';
import ProjectWorkflow from './components/ProjectWorkflow.jsx';
import TemplateManager from './components/TemplateManager.jsx';
import SettingsDialog from './components/SettingsDialog.jsx';
import LogPanel from './components/LogPanel.jsx';

export default function App() {
  const [view, setView] = useState('projects'); // projects | workflow | templates
  const [activeProjectId, setActiveProjectId] = useState(null);
  const [employee, setEmployee] = useState(() => localStorage.getItem('gn_employee') || '');
  const [provider, setProvider] = useState(() => localStorage.getItem('gn_provider') || 'claude');
  const [providers, setProviders] = useState({ claude: false, gemini: false, openai: false });
  const [templates, setTemplates] = useState([]);
  const [showSettings, setShowSettings] = useState(false);
  const [toast, setToast] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);

  const isDesktop = typeof window !== 'undefined' && window.gnDesktop && window.gnDesktop.isDesktop;
  async function doUpdate() {
    if (!isDesktop) return;
    let url = '';
    try { url = (await api.getSettings()).updateUrl || ''; } catch (_) {}
    notify(url ? 'Đang tải bản mới từ link…' : 'Đang cập nhật từ file trong Downloads…', 'info');
    try {
      const r = await window.gnDesktop.update({ url });
      if (r && r.ok) notify('Đã cập nhật, app đang khởi động lại…', 'success');
      else if (r && r.canceled) {} 
      else notify('Cập nhật lỗi: ' + (r && r.error || 'không rõ'), 'error');
    } catch (e) { notify('Cập nhật lỗi: ' + e.message, 'error'); }
  }

  function notify(message, type = 'info') {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  }

  async function reloadTemplates() {
    try { setTemplates(await api.listTemplates()); } catch (_) {}
  }
  async function reloadProviders() {
    try {
      const p = await api.providers();
      setProviders(p);
      const has = (x) => (x === 'openai' ? p.openai : x === 'gemini' ? p.gemini : p.claude);
      // Auto-correct: if the active provider has no key but another does, switch to it.
      setProvider((prev) => {
        if (has(prev)) return prev;
        return p.openai ? 'openai' : p.claude ? 'claude' : p.gemini ? 'gemini' : prev;
      });
    } catch (_) {}
  }

  useEffect(() => { reloadTemplates(); reloadProviders(); }, []);
  useEffect(() => { localStorage.setItem('gn_employee', employee); }, [employee]);
  useEffect(() => { localStorage.setItem('gn_provider', provider); }, [provider]);

  const anyKey = providers.claude || providers.gemini || providers.openai;
  const PROV_LABEL = { claude: 'Claude', gemini: 'Gemini', openai: 'Custom (OpenAI)' };
  const providerHasKey =
    provider === 'openai' ? providers.openai : provider === 'gemini' ? providers.gemini : providers.claude;

  function openProject(id) { setActiveProjectId(id); setView('workflow'); }

  return (
    <div className="min-h-full">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-[1040px] flex-wrap items-center justify-between gap-3 px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-600 text-lg font-black text-white">G</div>
            <div>
              <div className="text-lg font-extrabold leading-tight text-slate-800">GN Content Tool</div>
              <div className="text-[11px] text-slate-400">Chuyên viết content · v4.6</div>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-500">Nhân viên</span>
              <Input className="w-40" value={employee} onChange={(e) => setEmployee(e.target.value)} placeholder="Tên của bạn" />
            </div>
            <button
              onClick={() => setShowSettings(true)}
              title="Đổi nhà cung cấp AI / nhập key"
              className={`rounded-lg border px-3 py-2 text-sm font-semibold ${providerHasKey ? 'border-emerald-300 bg-emerald-50 text-emerald-700' : 'border-rose-300 bg-rose-50 text-rose-700'}`}
            >
              AI: {PROV_LABEL[provider] || provider} {providerHasKey ? '●' : '(chưa có key)'}
            </button>
            {isDesktop && (
              <Button variant="success" onClick={doUpdate} title="Cập nhật bản mới từ file zip trong Downloads">
                ⬆ Cập nhật
              </Button>
            )}
            <Button variant="secondary" onClick={() => setShowSettings(true)}>⚙ Cài đặt</Button>
          </div>
        </div>
        <div className="mx-auto flex max-w-[1040px] gap-1 px-5">
          {[['projects', 'Dự án'], ['templates', 'Mẫu content'], ['logs', 'Nhật ký']].map(([k, lbl]) => (
            <button key={k} onClick={() => { setView(k); }}
              className={`-mb-px border-b-2 px-4 py-2.5 text-sm font-semibold ${view === k || (k === 'projects' && view === 'workflow') ? 'border-indigo-600 text-indigo-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
              {lbl}
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-[1040px] px-5 py-6">
        {!anyKey && (
          <div className="mb-4 flex items-center justify-between gap-3 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-800">
            <span>Chưa cấu hình API key. Mở Cài đặt để nhập key (Claude / Gemini / Custom).</span>
            <Button variant="secondary" onClick={() => setShowSettings(true)}>Mở Cài đặt</Button>
          </div>
        )}

        {view === 'templates' && <TemplateManager notify={notify} onChanged={reloadTemplates} />}

        {view === 'logs' && <LogPanel notify={notify} />}

        {view === 'projects' && (
          <ProjectList templates={templates} employee={employee} onOpen={openProject} notify={notify} refreshKey={refreshKey} />
        )}

        {view === 'workflow' && activeProjectId && (
          <ProjectWorkflow
            projectId={activeProjectId}
            provider={provider}
            notify={notify}
            onBack={() => { setView('projects'); setRefreshKey((k) => k + 1); }}
            onChanged={() => setRefreshKey((k) => k + 1)}
          />
        )}
      </main>

      <SettingsDialog open={showSettings} onClose={() => setShowSettings(false)} provider={provider}
        onProviderChange={(p) => setProvider(p)} notify={notify} />
      <Toast toast={toast} />
    </div>
  );
}
