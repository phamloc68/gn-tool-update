// The 4-step project workflow with auto data-flow and progress bar.
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../api';
import { resolveVars } from '../resolve';
import { Button, Card, Field, Input, Textarea, Select, Badge, Spinner } from './ui.jsx';
import OutputBox from './OutputBox.jsx';

const FACT_LOCK = `FACT CONSISTENCY LOCK:
- Before writing, fix ONE canonical value for every recurring fact (revenues, match counts, attendance, dates, quantities).
- Whenever a fact is repeated anywhere in the script, it must match its canonical value EXACTLY.
- In the final pass, cross-check every number that appears more than once.`;


const STEP_DEFS = [
  ['content', 'CONTENT', 'status_content'],
];
const STATUS_LABEL = { todo: 'Chưa làm', doing: 'Đang làm', done: 'Hoàn thành', skipped: 'Bỏ qua' };
const STATUS_TONE = { todo: 'slate', doing: 'amber', done: 'green', skipped: 'indigo' };

function ProgressBar({ project }) {
  return (
    <div className="flex items-center gap-2">
      {STEP_DEFS.map(([key, label, sk], i) => {
        const st = project[sk] || 'todo';
        const tone = STATUS_TONE[st];
        const color = { slate: 'bg-slate-200 text-slate-500', amber: 'bg-amber-100 text-amber-700', green: 'bg-emerald-100 text-emerald-700', indigo: 'bg-indigo-100 text-indigo-700' }[tone];
        return (
          <React.Fragment key={key}>
            <div className={`flex-1 rounded-lg px-2 py-2 text-center text-xs font-bold ${color}`}>
              {i + 1}. {label}
              <div className="text-[10px] font-medium">{STATUS_LABEL[st]}</div>
            </div>
            {i < STEP_DEFS.length - 1 && <span className="text-slate-300">→</span>}
          </React.Fragment>
        );
      })}
    </div>
  );
}

function StepCard({ n, title, status, warn, children }) {
  return (
    <Card title={`Bước ${n} — ${title}`} right={<Badge tone={STATUS_TONE[status] || 'slate'}>{STATUS_LABEL[status] || 'Chưa làm'}</Badge>}>
      {warn && (
        <div className="mb-3 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-sm font-medium text-amber-800">
          ⚠ {warn}
        </div>
      )}
      {children}
    </Card>
  );
}

function parseTitles(text) {
  return String(text || '')
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => l.replace(/^\s*(\d+[.)]\s*|[-*•]\s*)/, '').trim())
    .filter((l) => l.length > 3)
    .slice(0, 40);
}

// Extract Bible verse references ("John 3:16", "1 Corinthians 13:4", "Psalm 4:8")
// so the engine can forbid re-quoting them in later sections.
function extractVerseRefs(text) {
  const out = [];
  const re = /\b((?:[123]\s+)?[A-Z][a-z]+)\s+(\d{1,3}):(\d{1,3})(?:[-\u2013]\d{1,3})?\b/g;
  let m;
  while ((m = re.exec(String(text || ''))) !== null) {
    out.push({ ref: `${m[1]} ${m[2]}:${m[3]}`, book: m[1].trim() });
  }
  return out;
}

function sanitizeStyle(text) {
  return String(text || '')
    .split(/\r?\n/)
    .filter((ln) => !/fill before running|begin now with step\s*1|bullet outline only|the\s+\d*-?bullet outline|=\s*\(the subject of tonight|awaiting\s*"?continue|two-step workflow|reply first with|stop\.?\s*wait for|wait for my ["“]?continue/i.test(ln))
    .join('\n');
}
function sectionsFromLength(len) {
  const words = wordsFromLength(len);
  return Math.max(3, Math.min(25, Math.round(words / 1300)));
}
function wordsFromLength(len) {
  const s = String(len || '').toLowerCase();
  const wm = s.match(/([\d.,]+)\s*(words?|từ|từ\.)/);
  if (wm) { const n = Number(wm[1].replace(/[.,]/g, '')); if (n > 0) return n; }
  if (/3\s*hour|3\s*giờ/.test(s)) return 26000;
  if (/2\s*hour|2\s*giờ/.test(s)) return 18000;
  if (/1\s*hour|1\s*giờ/.test(s)) return 8500;
  const mm = s.match(/(\d+)\s*(phút|min|minute)/);
  if (mm) return Number(mm[1]) * 140;
  const m = s.match(/(\d+)/);
  if (m) { const n = Number(m[1]); if (n <= 200) return n * 140; if (n > 200) return n; }
  return 9000;
}

// Force the model to output entirely in the chosen language, regardless of the
// prompt/template being written in English. Placed first AND last in every call.
function langLock(lang) {
  const L = (lang || 'English').trim();
  return `LANGUAGE LOCK (HIGHEST PRIORITY): Write the ENTIRE output in ${L}. Every sentence — including any title, label, or heading the format requires — must be written in ${L}. The instructions below may be in English or Vietnamese; that is only guidance. Your written script itself must be 100% in ${L}. Do not output any other language (no English unless ${L} is English), and do not translate or restate these instructions.`;
}
function langTail(lang) {
  const L = (lang || 'English').trim();
  return `FINAL REMINDER: Output the script ONLY in ${L}. If you notice any sentence not in ${L}, rewrite it in ${L} before finishing.`;
}

export default function ProjectWorkflow({ projectId, provider, notify, onBack, onChanged }) {
  const [project, setProject] = useState(null);
  const [template, setTemplate] = useState(null);
  const [loading, setLoading] = useState('');
  const [status, setStatus] = useState('');
  const [summary, setSummary] = useState('');
  const pending = useRef({});
  const timer = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const p = await api.getProject(projectId);
        setProject(p);
        setSummary((p.content || '').slice(0, 600));
        if (p.template_id) {
          try { setTemplate(await api.getTemplate(p.template_id)); } catch (_) { setTemplate(null); }
        }
      } catch (e) { notify(e.message, 'error'); }
    })();
    // eslint-disable-next-line
  }, [projectId]);

  function patchProject(patch) {
    setProject((p) => ({ ...p, ...patch }));
    pending.current = { ...pending.current, ...patch };
    clearTimeout(timer.current);
    timer.current = setTimeout(async () => {
      const toSave = pending.current; pending.current = {};
      try { await api.updateProject(projectId, toSave); onChanged?.(); } catch (_) {}
    }, 700);
  }

  async function run(stepName, promptText, ctx, busyMsg) {
    if (!template) return notify('Project chưa gắn mẫu content hợp lệ.', 'error');
    if (!promptText || !promptText.trim()) return notify('Prompt của bước này đang trống trong mẫu content.', 'error');
    const resolvedPrompt = resolveVars(promptText, ctx);
    setLoading(stepName); setStatus(busyMsg);
    try {
      const r = await api.runStep(projectId, { stepName, resolvedPrompt, provider });
      setProject(r.project);
      setStatus('✅ Đã tạo xong');
      notify('Đã tạo xong.', 'success');
      onChanged?.();
    } catch (e) {
      setStatus(''); notify(e.message, 'error');
    } finally { setLoading(''); }
  }

  if (!project) return <Card><div className="flex items-center gap-2 text-slate-500"><Spinner /> Đang tải project…</div></Card>;

  const effectiveTitle = project.selected_title || project.manual_title || '';
  // Story scripts use a FIXED 45-60 min length (~7,500 words) regardless of the
  // dropdown, so every Story episode comes out the same length.
  const isStory = (template?.name || project.template_name || '').trim().toLowerCase() === 'story';
  const STORY_FIXED_LEN = '7500 words';
  const noTemplate = !template;
  const tplName = project.template_name || 'mẫu content';
  const warnFor = (key) =>
    template && !((template[key] || '').trim())
      ? `Mẫu "${tplName}" chưa có prompt cho bước này. Mở tab "Mẫu content" → Sửa mẫu để điền (hoặc tạo project mới với mẫu "Boring History").`
      : null;

  // Build the CONTENT prompt with the authoritative instruction FIRST, so even a
  // two-step "outline only / fill before running" template still writes the full script.
  function buildContentPrompt() {
    const title = effectiveTitle;
    const topic = project.topic;
    const lang = project.language || 'the requested language';
    const len = project.length || 'a suitable length';
    const styleGuide = sanitizeStyle(resolveVars(template?.content_prompt || '', {
      topic, title, language: project.language, length: project.length, notes: project.notes,
      script: '', visualType: '', promptCount: '', characterAction: '',
    }));
    const head = langLock(lang) + '\n\n' +
      `TASK: Write the COMPLETE bedtime-history narration script for tonight's episode, in ${lang}, about ${len} long.\n` +
      `SUBJECT: "${title}"` + (topic && topic !== title ? ` (general channel/topic: ${topic})` : '') + `. Use exactly this subject; do NOT ask me to provide a topic, and do NOT translate or restate this line back to me.\n` +
      `NOTES: ${project.notes || '(none)'}\n\n` +
      `RULES (highest priority - override anything below): Write the entire script in full, right now, in ONE response, all sections in order, ending with a calm wind-down. IGNORE any instruction in the STYLE GUIDE below that says to only produce an outline, to "fill before running", to wait for "CONTINUE", or to ask me for the subject.\n\n` +
      FACT_LOCK + `\n\n` +
      `=== STYLE GUIDE (match this tone & structure, but write the full script now) ===\n`;
    return head + styleGuide;
  }

  // Generate ONE complete script (chunked). prefix = text already written before
  // it (for live display); directives = batch/anti-dup instructions injected everywhere.
  async function generateOneScript({ scriptTitle, len, directives, prefix, stepBase, labelPrefix }) {
    const lang = project.language || 'English';
    const topic = project.topic;
    const styleGuide = sanitizeStyle(resolveVars(template?.content_prompt || '', {
      topic, title: scriptTitle, language: lang, length: len, notes: project.notes,
      script: '', visualType: '', promptCount: '', characterAction: '',
    }));
    const dir = directives ? directives + '\n\n' : '';

    // SHORT content (<= ~2800 words): write in ONE clean call so the template's
    // exact structure / labels / output sections stay intact. Anything longer is
    // chunked into smaller sections so each gateway call finishes well under its
    // upstream timeout (a single ~4000+ word generation makes the gateway give up).
    if (wordsFromLength(len) <= 2800) {
      setStatus(`${labelPrefix}Đang viết…`);
      const prompt = langLock(lang) + '\n\n' + dir +
        `Viết HOÀN CHỈNH ngay trong MỘT lần trả lời, bằng ${lang}, độ dài mục tiêu ${len || 'theo hướng dẫn'}. ` +
        `Bám SÁT hướng dẫn dưới đây: đúng cấu trúc, đúng các phần và nhãn mà phần đầu ra yêu cầu, và mọi quy tắc. Chỉ xuất đúng những gì hướng dẫn yêu cầu, không thêm lời dẫn ngoài.\n\n=== HƯỚNG DẪN ===\n` +
        styleGuide + `\n\n${langTail(lang)}`;
      const r = await api.llmCall(projectId, { resolvedPrompt: prompt, provider, step: stepBase });
      const txt = (r.output || '').trim();
      patchProject({ content: prefix + txt });
      return txt;
    }

    const N = sectionsFromLength(len);
    setStatus(`${labelPrefix}Đang lập dàn ý (${N} phần)…`);
    const outlinePrompt = langLock(lang) + '\n\n' +
      `${dir}You are planning a script titled "${scriptTitle}"` +
      (topic && topic !== scriptTitle ? ` (general topic: ${topic})` : '') +
      ` in ${lang}, target length ${len || 'medium'}.\n` +
      `If the STYLE GUIDE below defines an exact section structure, output THAT exact outline. Otherwise produce a numbered outline of about ${N} sections.\n` +
      `Each line: "n. <short section title> — <one-sentence teaser>". Output ONLY the numbered list.\n\nSTYLE GUIDE:\n` + styleGuide.slice(0, 6000);
    const outlineRes = await api.llmCall(projectId, { resolvedPrompt: outlinePrompt, provider, step: stepBase + '-outline' });
    const secs = parseTitles(outlineRes.output);

    let factSheet = '';
    if (secs.length >= 2) {
      try {
        setStatus(`${labelPrefix}Đang chốt số liệu…`);
        const factPrompt = `${dir}Prepare a CONSISTENCY SHEET for the script titled "${scriptTitle}" (topic: ${topic}) in ${lang}. List (1) EVERY named character with ONE fixed name and their role — one name per character, no variants; and (2) any key recurring facts, objects, places, dates or amounts, each with ONE canonical value. Format one per line "item — canonical value". Output ONLY the list.`;
        const fr = await api.llmCall(projectId, { resolvedPrompt: factPrompt, provider, step: stepBase + '-facts' });
        factSheet = (fr.output || '').trim();
      } catch (_) {}
    }

    let scriptText = '';
    const usedRefs = [];
    const usedBooks = new Set();
    if (secs.length < 2) {
      setStatus(`${labelPrefix}Đang viết…`);
      const r = await api.llmCall(projectId, { resolvedPrompt: dir + buildContentPrompt(), provider, step: stepBase });
      scriptText = (r.output || '').trim();
      patchProject({ content: prefix + scriptText });
    } else {
      const per = Math.min(1400, Math.max(300, Math.round(wordsFromLength(len) / secs.length)));
      for (let i = 0; i < secs.length; i++) {
        setStatus(`${labelPrefix}Đang viết phần ${i + 1}/${secs.length}…`);
        const tail = scriptText.slice(-1500);
        const opening = i === 0;
        const finalPart = i === secs.length - 1;
        const secPrompt = [
          langLock(lang),
          dir + `You are writing ONE continuous script in ${lang}, titled "${scriptTitle}"` + (topic && topic !== scriptTitle ? ` (topic: ${topic})` : '') + `. This is part ${i + 1} of ${secs.length}. Theme of this part: "${secs[i]}".`,
          `FOLLOW THE STYLE GUIDE below EXACTLY — its voice, structure, output format, banned words, CTAs, and any rules it assigns to this specific section number.`,
          `Length: about ${per} words for this part, UNLESS the style guide specifies a different word count — then follow the style guide.`,
          opening ? `This is the OPENING part: follow the style guide's opening rules.` : `This is a LATER part: do not re-open the script; include a CTA only if the style guide assigns one to this section.`,
          finalPart ? `This is the FINAL part: include the script's closing exactly as the style guide specifies (wind-down, benediction, CTA).` : '',
          `CONTINUITY: continue smoothly from the text below; do NOT re-introduce the topic, do NOT repeat earlier content, do NOT write other parts, do NOT output an outline.`,
          `OUTLINE (context only, do NOT print it):\n${outlineRes.output}`,
          usedRefs.length ? `SCRIPTURE LEDGER — these verses were ALREADY quoted verbatim earlier; do NOT quote any of them verbatim again (a short paraphrase without quotation marks is allowed at most once). For any new point, quote from a DIFFERENT book than these. Already quoted: ${usedRefs.join('; ')}. Books already used: ${[...usedBooks].join(', ')}.` : '',
          factSheet ? `CONSISTENCY SHEET — use EXACTLY these character names (one name per character, never a variant) and canonical values every time they appear:\n${factSheet}` : FACT_LOCK,
          tail ? `END OF TEXT SO FAR (continue right after this):\n...${tail}` : '',
          `STYLE GUIDE (follow exactly):\n${styleGuide.slice(0, 6000)}`,
          `BEFORE DELIVERING, silently confirm this part follows the style guide, every repeated fact matches the fact sheet, AND the whole part is written in ${lang}. Then output ONLY the script text of this part.`,
          langTail(lang),
        ].filter(Boolean).join('\n\n');
        const r = await api.llmCall(projectId, { resolvedPrompt: secPrompt, provider, step: `${stepBase}-s${i + 1}` });
        const sectionText = (r.output || '').trim();
        scriptText += (scriptText ? '\n\n' : '') + sectionText;
        for (const v of extractVerseRefs(sectionText)) { if (!usedRefs.includes(v.ref)) usedRefs.push(v.ref); usedBooks.add(v.book); }
        patchProject({ content: prefix + scriptText });
      }
    }
    return scriptText;
  }

  function parseBatchPlan(text, n) {
    const lines = String(text || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const specs = [];
    for (const ln of lines) {
      if (!/title\s*:/i.test(ln)) continue;
      const g = (re) => { const m = ln.match(re); return m ? m[1].trim() : ''; };
      specs.push({
        title: g(/title\s*:\s*([^|]+)/i),
        motif: g(/motif\s*:\s*([^|]+)/i),
        verse: g(/verse\s*:\s*([^|]+)/i),
        story: g(/story\s*:\s*([^|]+)/i),
      });
    }
    return specs.slice(0, n);
  }

  async function writeContent() {
    if (!template) return notify('Project chưa gắn mẫu content hợp lệ.', 'error');
    const baseTitle = effectiveTitle || project.topic;
    if (!baseTitle) return notify('Cần có Chủ đề hoặc Tiêu đề trước khi viết content.', 'error');
    const lang = project.language || 'English';
    const N = Math.max(1, Math.min(8, parseInt(project.batch_count || '1', 10) || 1));
    const perLen = isStory ? STORY_FIXED_LEN : (project.length || (N > 1 ? '4000 words' : 'medium'));
    setLoading('content');
    let full = '';
    patchProject({ content: '', status_content: 'doing' });
    try {
      if (N <= 1) {
        full = await generateOneScript({ scriptTitle: baseTitle, len: perLen, directives: '', prefix: '', stepBase: 'content', labelPrefix: '' });
      } else {
        setStatus(`Đang lập kế hoạch lô ${N} bài…`);
        const planPrompt =
          `Plan a batch of ${N} INDEPENDENT, standalone scripts in ${lang} on the big theme "${baseTitle}" (topic: ${project.topic}). ` +
          `They will be joined back-to-back into one long video, so each must be distinct. ` +
          `For each script give: a unique video Title (6-12 words), a distinct opening Motif/central image, a distinct anchor Bible Verse (KJV book chapter:verse), and a distinct Testimony character/setting (no real names). ` +
          `Make all four fields DIFFERENT across the ${N} scripts (no repeated motif, verse, or story). ` +
          `Output EXACTLY ${N} lines, one per script, strictly in this format and nothing else:\n` +
          `1 | Title: ... | Motif: ... | Verse: ... | Story: ...`;
        const planRes = await api.llmCall(projectId, { resolvedPrompt: planPrompt, provider, step: 'batch-plan' });
        let specs = parseBatchPlan(planRes.output, N);
        for (let k = specs.length; k < N; k++) specs.push({ title: `${baseTitle} — Part ${k + 1}`, motif: '', verse: '', story: '' });
        const usedMotif = [], usedVerse = [], usedStory = [];
        for (let k = 0; k < N; k++) {
          const sp = specs[k];
          const scriptTitle = sp.title || `${baseTitle} — Part ${k + 1}`;
          const directives =
            `BATCH CONTEXT: This is script ${k + 1} of ${N} in a batch on the theme "${baseTitle}". This script is fully STANDALONE — never reference the other scripts. ` +
            (sp.motif ? `Use THIS opening motif/central image and no other: ${sp.motif}. ` : '') +
            (sp.verse ? `Use THIS anchor Bible verse (KJV): ${sp.verse}. ` : '') +
            (sp.story ? `Use THIS testimony character/setting (no real names): ${sp.story}. ` : '') +
            `Do NOT reuse anything from earlier scripts — earlier motifs: ${usedMotif.join('; ') || 'none'}; earlier verses: ${usedVerse.join('; ') || 'none'}; earlier stories: ${usedStory.join('; ') || 'none'}.`;
          const header = `=== SCRIPT ${k + 1}/${N}: ${scriptTitle} ===\n`;
          const prefix = full + (full ? '\n\n\n' : '') + header;
          patchProject({ content: prefix });
          const scriptText = await generateOneScript({ scriptTitle, len: perLen, directives, prefix, stepBase: `batch-${k + 1}`, labelPrefix: `Bài ${k + 1}/${N} — ` });
          full = prefix + scriptText;
          patchProject({ content: full });
          if (sp.motif) usedMotif.push(sp.motif);
          if (sp.verse) usedVerse.push(sp.verse);
          if (sp.story) usedStory.push(sp.story);
        }
      }
      await api.updateProject(projectId, { content: full, status_content: 'done' });
      setProject((p) => ({ ...p, content: full, status_content: 'done' }));
      setStatus('✅ Đã viết xong content');
      notify('Đã viết xong content.', 'success');
      onChanged?.();
    } catch (e) {
      if (full) { try { await api.updateProject(projectId, { content: full }); setProject((p) => ({ ...p, content: full })); } catch (_) {} }
      setStatus('');
      notify(e.message, 'error');
    } finally {
      setLoading('');
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <Button variant="ghost" onClick={onBack}>← Danh sách dự án</Button>
          <h2 className="mt-1 text-xl font-bold text-slate-800">{project.name}</h2>
          <p className="text-sm text-slate-500">{project.topic} · {project.template_name} · {project.language} · {project.length}</p>
        </div>
        <Button variant="success" onClick={() => api.exportFull(project.id)}>⬇ Tải full package .docx</Button>
      </div>

      <Card><ProgressBar project={project} /></Card>

      {noTemplate && <div className="rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-800">Không tìm thấy mẫu content của project (có thể đã bị xoá). Hãy tạo lại mẫu hoặc project.</div>}



      {/* STEP 1 — CONTENT */}
      <StepCard n={1} title="CONTENT — Viết content" status={project.status_content} warn={warnFor('content_prompt')}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Chủ đề"><Input value={project.topic} onChange={(e) => patchProject({ topic: e.target.value })} /></Field>
          <Field label="Tiêu đề dùng cho content"><Input value={effectiveTitle} onChange={(e) => patchProject({ selected_title: e.target.value })} /></Field>
          <Field label="Độ dài">
            {isStory ? (
              <Input value="Cố định 45–60 phút (~7.500 từ)" readOnly className="bg-slate-50 text-slate-500" />
            ) : (
              <Select value={project.length} onChange={(e) => patchProject({ length: e.target.value })}>
                <option>khoảng 30 phút</option>
                <option>khoảng 60 phút</option>
                <option>khoảng 2 giờ</option>
              </Select>
            )}
          </Field>
          <Field label="Ngôn ngữ">
            <Select value={project.language} onChange={(e) => patchProject({ language: e.target.value })}>
              <option value="English">Tiếng Anh (English)</option>
              <option value="Spanish">Tiếng Tây Ban Nha (Español)</option>
              <option value="German">Tiếng Đức (Deutsch)</option>
              <option value="Japanese">Tiếng Nhật (日本語)</option>
              <option value="Korean">Tiếng Hàn (한국어)</option>
              <option value="Portuguese">Tiếng Bồ Đào Nha (Português)</option>
              <option value="Vietnamese">Tiếng Việt</option>
            </Select>
          </Field>
          <Field label="Ghi chú / yêu cầu thêm">
            <Input value={project.notes || ''} onChange={(e) => patchProject({ notes: e.target.value })} placeholder="VD: giọng ASMR, tránh chính trị…" />
          </Field>
        </div>
        <div className="my-3">
          <Button size="lg" disabled={loading || noTemplate} onClick={writeContent}>
            {loading === 'content' ? <Spinner light /> : '📝'} Viết content
          </Button>
        </div>
        <OutputBox title={`${project.name}-content`} value={project.content} onChange={(v) => { patchProject({ content: v }); }} rows={16} placeholder="Content/script sẽ hiện ở đây — có thể sửa trực tiếp." />
        <p className="mt-1 text-xs text-slate-500">Content này tự động dùng cho bước Visual và Thumbnail.</p>
      </StepCard>





      {status && <div className="rounded-xl bg-slate-800 px-4 py-2 text-center text-sm font-medium text-white">{loading ? <span className="inline-flex items-center gap-2"><Spinner light /> {status}</span> : status}</div>}
    </div>
  );
}
