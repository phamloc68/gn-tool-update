// Project list + create-new-project modal.
import React, { useEffect, useState } from 'react';
import { api } from '../api';
import { Button, Card, Field, Input, Textarea, Select, Modal, Spinner, Badge } from './ui.jsx';

const STEPS = [
  ['status_content', 'CONTENT'],
];
const STATUS_TONE = { todo: 'slate', doing: 'amber', done: 'green', skipped: 'slate' };

function NewProject({ open, onClose, templates, employee, onCreated, notify }) {
  const [f, setF] = useState({ name: '', topic: '', template_id: '', has_title: true, manual_title: '', length: 'khoảng 30 phút', language: 'English', notes: '', batch_count: '1' });
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  useEffect(() => { if (open) setF({ name: '', topic: '', template_id: templates[0]?.id || '', has_title: true, manual_title: '', length: 'khoảng 30 phút', language: 'English', notes: '', batch_count: '1' }); }, [open, templates]);

  async function create() {
    if (!f.name.trim()) return notify('Cần nhập tên project.', 'error');
    if (!f.template_id) return notify('Vui lòng chọn mẫu content trước.', 'error');
    setSaving(true);
    try {
      const tpl = templates.find((t) => String(t.id) === String(f.template_id));
      const p = await api.createProject({ ...f, template_id: Number(f.template_id), template_name: tpl?.name || '', employee });
      notify('Đã tạo project.', 'success'); onCreated(p); onClose();
    } catch (e) { notify(e.message, 'error'); } finally { setSaving(false); }
  }

  return (
    <Modal open={open} onClose={onClose} title="Tạo project mới" maxWidth="max-w-xl">
      <div className="space-y-3">
        <Field label="Tên project"><Input value={f.name} onChange={set('name')} placeholder="VD: Video tháng 6 — Peasants Winter" /></Field>
        <Field label="Chọn mẫu content (Master Prompt Template)">
          <Select value={f.template_id} onChange={set('template_id')}>
            <option value="">— Chọn mẫu —</option>
            {templates.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </Select>
        </Field>
        <Field label="Chủ đề video"><Input value={f.topic} onChange={set('topic')} placeholder="VD: peasants surviving a Little Ice Age winter" /></Field>

        <Field label="Tiêu đề video">
          <Input value={f.manual_title} onChange={set('manual_title')} placeholder="Nhập tiêu đề video (dùng cho content + thumbnail)" />
        </Field>

        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Độ dài content">
            <Select value={f.length} onChange={set('length')}>
              <option>khoảng 30 phút</option>
              <option>khoảng 60 phút</option>
              <option>khoảng 2 giờ</option>
            </Select>
          </Field>
          <Field label="Ngôn ngữ">
            <Select value={f.language} onChange={set('language')}>
              <option value="English">Tiếng Anh (English)</option>
              <option value="Spanish">Tiếng Tây Ban Nha (Español)</option>
              <option value="German">Tiếng Đức (Deutsch)</option>
              <option value="Japanese">Tiếng Nhật (日本語)</option>
              <option value="Korean">Tiếng Hàn (한국어)</option>
              <option value="Vietnamese">Tiếng Việt</option>
            </Select>
          </Field>
        </div>
        <Field label="Số kịch bản trong lô" hint="1 = viết 1 bài. >1 = viết nhiều bài độc lập cùng chủ đề để ghép thành video dài (vd 4). Chỉ hợp với mẫu kiểu sermon.">
          <Input type="number" min="1" max="8" value={f.batch_count} onChange={set('batch_count')} placeholder="1" />
        </Field>
        <Field label="Ghi chú / yêu cầu thêm"><Textarea rows={2} value={f.notes} onChange={set('notes')} placeholder="VD: giọng ASMR, tránh chính trị…" /></Field>
      </div>
      <div className="mt-5 flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>Huỷ</Button>
        <Button onClick={create} disabled={saving}>{saving && <Spinner light />} Tạo project</Button>
      </div>
    </Modal>
  );
}

export default function ProjectList({ templates, employee, onOpen, notify, refreshKey }) {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);

  async function load() { try { setItems(await api.listProjects()); } catch (e) { notify(e.message, 'error'); } }
  useEffect(() => { load(); }, [refreshKey]);

  async function remove(id, name) {
    if (!confirm(`Xoá project "${name}"?`)) return;
    try { await api.deleteProject(id); load(); } catch (e) { notify(e.message, 'error'); }
  }

  return (
    <Card title="Dự án của bạn" right={<Button onClick={() => { if (!templates.length) return notify('Hãy tạo ít nhất 1 mẫu content trước.', 'error'); setOpen(true); }}>+ Tạo project mới</Button>}>
      {items.length === 0 && <p className="text-sm text-slate-500">Chưa có project nào. Bấm “+ Tạo project mới” để bắt đầu.</p>}
      <div className="space-y-2.5">
        {items.map((p) => (
          <div key={p.id} className="rounded-xl border border-slate-200 p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="font-semibold text-slate-800">{p.name}</div>
                <div className="text-xs text-slate-500">{p.topic || '—'} · {p.template_name || '—'}{p.employee ? ` · ${p.employee}` : ''}</div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {STEPS.map(([k, lbl]) => <Badge key={k} tone={STATUS_TONE[p[k]] || 'slate'}>{lbl}</Badge>)}
                </div>
              </div>
              <div className="flex shrink-0 flex-col gap-2 sm:flex-row">
                <Button onClick={() => onOpen(p.id)}>Mở</Button>
                <Button variant="ghost" onClick={() => api.exportFull(p.id)}>Tải full .docx</Button>
                <Button variant="ghost" onClick={() => remove(p.id, p.name)}>Xoá</Button>
              </div>
            </div>
          </div>
        ))}
      </div>
      <NewProject open={open} onClose={() => setOpen(false)} templates={templates} employee={employee} onCreated={(p) => { load(); onOpen(p.id); }} notify={notify} />
    </Card>
  );
}
