// SQLite database using sql.js (WASM) — pure JS, no native build.
// Schema: templates (4 explicit prompts) + projects (4-step workflow).
const path = require('path');
const fs = require('fs');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'pipeline.db');

let DB = null;

const SCHEMA = `
CREATE TABLE IF NOT EXISTS templates (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  name            TEXT NOT NULL,
  niche           TEXT DEFAULT '',
  title_prompt    TEXT DEFAULT '',
  content_prompt  TEXT DEFAULT '',
  visual_prompt   TEXT DEFAULT '',
  thumbnail_prompt TEXT DEFAULT '',
  created_at      TEXT NOT NULL,
  updated_at      TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS projects (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  name             TEXT NOT NULL,
  topic            TEXT DEFAULT '',
  has_title        INTEGER DEFAULT 0,
  manual_title     TEXT DEFAULT '',
  length           TEXT DEFAULT '',
  language         TEXT DEFAULT '',
  notes            TEXT DEFAULT '',
  template_id      INTEGER,
  template_name    TEXT DEFAULT '',
  employee         TEXT DEFAULT '',
  titles_output    TEXT DEFAULT '',
  selected_title   TEXT DEFAULT '',
  content          TEXT DEFAULT '',
  visual_type      TEXT DEFAULT 'image',
  prompt_count     TEXT DEFAULT '',
  batch_count      TEXT DEFAULT '1',
  character_action TEXT DEFAULT '',
  visual_image     TEXT DEFAULT '',
  visual_veo       TEXT DEFAULT '',
  thumbnail_prompt TEXT DEFAULT '',
  status_title     TEXT DEFAULT 'todo',
  status_content   TEXT DEFAULT 'todo',
  status_visual    TEXT DEFAULT 'todo',
  status_thumbnail TEXT DEFAULT 'todo',
  created_at       TEXT NOT NULL,
  updated_at       TEXT NOT NULL
);
`;

const now = () => new Date().toISOString();

async function init() {
  if (DB) return module.exports;
  const initSqlJs = require('sql.js');
  const wasmPath = require.resolve('sql.js/dist/sql-wasm.wasm');
  const SQL = await initSqlJs({ locateFile: () => wasmPath });
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  DB = fs.existsSync(DB_FILE)
    ? new SQL.Database(fs.readFileSync(DB_FILE))
    : new SQL.Database();
  DB.run('PRAGMA journal_mode = MEMORY;');
  DB.exec(SCHEMA);
  migrate(); // add any columns missing from older databases
  seedDefaults(); // one-time built-in templates
  persist();
  return module.exports;
}


// Non-destructive migration: add columns that older DB versions are missing.
function ensureColumns(table, cols) {
  let existing = [];
  try {
    existing = all(`PRAGMA table_info(${table})`).map((r) => r.name);
  } catch (_) {
    return;
  }
  for (const [name, decl] of Object.entries(cols)) {
    if (!existing.includes(name)) {
      try { DB.run(`ALTER TABLE ${table} ADD COLUMN ${name} ${decl}`); } catch (_) {}
    }
  }
}

function migrate() {
  ensureColumns('templates', {
    niche: "TEXT DEFAULT ''",
    title_prompt: "TEXT DEFAULT ''",
    content_prompt: "TEXT DEFAULT ''",
    visual_prompt: "TEXT DEFAULT ''",
    thumbnail_prompt: "TEXT DEFAULT ''",
  });
  ensureColumns('projects', {
    topic: "TEXT DEFAULT ''",
    has_title: 'INTEGER DEFAULT 0',
    manual_title: "TEXT DEFAULT ''",
    length: "TEXT DEFAULT ''",
    language: "TEXT DEFAULT ''",
    notes: "TEXT DEFAULT ''",
    template_id: 'INTEGER',
    template_name: "TEXT DEFAULT ''",
    employee: "TEXT DEFAULT ''",
    titles_output: "TEXT DEFAULT ''",
    selected_title: "TEXT DEFAULT ''",
    content: "TEXT DEFAULT ''",
    visual_type: "TEXT DEFAULT 'image'",
    prompt_count: "TEXT DEFAULT ''",
    batch_count: "TEXT DEFAULT '1'",
    character_action: "TEXT DEFAULT ''",
    visual_image: "TEXT DEFAULT ''",
    visual_veo: "TEXT DEFAULT ''",
    thumbnail_prompt: "TEXT DEFAULT ''",
    status_title: "TEXT DEFAULT 'todo'",
    status_content: "TEXT DEFAULT 'todo'",
    status_visual: "TEXT DEFAULT 'todo'",
    status_thumbnail: "TEXT DEFAULT 'todo'",
  });
}


// Seed built-in starter templates ONCE (so deleting them won't re-add them).
function seedDefaults() {
  try {
    const seeds = require('./lib/seedTemplates');
    const KEYS = ['title_prompt', 'content_prompt', 'visual_prompt', 'thumbnail_prompt'];
    const everSeeded =
      fs.existsSync(path.join(DATA_DIR, '.seeded_v1')) ||
      fs.existsSync(path.join(DATA_DIR, '.seeded_v2')) ||
      fs.existsSync(path.join(DATA_DIR, '.seeded'));
    const verMarker = path.join(DATA_DIR, '.seed_v25');
    const refreshDone = fs.existsSync(verMarker);
    const existing = all('SELECT * FROM templates');
    for (const t of seeds) {
      const slug = t.name.toLowerCase().replace(/[^a-z0-9]+/g, '_');
      const tplMarker = path.join(DATA_DIR, '.seeded_tpl_' + slug);
      const ex = existing.find((e) => e.name === t.name);
      if (ex) {
        const needsHeal = KEYS.some((k) => !((ex[k] || '').trim()));
        if (!refreshDone || needsHeal) templates.update(ex.id, t);
        try { fs.writeFileSync(tplMarker, new Date().toISOString()); } catch (_) {}
      } else {
        // Respect deliberate deletion: only create if this template was never seeded.
        const wasSeeded = fs.existsSync(tplMarker) || (t.name === 'Boring History' && everSeeded);
        if (!wasSeeded) {
          templates.create(t);
          try { fs.writeFileSync(tplMarker, new Date().toISOString()); } catch (_) {}
        }
      }
    }
    fs.writeFileSync(path.join(DATA_DIR, '.seeded'), new Date().toISOString());
    fs.writeFileSync(verMarker, new Date().toISOString());
  } catch (_) {}
}

function persist() {
  fs.writeFileSync(DB_FILE, Buffer.from(DB.export()));
}

function bindArg(params) {
  if (params === undefined) return undefined;
  if (Array.isArray(params)) return params;
  if (params !== null && typeof params === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(params)) out['@' + k] = v;
    return out;
  }
  return [params];
}
function all(sql, params) {
  const stmt = DB.prepare(sql);
  const b = bindArg(params);
  if (b !== undefined) stmt.bind(b);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}
function get(sql, params) {
  return all(sql, params)[0];
}
function run(sql, params) {
  const stmt = DB.prepare(sql);
  const b = bindArg(params);
  if (b !== undefined) stmt.bind(b);
  stmt.step();
  stmt.free();
  const idRow = all('SELECT last_insert_rowid() AS id');
  persist();
  return { lastInsertRowid: idRow[0] ? idRow[0].id : 0, changes: DB.getRowsModified() };
}

// ---- Templates (4 explicit prompts) ----
const TEMPLATE_FIELDS = ['name', 'niche', 'title_prompt', 'content_prompt', 'visual_prompt', 'thumbnail_prompt'];
const templates = {
  all() {
    return all('SELECT * FROM templates ORDER BY updated_at DESC');
  },
  get(id) {
    return get('SELECT * FROM templates WHERE id = ?', id);
  },
  create(data) {
    const ts = now();
    const info = run(
      `INSERT INTO templates (name,niche,title_prompt,content_prompt,visual_prompt,thumbnail_prompt,created_at,updated_at)
       VALUES (@name,@niche,@title_prompt,@content_prompt,@visual_prompt,@thumbnail_prompt,@created_at,@updated_at)`,
      {
        name: data.name || 'Untitled',
        niche: data.niche || '',
        title_prompt: data.title_prompt || '',
        content_prompt: data.content_prompt || '',
        visual_prompt: data.visual_prompt || '',
        thumbnail_prompt: data.thumbnail_prompt || '',
        created_at: ts,
        updated_at: ts,
      }
    );
    return this.get(info.lastInsertRowid);
  },
  update(id, data) {
    const ex = this.get(id);
    if (!ex) return null;
    const merged = {};
    for (const f of TEMPLATE_FIELDS) merged[f] = data[f] !== undefined ? data[f] : ex[f];
    run(
      `UPDATE templates SET name=@name,niche=@niche,title_prompt=@title_prompt,content_prompt=@content_prompt,
         visual_prompt=@visual_prompt,thumbnail_prompt=@thumbnail_prompt,updated_at=@updated_at WHERE id=@id`,
      { id, ...merged, updated_at: now() }
    );
    return this.get(id);
  },
  remove(id) {
    return run('DELETE FROM templates WHERE id = ?', id);
  },
};

// ---- Projects ----
const PROJECT_UPDATABLE = [
  'name', 'topic', 'has_title', 'manual_title', 'length', 'language', 'notes',
  'template_id', 'template_name', 'employee',
  'titles_output', 'selected_title', 'content', 'visual_type', 'prompt_count',
  'character_action', 'batch_count', 'visual_image', 'visual_veo', 'thumbnail_prompt',
  'status_title', 'status_content', 'status_visual', 'status_thumbnail',
];
const projects = {
  all() {
    return all('SELECT * FROM projects ORDER BY updated_at DESC');
  },
  get(id) {
    return get('SELECT * FROM projects WHERE id = ?', id);
  },
  create(data) {
    const ts = now();
    const info = run(
      `INSERT INTO projects (name,topic,has_title,manual_title,length,language,notes,template_id,template_name,employee,
         selected_title,status_title,status_content,status_visual,status_thumbnail,visual_type,prompt_count,batch_count,created_at,updated_at)
       VALUES (@name,@topic,@has_title,@manual_title,@length,@language,@notes,@template_id,@template_name,@employee,
         @selected_title,@status_title,@status_content,@status_visual,@status_thumbnail,@visual_type,@prompt_count,@batch_count,@created_at,@updated_at)`,
      {
        name: data.name || 'Project',
        topic: data.topic || '',
        has_title: data.has_title ? 1 : 0,
        manual_title: data.manual_title || '',
        length: data.length || '',
        language: data.language || '',
        notes: data.notes || '',
        template_id: data.template_id ?? null,
        template_name: data.template_name || '',
        employee: data.employee || '',
        selected_title: data.has_title ? data.manual_title || '' : '',
        status_title: data.has_title ? 'skipped' : 'todo',
        status_content: 'todo',
        status_visual: 'todo',
        status_thumbnail: 'todo',
        visual_type: data.visual_type || 'image',
        prompt_count: data.prompt_count || '',
        batch_count: data.batch_count || '1',
        created_at: ts,
        updated_at: ts,
      }
    );
    return this.get(info.lastInsertRowid);
  },
  update(id, data) {
    const ex = this.get(id);
    if (!ex) return null;
    const sets = [];
    const params = { id, updated_at: now() };
    for (const f of PROJECT_UPDATABLE) {
      if (data[f] !== undefined) {
        sets.push(`${f}=@${f}`);
        params[f] = f === 'has_title' ? (data[f] ? 1 : 0) : data[f];
      }
    }
    sets.push('updated_at=@updated_at');
    run(`UPDATE projects SET ${sets.join(', ')} WHERE id=@id`, params);
    return this.get(id);
  },
  remove(id) {
    return run('DELETE FROM projects WHERE id = ?', id);
  },
};

module.exports = { init, persist, templates, projects };
