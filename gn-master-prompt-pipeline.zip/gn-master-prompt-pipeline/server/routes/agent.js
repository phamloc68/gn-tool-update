// Routes for the Sheet Agent. The frontend calls /next repeatedly (one title per
// call) so progress stays live and no single request runs too long.
const express = require('express');
const agent = require('../lib/agent');
const router = express.Router();

router.get('/pending', async (req, res) => {
  try {
    const rows = await agent.fetchPending(req.query.sheetUrl, req.query.token, req.query.outDir);
    res.json({ count: rows.length, rows });
  } catch (e) { res.status(500).json({ error: e.message || 'Lỗi đọc Sheet' }); }
});

router.post('/next', async (req, res) => {
  try {
    const { sheetUrl, token, provider = 'openai', model, outDir } = req.body || {};
    const r = await agent.runNext({ sheetUrl, token, provider, model, outDir });
    res.json(r);
  } catch (e) { res.status(500).json({ error: e.message || 'Agent lỗi' }); }
});

module.exports = router;
