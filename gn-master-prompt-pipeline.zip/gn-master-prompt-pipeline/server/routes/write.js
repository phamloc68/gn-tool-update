// Batch-writer routes. /templates lists template names for the dropdown;
// /one generates + saves a single script. The client calls /one in parallel.
const express = require('express');
const writer = require('../lib/writer');
const router = express.Router();

router.get('/templates', (req, res) => {
  try { res.json({ names: require('../db').templates.all().map((t) => t.name) }); }
  catch (e) { res.status(500).json({ error: e.message || 'Lỗi' }); }
});

router.post('/one', async (req, res) => {
  try {
    const { title, template, language, length, notes, provider = 'openai', model, outDir, format, index } = req.body || {};
    const r = await writer.writeOne({ title, template, language, length, notes, provider, model, outDir, format, index });
    res.json(r);
  } catch (e) { res.status(500).json({ error: e.message || 'Viết lỗi' }); }
});

module.exports = router;
