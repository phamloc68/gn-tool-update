// Builds the Express app and (optionally) starts it. Used by both the CLI
// entry point (index.js) and the Electron main process.
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const settings = require('./lib/settings');
const llm = require('./lib/llm');

function createApp() {
  settings.loadIntoEnv();

  const templatesRouter = require('./routes/templates');
  const projectsRouter = require('./routes/projects');
  const settingsRouter = require('./routes/settings');
  const logsRouter = require('./routes/logs');

  const app = express();
  app.use(cors());
  app.use(express.json({ limit: '20mb' }));
  app.use(express.urlencoded({ extended: true, limit: '20mb' }));

  app.get('/api/health', (req, res) => res.json({ ok: true, ts: Date.now() }));
  app.get('/api/providers', (req, res) => res.json(llm.availability()));

  const APP_VERSION = '6.29';
  function isNewerVersion(a, b) {
    const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0);
    const pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const x = pa[i] || 0, y = pb[i] || 0;
      if (x > y) return true;
      if (x < y) return false;
    }
    return false;
  }
  // Update-available check: compares this build's APP_VERSION against a small
  // version manifest published next to the update zip. The frontend polls this
  // and shows an "update available" banner to anyone on an older build.
  app.get('/api/version', async (req, res) => {
    const current = APP_VERSION;
    const zipUrl = process.env.UPDATE_URL
      || 'https://raw.githubusercontent.com/phamloc68/gn-tool-update/main/gn-master-prompt-pipeline.zip';
    const verUrl = zipUrl.replace(/gn-master-prompt-pipeline\.zip/i, 'gn-master-prompt-pipeline.version.json');
    let latest = null, notes = '';
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 8000);
      const r = await fetch(verUrl, { signal: ctrl.signal });
      clearTimeout(t);
      if (r && r.ok) {
        const j = await r.json();
        latest = String(j.version || '').trim();
        notes = String(j.notes || '');
      }
    } catch (_) {}
    const updateAvailable = Boolean(latest && isNewerVersion(latest, current));
    res.json({ current, latest, updateAvailable, url: zipUrl, notes });
  });

  // Quick connection test for a provider (tiny prompt) -> exact error if any.
  app.post('/api/test', async (req, res) => {
    try {
      const { provider = 'claude', model } = req.body || {};
      const r = await llm.generate({
        provider, model, prompt: 'Reply with exactly: OK',
        maxTokens: 20, temperature: 0, timeoutMs: 45000,
      });
      res.json({ ok: true, provider, model: r.model, text: (r.text || '').slice(0, 120) });
    } catch (err) {
      res.status(err.status || 500).json({ ok: false, error: err.message });
    }
  });

  app.use('/api/templates', templatesRouter);
  app.use('/api/projects', projectsRouter);
  app.use('/api/settings', settingsRouter);
  app.use('/api/logs', logsRouter);
  app.use('/api/agent', require('./routes/agent'));
  app.use('/api/qa', require('./routes/qa'));

  const clientDist = path.join(__dirname, '..', 'client', 'dist');
  if (fs.existsSync(clientDist)) {
    app.use(express.static(clientDist));
    app.get('*', (req, res, next) => {
      if (req.path.startsWith('/api/')) return next();
      res.sendFile(path.join(clientDist, 'index.html'));
    });
  }

  app.use((err, req, res, next) => {
    console.error('[error]', err.message);
    res.status(err.status || 400).json({ error: err.message || 'Server error' });
  });

  return app;
}

async function start({ port } = {}) {
  await require('./db').init();
  const app = createApp();
  const desired =
    port === undefined || port === null ? process.env.PORT || 3001 : port;
  return new Promise((resolve, reject) => {
    const server = app.listen(desired, () => resolve({ app, server, port: server.address().port }));
    server.on('error', reject);
  });
}

module.exports = { createApp, start };
