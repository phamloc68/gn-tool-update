@echo off
REM ============================================================
REM  GN Content Tool - DONG GOI CHO NHAN VIEN
REM  Chay file nay 1 lan tren may admin (co Node.js 18+).
REM  Ket qua: file "GN-Content-Tool-NhanVien.zip" san sang gui.
REM  May nhan vien KHONG can cai Node.js - chi giai nen + bam .exe.
REM ============================================================
setlocal
cd /d "%~dp0"

echo.
echo [1/4] Tim Node.js...
where node >nul 2>nul
if not errorlevel 1 goto :node_ok
REM Node khong co trong PATH -> tu tim o cac thu muc cai dat thuong gap
for %%P in ("%ProgramFiles%\nodejs" "%ProgramFiles(x86)%\nodejs" "%LOCALAPPDATA%\Programs\nodejs" "%LOCALAPPDATA%\Programs\node" "%ProgramW6432%\nodejs") do (
  if exist "%%~P\node.exe" (
    set "PATH=%%~P;%PATH%"
    goto :node_found
  )
)
:node_found
where node >nul 2>nul
if not errorlevel 1 goto :node_ok
echo.
echo   KHONG TIM THAY Node.js tren may nay.
echo   Neu vua cai Node: hay KHOI DONG LAI MAY roi chay lai file nay.
echo   Neu chua cai: tai ban LTS tai https://nodejs.org/ , cai xong khoi dong lai may.
echo.
pause
exit /b 1
:node_ok
node -v

echo.
echo [2/4] Cai dependencies + chuan bi giao dien...
call npm install || goto :error
if not exist "client\dist\index.html" (
  call npm --prefix client install || goto :error
  call npm --prefix client run build || goto :error
)

echo.
echo [3/4] Dong goi app (tai Electron lan dau, doi vai phut)...
call npx --no-install electron-packager . "GN Content Tool" --platform=win32 --arch=x64 --out=release --overwrite --prune=true --ignore="/client/node_modules" --ignore="/client/src" --ignore="^/release" || goto :error

echo.
echo [4/4] Nen thanh file zip de gui...
if exist "GN-Content-Tool-NhanVien.zip" del /f /q "GN-Content-Tool-NhanVien.zip"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'release\GN Content Tool-win32-x64' -DestinationPath 'GN-Content-Tool-NhanVien.zip' -Force"

echo.
echo ============================================================
echo  XONG!  File de gui nhan vien:
echo     %CD%\GN-Content-Tool-NhanVien.zip
echo.
echo  Nhan vien chi can: giai nen -> mo thu muc
echo     "GN Content Tool-win32-x64" -> bam "GN Content Tool.exe"
echo  (Khong can cai Node.js. Lan dau vao Cai dat nhap API key.)
echo ============================================================
echo.
pause
exit /b 0

:error
echo.
echo DONG GOI THAT BAI. Keo len tren xem dong loi dau tien.
pause
exit /b 1
