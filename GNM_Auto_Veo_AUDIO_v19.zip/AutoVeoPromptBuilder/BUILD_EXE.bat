@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title Build GNM Auto Veo AUDIO (.exe)

echo =====================================================================
echo   TAO FILE .EXE  -  Chay 1 LAN tren may Windows nay
echo   Ket qua: GNM Auto Veo AUDIO.exe  (copy file nay cho nhan vien)
echo =====================================================================
echo.

REM ====== 1) Tim / cai Python ======
set "PYEXE="
for %%P in (py python) do (
  if not defined PYEXE ( %%P -c "import sys" >nul 2>&1 && set "PYEXE=%%P" )
)
if not defined PYEXE (
  set "PYVER=3.12.7"
  set "PYINST=%TEMP%\python-!PYVER!-amd64.exe"
  echo [1/4] Chua co Python. Dang tai Python !PYVER! ...
  powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -Uri ('https://www.python.org/ftp/python/!PYVER!/python-!PYVER!-amd64.exe') -OutFile '!PYINST!' } catch { exit 1 }"
  if errorlevel 1 ( echo     ^>^> Tai Python that bai. & pause & exit /b 1 )
  echo [1/4] Dang cai Python ...
  "!PYINST!" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=1
  for %%D in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%ProgramFiles%\Python312\python.exe"
  ) do ( if not defined PYEXE if exist %%D set "PYEXE=%%~D" )
  if not defined PYEXE ( echo     ^>^> Da cai nhung chua thay python.exe. Mo lai file nay. & pause & exit /b 1 )
)
echo [1/4] Python: !PYEXE!

REM ====== 2) Cai thu vien + PyInstaller ======
echo [2/4] Dang cai thu vien va PyInstaller ...
"!PYEXE!" -m pip install --upgrade pip
"!PYEXE!" -m pip install -r requirements.txt pyinstaller
if errorlevel 1 ( echo     ^>^> Cai dat that bai. & pause & exit /b 1 )

REM ====== 3) Dong goi thanh 1 file .exe ======
echo [3/4] Dang dong goi .exe (1-3 phut, vui long doi) ...
"!PYEXE!" -m PyInstaller --onefile --windowed --noconfirm --clean ^
  --name "GNM Auto Veo AUDIO" ^
  --collect-all customtkinter ^
  app.py
if errorlevel 1 ( echo     ^>^> Build that bai. Xem thong bao ben tren. & pause & exit /b 1 )

REM ====== 4) Dua file .exe ra ngoai cho de lay ======
if exist "dist\GNM Auto Veo AUDIO.exe" (
  copy /Y "dist\GNM Auto Veo AUDIO.exe" "GNM Auto Veo AUDIO.exe" >nul
  echo.
  echo =====================================================================
  echo   XONG! File ung dung:
  echo     - %~dp0GNM Auto Veo AUDIO.exe
  echo     - %~dp0dist\GNM Auto Veo AUDIO.exe
  echo.
  echo   COPY file "GNM Auto Veo AUDIO.exe" cho nhan vien.
  echo   Ho chi can NHAN DUP file .exe la phan mem mo len - khong cai gi them.
  echo =====================================================================
  explorer /select,"%~dp0GNM Auto Veo AUDIO.exe"
) else (
  echo     ^>^> Khong tim thay file .exe sau khi build.
)
echo.
pause
endlocal
