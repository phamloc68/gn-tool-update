"""Giao diện desktop (CustomTkinter) cho GNM Auto Veo AUDIO — thiết kế dễ dùng."""
from __future__ import annotations

import os
import threading
from typing import Optional

import customtkinter as ctk
from tkinter import filedialog, messagebox
import subprocess

import config
from core.exporter import ExportMeta, export
from core.formatter import build_output
from core.scene_splitter import split_scenes
from core.story_analyzer import analysis_to_brief, analyze_story
from core.story_reader import read_story, word_count
from core.validator import validate_output
from core.veo_prompt_generator import generate_prompts, regenerate_indices
from services.ai_client import AIError, get_client
from utils.logger import Logger
from core import updater
from utils.settings import load_settings, save_settings

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

ACCENT = "#E0913E"
ACCENT_HOVER = "#C77A2C"
BG = "#1A1714"
HEADER = "#221D18"
CARD = "#262019"
FIELD = "#332A21"
BTN = "#3A3128"
BTN_HOVER = "#4A3E30"
MUTED = "#A99E8C"
GOOD = "#6FB36F"


class App(ctk.CTk):
    """Cửa sổ chính."""

    def __init__(self) -> None:
        super().__init__()
        self.title(f"{config.APP_NAME}  v{config.VERSION}")
        self.geometry("1200x820")
        self.minsize(1060, 740)

        self.input_path: str = ""
        self.output_dir: str = ""
        self.analysis: Optional[dict] = None
        self.output_text: str = ""
        self._busy: bool = False
        self.segments: list[str] = []
        self.prompts: list[str] = []
        self.brief: str = ""
        self.failed_indices: list[int] = []
        self.visual_style: str = config.VISUAL_STYLES[0]
        self.logger = Logger(callback=self._log_threadsafe)

        self._build_ui()
        self._apply_settings(load_settings())
        self.logger.info(f"Khoi dong {config.APP_NAME} v{config.VERSION}")
        threading.Thread(target=self._startup_update_check, daemon=True).start()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ============================ UI ============================
    def _build_ui(self) -> None:
        self.configure(fg_color=BG)
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # ===== HEADER =====
        header = ctk.CTkFrame(self, fg_color=HEADER, corner_radius=0)
        header.grid(row=0, column=0, columnspan=2, sticky="ew")
        hl = ctk.CTkFrame(header, fg_color="transparent")
        hl.pack(side="left", padx=22, pady=10)
        ctk.CTkLabel(hl, text="GNM Auto Veo AUDIO",
                     font=ctk.CTkFont(size=21, weight="bold"), text_color=ACCENT).pack(anchor="w")
        ctk.CTkLabel(hl, text="Truyen  ->  prompt video Veo  ·  3 buoc",
                     font=ctk.CTkFont(size=12), text_color=MUTED).pack(anchor="w")
        ctk.CTkLabel(header, text=f"v{config.VERSION}", font=ctk.CTkFont(size=12),
                     text_color=MUTED).pack(side="right", padx=22)

        # ===== LEFT: cau hinh (scroll) =====
        left = ctk.CTkScrollableFrame(self, width=420, fg_color="transparent")
        left.grid(row=1, column=0, sticky="nsw", padx=(14, 7), pady=14)

        # --- Card 1: Nguon & noi luu ---
        c = self._card(left, "1   NGUON TRUYEN & NOI LUU")
        self.btn_input = ctk.CTkButton(c, text="  Chon file truyen (.txt)", height=42,
                                       fg_color=BTN, hover_color=BTN_HOVER, anchor="w",
                                       command=self._pick_input)
        self.btn_input.pack(fill="x")
        self.lbl_input = ctk.CTkLabel(c, text="Chua chon file", text_color=MUTED,
                                      anchor="w", wraplength=360, justify="left")
        self.lbl_input.pack(fill="x", pady=(4, 10))
        self.btn_output = ctk.CTkButton(c, text="  Chon noi luu ket qua", height=42,
                                        fg_color=BTN, hover_color=BTN_HOVER, anchor="w",
                                        command=self._pick_output)
        self.btn_output.pack(fill="x")
        self.lbl_output = ctk.CTkLabel(c, text="Chua chon (se hoi khi luu)", text_color=MUTED,
                                       anchor="w", wraplength=360, justify="left")
        self.lbl_output.pack(fill="x", pady=(4, 0))

        # --- Card 2: Tuy chon video ---
        c = self._card(left, "2   CHE DO & TUY CHON")
        self._lab(c, "Che do tao prompt")
        self.opt_mode = ctk.CTkOptionMenu(c, values=config.MODES,
                                          fg_color=FIELD, button_color=ACCENT, button_hover_color=ACCENT_HOVER)
        self.opt_mode.set("Video (Veo)")
        self.opt_mode.pack(fill="x", pady=(0, 4))
        self._lab(c, "Phong cach hinh anh")
        self.opt_style = ctk.CTkOptionMenu(c, values=config.VISUAL_STYLES,
                                           fg_color=FIELD, button_color=ACCENT, button_hover_color=ACCENT_HOVER)
        self.opt_style.set("2D CHINESE")
        self.opt_style.pack(fill="x", pady=(0, 4))
        g = self._grid2(c)
        a, b = self._cell(g, 0), self._cell(g, 1)
        self._lab(a, "Thoi luong / canh")
        self.opt_duration = ctk.CTkOptionMenu(a, values=config.DURATIONS, fg_color=FIELD,
                                              button_color=ACCENT, button_hover_color=ACCENT_HOVER)
        self.opt_duration.set("8 seconds"); self.opt_duration.pack(fill="x")
        self._lab(b, "Khung hinh")
        self.opt_aspect = ctk.CTkOptionMenu(b, values=config.ASPECT_RATIOS, fg_color=FIELD,
                                            button_color=ACCENT, button_hover_color=ACCENT_HOVER)
        self.opt_aspect.pack(fill="x")
        g = self._grid2(c)
        a, b = self._cell(g, 0), self._cell(g, 1)
        self._lab(a, "Ngon ngu prompt")
        self.opt_lang = ctk.CTkOptionMenu(a, values=config.LANGUAGES, fg_color=FIELD,
                                          button_color=ACCENT, button_hover_color=ACCENT_HOVER)
        self.opt_lang.pack(fill="x")
        self._lab(b, "So canh toi da")
        self.opt_max = ctk.CTkOptionMenu(b, values=config.MAX_SCENES_OPTIONS, fg_color=FIELD,
                                         button_color=ACCENT, button_hover_color=ACCENT_HOVER)
        self.opt_max.pack(fill="x")
        self._lab(c, "Yeu cau hinh anh them (khong bat buoc)")
        self.ent_extra = ctk.CTkEntry(c, placeholder_text="vd: muted tones, film grain...", fg_color=FIELD)
        self.ent_extra.pack(fill="x")

        # --- Card 3: Cai dat AI ---
        c = self._card(left, "3   CAI DAT AI  (nhap 1 lan, tu luu)")
        self._lab(c, "Nha cung cap AI")
        self.opt_provider = ctk.CTkOptionMenu(c, values=config.PROVIDERS, command=self._on_provider_change,
                                              fg_color=FIELD, button_color=ACCENT, button_hover_color=ACCENT_HOVER)
        self.opt_provider.pack(fill="x", pady=(0, 4))
        self._lab(c, "Base URL (cong 9Router / OpenAI-compatible)")
        self.ent_baseurl = ctk.CTkEntry(c, placeholder_text="https://llm.chiasegpu.vn/v1", fg_color=FIELD)
        self.ent_baseurl.pack(fill="x", pady=(0, 4))
        self._lab(c, "API key")
        kr = ctk.CTkFrame(c, fg_color="transparent"); kr.pack(fill="x"); kr.grid_columnconfigure(0, weight=1)
        self.ent_key = ctk.CTkEntry(kr, show="*", placeholder_text="Dan API key", fg_color=FIELD)
        self.ent_key.grid(row=0, column=0, sticky="ew")
        ctk.CTkButton(kr, text="HIEN", width=52, fg_color=BTN, hover_color=BTN_HOVER,
                      command=self._toggle_key).grid(row=0, column=1, padx=(6, 0))
        self._lab(c, "Model")
        self.cmb_model = ctk.CTkComboBox(c, values=config.MODELS["OpenAI-compatible"],
                                         fg_color=FIELD, button_color=ACCENT)
        self.cmb_model.pack(fill="x", pady=(0, 4))
        self._lab(c, "Key phu - chay song song cho nhanh (moi dong 1 key)")
        self.txt_keys = ctk.CTkTextbox(c, height=56, wrap="none", fg_color=FIELD)
        self.txt_keys.pack(fill="x")
        ctk.CTkLabel(c, text="De trong neu chi 1 key. 2 key = nhanh ~gap doi.",
                     anchor="w", text_color="#7f8fae", wraplength=360, justify="left").pack(fill="x", pady=(3, 0))

        # --- Card 4: Phien ban ---
        c = self._card(left, "4   PHIEN BAN & CAP NHAT")
        self._lab(c, "URL cap nhat (admin dien 1 lan)")
        self.ent_update = ctk.CTkEntry(c, placeholder_text="https://.../version.json", fg_color=FIELD)
        self.ent_update.pack(fill="x", pady=(0, 6))
        self.btn_update = ctk.CTkButton(c, text="Kiem tra cap nhat", height=38,
                                        fg_color=BTN, hover_color=BTN_HOVER, command=self._check_update_clicked)
        self.btn_update.pack(fill="x")

        # ===== RIGHT: hanh dong + ket qua =====
        right = ctk.CTkFrame(self, fg_color="transparent")
        right.grid(row=1, column=1, sticky="nsew", padx=(7, 14), pady=14)
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure(5, weight=1)

        guide = ctk.CTkFrame(right, fg_color=CARD, corner_radius=14)
        guide.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        ctk.CTkLabel(guide, justify="left", anchor="w", text_color="#e8dcc8",
                     font=ctk.CTkFont(size=13),
                     text="  1  Chon file truyen      2  Bam TAO PROMPT      3  Bam LUU FILE"
                     ).pack(fill="x", padx=14, pady=12)

        self.btn_generate = ctk.CTkButton(
            right, text="TAO PROMPT VEO", height=58, corner_radius=12,
            font=ctk.CTkFont(size=18, weight="bold"),
            fg_color=ACCENT, hover_color=ACCENT_HOVER, text_color="#1a1410",
            command=self._generate_clicked)
        self.btn_generate.grid(row=1, column=0, sticky="ew", pady=(0, 8))

        actions = ctk.CTkFrame(right, fg_color="transparent")
        actions.grid(row=2, column=0, sticky="ew", pady=(0, 10))
        actions.grid_columnconfigure((0, 1), weight=1)
        self.btn_retry = ctk.CTkButton(actions, text="Lam lai canh loi", height=42, state="disabled",
                                       fg_color=BTN, hover_color=BTN_HOVER, command=self._retry_clicked)
        self.btn_retry.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        self.btn_export = ctk.CTkButton(actions, text="LUU FILE .TXT", height=42, state="disabled",
                                        fg_color=GOOD, hover_color="#5a9a5a", text_color="#10210f",
                                        font=ctk.CTkFont(size=14, weight="bold"), command=self._export_clicked)
        self.btn_export.grid(row=0, column=1, sticky="ew", padx=(5, 0))

        self.progress = ctk.CTkProgressBar(right, height=12, corner_radius=6, progress_color=ACCENT)
        self.progress.set(0)
        self.progress.grid(row=3, column=0, sticky="ew", pady=(0, 4))
        self.lbl_status = ctk.CTkLabel(right, text="San sang.", anchor="w", text_color="#9cc")
        self.lbl_status.grid(row=4, column=0, sticky="ew", pady=(0, 8))

        tabs = ctk.CTkTabview(right, fg_color=CARD, segmented_button_selected_color=ACCENT,
                              segmented_button_selected_hover_color=ACCENT_HOVER)
        tabs.grid(row=5, column=0, sticky="nsew")
        tabs.add("Xem truoc")
        tabs.add("Nhat ky")
        self.txt_preview = ctk.CTkTextbox(tabs.tab("Xem truoc"), wrap="word", fg_color="#1d1a17")
        self.txt_preview.pack(fill="both", expand=True, padx=6, pady=6)
        self.txt_log = ctk.CTkTextbox(tabs.tab("Nhat ky"), wrap="word", fg_color="#1d1a17")
        self.txt_log.pack(fill="both", expand=True, padx=6, pady=6)

        # defaults
        self.opt_provider.set("OpenAI-compatible")
        self._on_provider_change("OpenAI-compatible")

    # ---- helpers tao UI ----
    def _card(self, parent, title: str):
        card = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=14)
        card.pack(fill="x", pady=(0, 12))
        if title:
            ctk.CTkLabel(card, text=title, anchor="w", text_color=ACCENT,
                         font=ctk.CTkFont(size=12, weight="bold")).pack(fill="x", padx=16, pady=(13, 4))
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=16, pady=(0, 14))
        return inner

    def _grid2(self, parent):
        r = ctk.CTkFrame(parent, fg_color="transparent")
        r.pack(fill="x", pady=(4, 0))
        r.grid_columnconfigure((0, 1), weight=1)
        return r

    def _cell(self, row, idx):
        cell = ctk.CTkFrame(row, fg_color="transparent")
        cell.grid(row=0, column=idx, sticky="ew", padx=(0, 5) if idx == 0 else (5, 0))
        return cell

    def _lab(self, parent, text: str) -> None:
        ctk.CTkLabel(parent, text=text, anchor="w", text_color=MUTED,
                     font=ctk.CTkFont(size=12)).pack(fill="x", pady=(8, 2))

    def _toggle_key(self) -> None:
        self.ent_key.configure(show="" if self.ent_key.cget("show") else "•")

    # ============================ settings ============================
    def _apply_settings(self, s: dict) -> None:
        if not s:
            return
        prov = s.get("provider", "OpenAI-compatible")
        if prov in config.PROVIDERS:
            self.opt_provider.set(prov)
            self._on_provider_change(prov)
        for key, widget, setter in [
            ("base_url", self.ent_baseurl, "entry"),
            ("api_key", self.ent_key, "entry"),
            ("model", self.cmb_model, "combo"),
            ("extra_style", self.ent_extra, "entry"),
        ]:
            val = s.get(key, "")
            if val:
                if setter == "entry":
                    widget.delete(0, "end"); widget.insert(0, val)
                else:
                    widget.set(val)
        if s.get("mode") in config.MODES:
            self.opt_mode.set(s["mode"])
        if s.get("visual_style") in config.VISUAL_STYLES:
            self.opt_style.set(s["visual_style"])
        if s.get("duration") in config.DURATIONS:
            self.opt_duration.set(s["duration"])
        if s.get("aspect") in config.ASPECT_RATIOS:
            self.opt_aspect.set(s["aspect"])
        if s.get("language") in config.LANGUAGES:
            self.opt_lang.set(s["language"])
        if s.get("max_scenes") in config.MAX_SCENES_OPTIONS:
            self.opt_max.set(s["max_scenes"])
        if s.get("update_url"):
            self.ent_update.delete(0, "end")
            self.ent_update.insert(0, s["update_url"])
        if s.get("extra_keys"):
            self.txt_keys.delete("1.0", "end")
            self.txt_keys.insert("1.0", s["extra_keys"])
        if s.get("output_dir") and os.path.isdir(s["output_dir"]):
            self.output_dir = s["output_dir"]
            self.lbl_output.configure(text=self.output_dir)

    def _collect_settings(self) -> dict:
        return {
            "provider": self.opt_provider.get(),
            "base_url": self.ent_baseurl.get().strip(),
            "api_key": self.ent_key.get().strip(),
            "model": self.cmb_model.get().strip(),
            "mode": self.opt_mode.get(),
            "visual_style": self.opt_style.get(),
            "extra_style": self.ent_extra.get().strip(),
            "extra_keys": self.txt_keys.get("1.0", "end").strip(),
            "duration": self.opt_duration.get(),
            "aspect": self.opt_aspect.get(),
            "language": self.opt_lang.get(),
            "max_scenes": self.opt_max.get(),
            "output_dir": self.output_dir,
            "update_url": self.ent_update.get().strip(),
        }

    def _save_now(self) -> None:
        save_settings(self._collect_settings())

    def _on_close(self) -> None:
        self._save_now()
        self.destroy()

    # ============================ events ============================
    def _on_provider_change(self, provider: str) -> None:
        models = config.MODELS.get(provider, [])
        self.cmb_model.configure(values=models)
        if models:
            # mặc định chọn bản nhanh nếu có (sonnet), không thì phần tử đầu
            default = next((m for m in models if "sonnet" in m), models[0])
            self.cmb_model.set(default)
        if provider == "OpenAI-compatible" and not self.ent_baseurl.get().strip():
            self.ent_baseurl.insert(0, config.DEFAULT_BASE_URL)

    def _pick_input(self) -> None:
        path = filedialog.askopenfilename(title="Chọn file truyện .txt",
                                          filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if path:
            self.input_path = path
            self.lbl_input.configure(text="✔ " + os.path.basename(path), text_color="#7fae7f")
            self.analysis = None
            self.logger.info(f"Da chon file: {path}")

    def _pick_output(self) -> None:
        path = filedialog.askdirectory(title="Chọn thư mục lưu kết quả")
        if path:
            self.output_dir = path
            self.lbl_output.configure(text="✔ " + path, text_color="#7fae7f")
            self.logger.info(f"Noi luu: {path}")
            self._save_now()

    # ---- threadsafe UI ----
    def _log_threadsafe(self, line: str) -> None:
        self.after(0, lambda: self._append_log(line))

    def _append_log(self, line: str) -> None:
        self.txt_log.insert("end", line + "\n"); self.txt_log.see("end")

    def _set_status(self, text: str) -> None:
        self.after(0, lambda: self.lbl_status.configure(text=text))

    def _set_progress(self, value: float) -> None:
        self.after(0, lambda: self.progress.set(max(0.0, min(1.0, value))))

    def _set_preview(self, text: str) -> None:
        def _do() -> None:
            self.txt_preview.delete("1.0", "end"); self.txt_preview.insert("1.0", text)
        self.after(0, _do)

    def _set_busy(self, busy: bool) -> None:
        self._busy = busy
        if busy:
            for w in (self.btn_generate, self.btn_input, self.btn_output,
                      self.btn_retry, self.btn_export):
                self.after(0, lambda w=w: w.configure(state="disabled"))
        else:
            for w in (self.btn_generate, self.btn_input, self.btn_output):
                self.after(0, lambda w=w: w.configure(state="normal"))

    def _refresh_output(self) -> None:
        self.output_text = build_output(self.prompts, prefix=self._out_prefix())
        self._set_preview(self.output_text)
        has = any(p.strip() for p in self.prompts)
        nfail = len(self.failed_indices)
        self.logger.info(f"Hoan tat: {sum(1 for p in self.prompts if p.strip())} canh OK, {nfail} loi.")
        self.after(0, lambda: self.btn_export.configure(state="normal" if has else "disabled"))
        self.after(0, lambda: self.btn_retry.configure(state="normal" if nfail else "disabled"))

    def _build_clients(self):
        """Tao danh sach AIClient tu key chinh + cac key phu (chay song song)."""
        provider = self.opt_provider.get()
        model = self.cmb_model.get().strip()
        base_url = self.ent_baseurl.get().strip()
        keys = [self.ent_key.get().strip()]
        for line in self.txt_keys.get("1.0", "end").splitlines():
            line = line.strip()
            if line:
                keys.append(line)
        # bo trung & rong, giu thu tu
        seen = set(); uniq = []
        for k in keys:
            if k and k not in seen:
                seen.add(k); uniq.append(k)
        if not uniq:
            from services.ai_client import AIError
            raise AIError("Chua nhap API key.")
        return [get_client(provider, k, model, self.logger, base_url=base_url) for k in uniq]

    def _build_client(self):
        return get_client(self.opt_provider.get(), self.ent_key.get().strip(),
                          self.cmb_model.get().strip(), self.logger,
                          base_url=self.ent_baseurl.get().strip())

    def _duration_int(self) -> int:
        return int(self.opt_duration.get().split()[0])

    def _max_scenes(self) -> Optional[int]:
        v = self.opt_max.get()
        return None if v == "Auto" else int(v)

    # ============================ generate ============================
    def _generate_clicked(self) -> None:
        if self._busy:
            return
        if not self.input_path:
            self.logger.error("Chua chon file truyen.")
            self._set_status("⚠ Vui lòng chọn file truyện ở Bước 1.")
            return
        if not self.ent_key.get().strip():
            self.logger.error("Chua nhap API key.")
            self._set_status("⚠ Vui lòng nhập API key trong phần Cài đặt AI.")
            return
        self._save_now()
        threading.Thread(target=self._generate_worker, daemon=True).start()

    def _generate_worker(self) -> None:
        self._set_busy(True)
        self._set_progress(0)
        try:
            text = read_story(self.input_path)
            self.logger.info(f"Doc thanh cong: {word_count(text)} tu.")
            clients = self._build_clients()
            if len(clients) > 1:
                self.logger.info(f"Dung {len(clients)} key chay song song.")

            if self.analysis is None:
                self._set_status("Đang phân tích câu chuyện…")
                self.analysis = analyze_story(clients[0], text, self.opt_lang.get(), self.logger)
            brief = analysis_to_brief(self.analysis or {})

            self._set_status("Đang tách phân cảnh…")
            segments = split_scenes(text, self._duration_int(), self._max_scenes(), self.logger)
            if not segments:
                raise ValueError("Khong tach duoc phan canh nao.")

            self._set_status(f"Đang tạo prompt cho {len(segments)} cảnh…")
            self.segments = segments
            self.brief = brief
            prompts, failed = generate_prompts(
                clients, segments, brief,
                visual_style=self.opt_style.get(),
                extra_style=self.ent_extra.get(),
                aspect=self.opt_aspect.get(),
                language=self.opt_lang.get(),
                duration_sec=self._duration_int(),
                mode=self.opt_mode.get(),
                logger=self.logger,
                progress_cb=lambda dn, tt: self._set_progress(dn / tt),
            )
            self.prompts = prompts
            self.failed_indices = failed
            self._refresh_output()
            self._set_progress(1.0)
            if failed:
                self._set_status(f"⚠ Xong nhưng {len(failed)} cảnh lỗi — bấm 🔁 Làm lại cảnh lỗi.")
            else:
                done = sum(1 for p in prompts if p.strip())
                self._set_status(f"✔ Xong {done} cảnh! Bấm 💾 LƯU FILE .TXT để lưu.")
            self._save_now()
        except (AIError, ValueError, FileNotFoundError) as exc:
            self.logger.error(str(exc))
            self._set_status(f"Lỗi: {exc}")
        except Exception as exc:  # pragma: no cover
            self.logger.error(f"Loi khong mong doi: {exc}")
            self._set_status(f"Lỗi: {exc}")
        finally:
            self._set_busy(False)

    def _retry_clicked(self) -> None:
        if self._busy:
            return
        if not self.failed_indices or not self.segments:
            self._set_status("Khong co canh loi de lam lai.")
            return
        if not self.ent_key.get().strip():
            self._set_status("⚠ Cần API key để làm lại.")
            return
        threading.Thread(target=self._retry_worker, daemon=True).start()

    def _retry_worker(self) -> None:
        self._set_busy(True)
        try:
            clients = self._build_clients()
            self.logger.info(f"Lam lai {len(self.failed_indices)} canh loi…")
            prompts, failed = regenerate_indices(
                clients, self.segments, self.failed_indices, self.prompts, self.brief,
                visual_style=self.opt_style.get(),
                extra_style=self.ent_extra.get(),
                aspect=self.opt_aspect.get(),
                language=self.opt_lang.get(),
                duration_sec=self._duration_int(),
                mode=self.opt_mode.get(),
                logger=self.logger,
                progress_cb=lambda dn, tt: self._set_progress(dn / tt),
            )
            self.prompts = prompts
            self.failed_indices = failed
            self._refresh_output()
            self._set_progress(1.0)
            if failed:
                self._set_status(f"⚠ Vẫn còn {len(failed)} cảnh lỗi — có thể bấm Làm lại tiếp.")
            else:
                self._set_status("✔ Đã làm lại xong tất cả cảnh lỗi!")
            self._save_now()
        except (AIError, ValueError) as exc:
            self.logger.error(str(exc)); self._set_status(f"Lỗi: {exc}")
        except Exception as exc:  # pragma: no cover
            self.logger.error(f"Loi khong mong doi: {exc}"); self._set_status(f"Lỗi: {exc}")
        finally:
            self._set_busy(False)

    def _export_clicked(self) -> None:
        if not self.output_text.strip():
            self.logger.error("Chua co noi dung de luu.")
            return
        if not self.output_dir:
            self._pick_output()
            if not self.output_dir:
                return
        try:
            scene_count = validate_output(self.output_text).scene_count
            meta = ExportMeta(
                input_file=self.input_path,
                ai_provider=self.opt_provider.get(),
                model=self.cmb_model.get().strip(),
                total_scenes=scene_count,
                scene_duration=self.opt_duration.get(),
                aspect_ratio=self.opt_aspect.get(),
                visual_style=self.opt_style.get(),
                language=self.opt_lang.get(),
            )
            res = export(self.output_dir, self.output_text, meta)
            self.logger.info(f"Da luu: {res.txt_path}")
            self.logger.info(f"Da luu log: {res.json_path}")
            self._set_status(f"✔ Đã lưu {scene_count} cảnh → {os.path.basename(res.txt_path)}")
        except (ValueError, OSError) as exc:
            self.logger.error(str(exc))
            self._set_status(f"Lỗi lưu file: {exc}")


    def _out_prefix(self) -> str:
        return "SCENE_" if "video" in self.opt_mode.get().lower() else "IMAGE_"

    def _install_dir(self) -> str:
        # ui/main_window.py -> len 2 cap = thu muc cai dat (chua app.py)
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def _update_url(self) -> str:
        return self.ent_update.get().strip() or config.UPDATE_MANIFEST_URL

    def _startup_update_check(self) -> None:
        url = self._update_url()
        if not url:
            return
        try:
            info = updater.check_for_update(url)
            if info:
                self._set_status(f"⬆ Co ban moi v{info['version']}! Vao muc PHIEN BAN de cap nhat.")
                self.logger.info(f"Co ban moi: v{info['version']}")
        except Exception:
            pass  # khong lam phien khi mo app

    def _check_update_clicked(self) -> None:
        if self._busy:
            return
        threading.Thread(target=self._update_worker, daemon=True).start()

    def _update_worker(self) -> None:
        url = self._update_url()
        if not url:
            self.after(0, lambda: messagebox.showinfo(
                "Cap nhat", "Chua co URL cap nhat. Nho admin dien URL version.json vao o tren."))
            return
        self._set_status("Dang kiem tra cap nhat...")
        try:
            info = updater.check_for_update(url)
        except Exception as exc:
            self.logger.error(f"Kiem tra cap nhat loi: {exc}")
            self._set_status("Loi kiem tra cap nhat.")
            self.after(0, lambda: messagebox.showerror("Cap nhat", f"Khong kiem tra duoc:\n{exc}"))
            return
        self._save_now()
        if not info:
            self._set_status(f"Da la ban moi nhat (v{config.VERSION}).")
            self.after(0, lambda: messagebox.showinfo(
                "Cap nhat", f"Ban dang dung phien ban moi nhat (v{config.VERSION})."))
            return
        notes = info.get("notes", "")
        msg = (f"Co ban moi: v{info['version']}\n\n{notes}\n\n"
               "Tai ve ngay bay gio?")
        if not info.get("url"):
            self.after(0, lambda: messagebox.showinfo(
                "Cap nhat", f"Co ban moi v{info['version']} nhung manifest khong co link tai."))
            return
        do = []
        def ask():
            do.append(messagebox.askyesno("Cap nhat", msg))
        self.after(0, ask)
        # cho nguoi dung tra loi
        import time as _t
        while not do:
            _t.sleep(0.1)
        if not do[0]:
            self._set_status("Da huy tai cap nhat.")
            return
        self._set_status(f"Dang tai ban moi v{info['version']}...")
        self._set_busy(True)
        try:
            import sys as _sys
            dest_dir = updater.default_download_dir()
            path = updater.download_update(info["url"], dest_dir)
            self.logger.info(f"Da tai: {path}")
            if getattr(_sys, "frozen", False):
                # Dang chay ban .exe -> khong tu thay duoc, mo thu muc cho nguoi dung
                self._set_status(f"✔ Da tai: {path}")
                try:
                    subprocess.run(["explorer", "/select,", os.path.normpath(path)])
                except Exception:
                    try: os.startfile(dest_dir)
                    except Exception: pass
                self.after(0, lambda: messagebox.showinfo(
                    "Cap nhat",
                    f"Da tai ban moi v{info['version']} ve:\n{path}\n\n"
                    "Ban dang chay ban .exe: hay thay file .exe cu bang file moi trong thu muc vua mo."))
            else:
                # Chay tu ma nguon -> tu cai + khoi dong lai (mot bam)
                self._set_status(f"Dang cai ban moi v{info['version']}...")
                install_dir = self._install_dir()
                updater.apply_update(path, install_dir)
                self.logger.info("Da cai xong, khoi dong lai...")
                updater.relaunch(install_dir)
                self.after(0, lambda: messagebox.showinfo(
                    "Cap nhat",
                    f"Da cap nhat len v{info['version']}! Phan mem se khoi dong lai."))
                self.after(400, self._on_close)
        except Exception as exc:
            self.logger.error(f"Cap nhat loi: {exc}")
            self._set_status("Loi cap nhat.")
            self.after(0, lambda: messagebox.showerror("Cap nhat", f"Cap nhat that bai:\n{exc}"))
        finally:
            self._set_busy(False)


def main() -> None:
    app = App()
    app.mainloop()
