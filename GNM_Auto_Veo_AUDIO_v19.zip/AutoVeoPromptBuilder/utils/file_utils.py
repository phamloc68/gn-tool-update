"""Tiện ích đọc/ghi file với xử lý nhiều encoding."""
from __future__ import annotations

import os

# Thứ tự thử encoding: UTF-8-SIG (BOM), UTF-8, Windows-1258 (tiếng Việt),
# Windows-1252, cuối cùng latin-1 (không bao giờ lỗi).
_ENCODINGS: tuple[str, ...] = ("utf-8-sig", "utf-8", "cp1258", "cp1252", "latin-1")


def read_text_file(path: str) -> str:
    """Đọc file văn bản, tự dò encoding. Báo lỗi rõ nếu không đọc được hoặc rỗng."""
    if not path:
        raise ValueError("Chưa chọn file input.")
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Không tìm thấy file: {path}")

    raw = b""
    with open(path, "rb") as fh:
        raw = fh.read()

    if not raw.strip():
        raise ValueError("File input rỗng.")

    last_err: Exception | None = None
    for enc in _ENCODINGS:
        try:
            text = raw.decode(enc)
            if text.strip():
                return text
        except (UnicodeDecodeError, LookupError) as exc:  # thử encoding tiếp theo
            last_err = exc
            continue

    raise ValueError(f"Không giải mã được file với các encoding hỗ trợ. Lỗi cuối: {last_err}")


def write_text_file(path: str, content: str) -> None:
    """Ghi UTF-8 (không BOM)."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(content)


def ensure_dir(path: str) -> str:
    """Tạo thư mục nếu chưa có, trả về đường dẫn."""
    os.makedirs(path, exist_ok=True)
    return path
