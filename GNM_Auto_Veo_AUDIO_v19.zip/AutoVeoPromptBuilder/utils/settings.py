"""Lưu / đọc cài đặt người dùng (key, cổng, model...) để lần sau khỏi nhập lại."""
from __future__ import annotations

import json
import os
from typing import Any

_APP_DIR_NAME = "GNM Auto Veo AUDIO"


def _settings_path() -> str:
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    folder = os.path.join(base, _APP_DIR_NAME)
    try:
        os.makedirs(folder, exist_ok=True)
    except OSError:
        folder = os.path.expanduser("~")
    return os.path.join(folder, "settings.json")


def load_settings() -> dict[str, Any]:
    """Đọc cài đặt đã lưu. Lỗi -> trả dict rỗng (không làm sập app)."""
    try:
        with open(_settings_path(), encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_settings(data: dict[str, Any]) -> None:
    """Ghi cài đặt. Lỗi -> bỏ qua im lặng."""
    try:
        with open(_settings_path(), "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
    except OSError:
        pass
