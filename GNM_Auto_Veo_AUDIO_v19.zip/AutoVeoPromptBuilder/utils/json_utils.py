"""Trích xuất JSON từ phản hồi AI (chịu được fence ```json hoặc văn bản thừa)."""
from __future__ import annotations

import json
from typing import Any


def extract_json_array(text: str) -> list[Any]:
    """Lấy mảng JSON đầu tiên trong text. Ném ValueError nếu không parse được."""
    cleaned = _strip_fences(text)
    start = cleaned.find("[")
    end = cleaned.rfind("]")
    if start == -1 or end == -1 or end < start:
        raise ValueError("Không tìm thấy mảng JSON trong phản hồi AI.")
    snippet = cleaned[start:end + 1]
    try:
        data = json.loads(snippet)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Lỗi parse JSON: {exc}") from exc
    if not isinstance(data, list):
        raise ValueError("Phản hồi JSON không phải là mảng.")
    return data


def extract_json_object(text: str) -> dict[str, Any]:
    """Lấy object JSON đầu tiên trong text."""
    cleaned = _strip_fences(text)
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ValueError("Không tìm thấy object JSON trong phản hồi AI.")
    snippet = cleaned[start:end + 1]
    try:
        data = json.loads(snippet)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Lỗi parse JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("Phản hồi JSON không phải là object.")
    return data


def _strip_fences(text: str) -> str:
    t = text.strip()
    if t.startswith("```"):
        # bỏ dòng ```json ... ```
        lines = t.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        t = "\n".join(lines)
    return t
