"""Logger đơn giản: ghi ra console và (tùy chọn) gọi callback để hiển thị lên GUI."""
from __future__ import annotations

import datetime as _dt
from typing import Callable, Optional

LogCallback = Callable[[str], None]


class Logger:
    """Logger nhẹ, hỗ trợ callback cho GUI."""

    def __init__(self, callback: Optional[LogCallback] = None, echo: bool = True) -> None:
        self._callback = callback
        self._echo = echo

    def set_callback(self, callback: Optional[LogCallback]) -> None:
        self._callback = callback

    def log(self, message: str, level: str = "INFO") -> None:
        ts = _dt.datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {level}: {message}"
        if self._echo:
            print(line)
        if self._callback:
            try:
                self._callback(line)
            except Exception:  # pragma: no cover - GUI lỗi không được làm sập pipeline
                pass

    def info(self, message: str) -> None:
        self.log(message, "INFO")

    def warn(self, message: str) -> None:
        self.log(message, "WARN")

    def error(self, message: str) -> None:
        self.log(message, "ERROR")
