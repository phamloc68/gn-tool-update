# GNM Auto Veo AUDIO

Phần mềm nội bộ chạy local trên Windows: đọc một file truyện `.txt` (15–18 phút), tự phân tích, cắt thành các phân cảnh 6–8 giây và sinh prompt **Google Veo 3 / Veo 3.1** theo đúng thứ tự câu chuyện. Hỗ trợ **Gemini** và **Claude**.

File output đúng chuẩn:

```
SCENE_01: ...


SCENE_02: ...


SCENE_03: ...
```

Mỗi scene 1 dòng, cách nhau đúng 2 dòng trống, không voiceover, không dialogue, không timecode, không markdown.

> Giao diện 3 bước, **tự lưu cài đặt** (key/cổng/model) — nhập 1 lần, lần sau tự điền.

## 1. Yêu cầu

- Python 3.11 trở lên (Windows).
- API key của Gemini hoặc Claude.

## 2. Cài đặt

```bash
pip install -r requirements.txt
```

(Tùy chọn) Tạo file `.env` từ `.env.example` để lưu sẵn API key:

```
GEMINI_API_KEY=sk-...
CLAUDE_API_KEY=sk-ant-...
```

## 3. Chạy

```bash
python app.py
```

## 4. Cách dùng

1. **Chọn file TXT input** – file truyện cần xử lý.
2. **Chọn thư mục output** – nơi lưu file kết quả.
3. **AI provider** – Gemini hoặc Claude.
4. **API key** – dán key (hoặc để trống nếu đã có trong `.env`).
5. **Model** – chọn từ danh sách hoặc gõ tên model mới hơn.
6. **Scene duration** – 6 / 7 / 8 giây.
7. **Aspect ratio** – 16:9 / 9:16 / 1:1.
8. **Visual style** – chọn 1 trong các phong cách dựng sẵn.
9. **Global Visual Style** – nhập thêm yêu cầu hình ảnh (tùy chọn).
10. **Ngôn ngữ prompt** – English / Vietnamese.
11. **Max scenes** – Auto hoặc giới hạn 80/100/120/150.
12. **Analyze Story** – (tùy chọn) phân tích nhân vật/bối cảnh trước.
13. **Generate Veo Prompts** – chạy toàn bộ pipeline (tự phân tích nếu chưa).
14. **Export TXT** – lưu `veo_prompts_YYYYMMDD_HHMMSS.txt` + `.json` log.

## 5. Build file .exe

```bash
pyinstaller --onefile --windowed app.py
```

Nếu thiếu file dữ liệu của CustomTkinter khi chạy .exe, build kèm:

```bash
pyinstaller --onefile --windowed --collect-all customtkinter app.py
```

File `.exe` nằm trong thư mục `dist/`.

## 6. Kiến trúc

```
app.py                      # khởi chạy
config.py                   # cấu hình tập trung (model, style, tham số)
.env.example                # mẫu khai báo API key
requirements.txt
core/
  story_reader.py           # B1: đọc & chuẩn hóa TXT (đa encoding)
  story_analyzer.py         # B2: phân tích nhân vật/bối cảnh/timeline/cảm xúc
  scene_splitter.py         # B3: cắt cảnh 6–8s theo thứ tự
  veo_prompt_generator.py   # B4: sinh prompt Veo theo lô
  formatter.py              # B5a: làm sạch & đánh số SCENE_XX
  validator.py              # B5b: kiểm tra format/markdown/timecode/thoại
  exporter.py               # xuất TXT + JSON log
services/
  ai_client.py              # interface + retry/timeout + factory
  gemini_client.py          # REST Gemini
  claude_client.py          # REST Claude
ui/
  main_window.py            # GUI CustomTkinter
utils/
  file_utils.py             # đọc/ghi file đa encoding
  json_utils.py             # trích JSON từ phản hồi AI
  logger.py                 # log ra console + GUI
```

## 7. Logic xử lý

- **B1 Đọc:** thử lần lượt UTF-8-SIG, UTF-8, Windows-1258, Windows-1252, latin-1. File rỗng → báo lỗi.
- **B2 Phân tích:** gọi AI lấy nhân vật (tuổi/giới tính/ngoại hình/trang phục), bối cảnh, timeline, cảm xúc, cao trào, kết thúc.
- **B3 Cắt cảnh:** tính số từ theo `TOKENS_PER_SECOND` × thời lượng; cắt tại ranh giới câu/mệnh đề; nếu đặt Max scenes thì gộp để không vượt quá.
- **B4 Sinh prompt:** gửi từng lô (mặc định 12 cảnh) kèm "character bible" để giữ consistency; ghép thêm visual style + aspect ratio + 4K.
- **B5 Validate & format:** ép mỗi prompt về 1 dòng, bỏ markdown/timecode/thoại, đánh lại số `SCENE_01…`, nối bằng 2 dòng trống. Tự sửa nếu AI trả sai format.

## 8. Xử lý lỗi

- Thiếu API key → báo lỗi rõ ràng.
- Key sai (HTTP 401/403) → dừng, không retry.
- Lỗi mạng / 429 / 5xx → tự retry với backoff (mặc định 3 lần).
- Truyện quá dài → tự chia lô khi gửi AI, vẫn giữ đúng thứ tự cảnh.
- AI trả sai số phần tử → bù/cắt cho khớp, không vỡ thứ tự.

## 9. Tinh chỉnh

Sửa trong `config.py`: `TOKENS_PER_SECOND` (nhịp đọc), `BATCH_SIZE`, `MAX_RETRIES`, `REQUEST_TIMEOUT`, danh sách model, các `STYLE_ANCHORS`.

## 10. Dùng cổng trung gian (9Router / proxy OpenAI-compatible)

Nếu API key của bạn là của một cổng trung gian (ví dụ **9Router – llm.chiasegpu.vn**) chứ không phải key gốc của Anthropic/Google:

1. **AI provider** → chọn **OpenAI-compatible**.
2. **Base URL** → nhập đúng base, ví dụ `https://llm.chiasegpu.vn/v1` (đã điền sẵn).
3. **API key** → dán key của cổng (dạng `sk-...`).
4. **Model** → nhập đúng tên model cổng cung cấp, ví dụ `ant/claude-opus-4-6`.

Tool sẽ gọi `POST {Base URL}/chat/completions` theo chuẩn OpenAI với `Authorization: Bearer <key>`.

## 11. Cập nhật phiên bản cho nhân viên (in-app updater)

Phần mềm có mục **PHIEN BAN & CAP NHAT** với nút **"Kiem tra cap nhat"**.

Cách thiết lập (admin làm 1 lần):
1. Up bản mới (file .zip hoặc .exe) lên một nơi có link tải trực tiếp: GitHub Releases, Google Drive (link direct), Dropbox (?dl=1), hoặc server công ty.
2. Tạo file `version.json` (xem `version_manifest_MAU.json`) trỏ tới bản mới, đặt online ở một URL cố định:
   ```json
   { "version": "1.12.0", "url": "https://.../GNM_Auto_Veo_AUDIO_v13.zip", "notes": "..." }
   ```
3. Dán URL của `version.json` vào ô **URL cap nhat** trong app (chỉ cần 1 lần, app tự lưu). Hoặc đặt sẵn trong `config.py` → `UPDATE_MANIFEST_URL`.

Nhân viên: khi mở app, nếu có bản mới sẽ hiện thông báo; bấm **Kiem tra cap nhat** → đồng ý → app tải bản mới về **Downloads** và mở thư mục. Đóng app, giải nén đè (hoặc thay file .exe), mở lại là xong.

Mỗi lần ra bản mới, chỉ cần cập nhật `version.json` (đổi version + url) là toàn bộ nhân viên thấy.
