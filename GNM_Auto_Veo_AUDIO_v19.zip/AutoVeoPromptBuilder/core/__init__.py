"""Core pipeline: reader, analyzer, splitter, generator, formatter, validator, exporter."""
