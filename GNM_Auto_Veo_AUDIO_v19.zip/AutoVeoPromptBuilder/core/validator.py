"""Bước 5 (phần kiểm tra): validate output cuối cùng."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

_TIMECODE = re.compile(r"\b\d{1,2}:\d{2}(?::\d{2})?\b")
# Không tính dấu gạch dưới "_" là markdown vì nhãn SCENE_01 có chứa nó.
_MD = re.compile(r"[*`#>]")
_SPEECH = re.compile(
    r"\b(voiceover|voice-over|narration|narrator|dialogue|subtitle|caption)\b",
    re.IGNORECASE,
)
_SCENE_LINE = re.compile(r"^SCENE_\d{2,}: .+$")


@dataclass
class ValidationResult:
    ok: bool
    issues: list[str] = field(default_factory=list)
    scene_count: int = 0


def validate_output(text: str) -> ValidationResult:
    """Kiểm tra nội dung file output có đúng chuẩn không."""
    issues: list[str] = []

    blocks = [b for b in text.strip().split("\n\n\n")]
    scene_lines = [b for b in blocks if b.strip()]

    seen: set[str] = set()
    expected_idx = 1
    for b in scene_lines:
        if "\n" in b.strip():
            issues.append(f"Mot scene bi xuong dong: {b[:40]!r}")
        if not _SCENE_LINE.match(b.strip()):
            issues.append(f"Sai format dong: {b[:40]!r}")
            continue
        label = b.split(":", 1)[0].strip()
        if label in seen:
            issues.append(f"Trung scene: {label}")
        seen.add(label)
        num = int(label.split("_")[1])
        if num != expected_idx:
            issues.append(f"So thu tu khong lien tuc tai {label} (mong doi {expected_idx}).")
        expected_idx += 1

    if _MD.search(text):
        issues.append("Con ky tu markdown (* ` # >).")
    if _TIMECODE.search(text):
        issues.append("Con timecode dang mm:ss.")
    if _SPEECH.search(text):
        issues.append("Con nhan voiceover/dialogue/narration.")

    if not scene_lines:
        issues.append("Khong co scene nao.")

    return ValidationResult(ok=not issues, issues=issues, scene_count=len(scene_lines))
