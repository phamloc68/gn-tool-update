"""Bước 5 (phần định dạng): làm sạch & đánh số output đúng chuẩn SCENE_XX."""
from __future__ import annotations

import re
import unicodedata

# Các nhãn không được phép xuất hiện ở đầu nội dung prompt.
_LEAD_LABELS = re.compile(
    r"^\s*(scene|sence|canh|cảnh|prompt|shot)[ _\-]*\d*\s*[:\.\)\-]\s*",
    re.IGNORECASE,
)
_LEAD_BULLET = re.compile(r"^\s*(?:[-*•]|\d+[\.\)])\s+")
_TIMECODE = re.compile(r"\b\d{1,2}:\d{2}(?::\d{2})?\b")
_MD_CHARS = re.compile(r"[*_`#>]+")
_SPEECH = re.compile(
    r"\b(voiceover|voice-over|narration|narrator|dialogue|subtitle|caption|"
    r"thoại|lời thoại|thuyết minh|phụ đề)\s*:?",
    re.IGNORECASE,
)


def strip_diacritics(text: str) -> str:
    """Bỏ dấu tiếng Việt / mọi dấu phụ -> ASCII (Tư Mộc -> Tu Moc).

    Giúp Veo không bị lỗi parser khi gặp ký tự có dấu.
    """
    if not text:
        return text
    text = text.replace("đ", "d").replace("Đ", "D")
    nfkd = unicodedata.normalize("NFD", text)
    return "".join(c for c in nfkd if not unicodedata.combining(c))


# Bộ lọc tự thay từ/cụm rủi ro bằng từ an toàn (lưới an toàn tầng code).
# Thứ tự: cụm dài trước, từ đơn sau.
_SANITIZE = [
    (r"fish entrails", "fish scraps"),
    (r"\bentrails\b", "refuse"),
    (r"\brice wine\b", "tea"),
    (r"\bwine cups?\b", "tea cup"),
    (r"\bwine\b", "tea"),
    (r"\bdrunken\b", "tired"),
    (r"\bdrunk\b", "tired"),
    (r"\bintoxicated\b", "tired"),
    (r"\bdissolute\b", "relaxed"),
    (r"\bheavy[- ]lidded\b", "tired"),
    (r"\bdazed\b", "absent"),
    (r"\bexposed\b", "uncovered"),
    (r"\bbare torso\b", "simple clothing"),
    (r"\bbare chest\b", "simple clothing"),
    (r"\bin only (threadbare )?(cotton )?shorts\b", "in rumpled clothes"),
    (r"\bonly (cotton )?shorts\b", "rumpled clothes"),
    (r"\bnearly naked\b", "disheveled"),
    (r"\bhalf[- ]naked\b", "disheveled"),
    (r"\bnaked\b", "disheveled"),
    (r"\bnude\b", "disheveled"),
    (r"\bnudity\b", "plain clothing"),
    (r"(both )?hands? pressed[^,.;]*?mouth", "a hand resting on the chest"),
    (r"(both )?hands? (clutching|gripping|clamped over)[^,.;]*?mouth", "a hand resting on the chest"),
    (r"clutching (his|her|their) (own )?head[^,.;]*", "holding a bowed head"),
    (r"gripping (his|her|their) (own )?head[^,.;]*", "holding a bowed head"),
    (r"\bmarching (him|her|them)\b", r"escorting \1"),
    (r"\bdragging (him|her|them)\b", r"escorting \1"),
    (r"grip(?:s|ping)?[^,.;]*?\barms?\b", "walking beside him"),
    (r"grip(?:s|ping)?[^,.;]*?\bcollar\b", "gestures firmly near him"),
    (r"grab(?:s|bing)?[^,.;]*?\bcollar\b", "gestures firmly near him"),
    (r"\btearing[^,.;]*?(?:clothes|silk|fabric|tunic|garments?)", "gesturing at the garments"),
    (r"\bripping[^,.;]*?(?:clothes|silk|fabric|tunic|garments?)", "gesturing at the garments"),
    (r"\bgrabbing\b", "reaching toward"),
    (r"\bgrab\b", "reach toward"),
    (r"\bpure terror\b", "alarm"),
    (r"\bterrified\b", "startled"),
    (r"\bterror\b", "fear"),
    (r"\bfrantically\b", "anxiously"),
    (r"\bfrantic\b", "worried"),
    (r"\bdesperately\b", "anxiously"),
    (r"\bdesperate\b", "anxious"),
    (r"\bgaunt\b", "thin"),
    (r"\bemaciated\b", "thin"),
    (r"\bskeletal\b", "thin"),
    (r"\bstarving\b", "weary"),
    (r"\bstarved\b", "weary"),
    (r"\bhungry\b", "weary"),
    (r"\bhunger\b", "longing"),
    (r"\bcreeping dread\b", "quiet unease"),
    (r"\bdread\b", "unease"),
    (r"\bominous\b", "somber"),
    (r"\bsinister\b", "grim"),
    (r"\bmenacing\b", "stern"),
    (r"\beerie\b", "quiet"),
    (r"\bnightmarish\b", "grim"),
    (r"\bhorror\b", "gloom"),
    (r"\bmirage\b", "daydream"),
    (r"\bhallucinations?\b", "daydream"),
    (r"\bapparition\b", "figure"),
    (r"\b(?:gold|silver) coins?\b", "small keepsakes"),
    (r"\bcoins?\b", "keepsakes"),
    (r"\bgambling\b", "a card game"),
    (r"\bcasino\b", "gaming hall"),
    (r"\bpoverty\b", "hardship"),
    (r"\bdestitute\b", "humble"),
    (r"\bwretched\b", "weary"),
    (r"\bmiserable\b", "sorrowful"),
    (r"\bpoor\b", "humble"),
    (r"\bbloody\b", ""),
    (r"\bblood\b", ""),
    (r"\bgore\b", ""),
    (r"\bgory\b", ""),
    (r"\bwounds?\b", "marks"),
]


def sanitize(text: str) -> str:
    """Thay các từ/cụm dễ bị Veo chặn bằng từ an toàn."""
    for pat, rep in _SANITIZE:
        text = re.sub(pat, rep, text, flags=re.IGNORECASE)
    return text


def clean_line(text: str) -> str:
    """Ép 1 prompt về đúng 1 dòng, bỏ markdown / nhãn / timecode / thoại."""
    if not text:
        return ""
    t = text.replace("\r", " ").replace("\n", " ")
    t = _MD_CHARS.sub("", t)            # bỏ ký tự markdown
    t = _LEAD_LABELS.sub("", t)         # bỏ "SCENE_01:" nếu AI tự thêm
    t = _LEAD_BULLET.sub("", t)         # bỏ gạch đầu dòng
    t = _SPEECH.sub("", t)              # bỏ nhãn voiceover/dialogue
    t = _TIMECODE.sub("", t)            # bỏ timecode
    t = re.sub(r'^[\s"“”\']+|[\s"“”\']+$', "", t)  # bỏ ngoặc kép bao quanh
    t = sanitize(t)                        # thay tu rui ro bang tu an toan
    t = strip_diacritics(t)                # bỏ dấu tiếng Việt cho an toàn với Veo
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"\s+([,.;])", r"\1", t)    # dọn khoảng trắng trước dấu câu
    t = re.sub(r",\s*,", ", ", t)          # gộp dấu phẩy đôi do thay từ
    t = re.sub(r"\s{2,}", " ", t).strip()
    return t


def pad_width(total: int) -> int:
    """Độ rộng số thứ tự: 2 chữ số, mở rộng khi >99."""
    return max(2, len(str(total)))


def scene_label(index_one_based: int, total: int, prefix: str = "SCENE_") -> str:
    return f"{prefix}{str(index_one_based).zfill(pad_width(total))}"


PLACEHOLDER = "[CHUA TAO DUOC - bam Lam lai canh loi]"


def build_output(prompts: list[str], prefix: str = "SCENE_",
                 keep_slots: bool = True) -> str:
    """Tạo nội dung file cuối: mỗi cảnh 1 dòng, cách nhau đúng 2 dòng trống.

    keep_slots=True: cảnh lỗi (rỗng) vẫn giữ chỗ + đánh số đúng, ghi PLACEHOLDER
    để biết cảnh nào cần làm lại. keep_slots=False: bỏ cảnh rỗng (dồn số lại).
    """
    if keep_slots:
        items = [clean_line(p) if p.strip() else PLACEHOLDER for p in prompts]
    else:
        items = [clean_line(p) for p in prompts if p.strip()]
    total = len(items)
    blocks = [f"{scene_label(i + 1, total, prefix)}: {c}" for i, c in enumerate(items)]
    return "\n\n\n".join(blocks) + "\n"
