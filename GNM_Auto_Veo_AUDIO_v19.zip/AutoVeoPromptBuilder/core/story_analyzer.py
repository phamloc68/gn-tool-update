"""Bước 2: Phân tích câu chuyện bằng AI (nhân vật, bối cảnh, timeline, cảm xúc...)."""
from __future__ import annotations

from typing import Any, Optional

from config import ANALYZE_MAX_CHARS, ANALYZE_MAX_TOKENS
from services.ai_client import AIClient
from utils.json_utils import extract_json_object
from utils.logger import Logger

_ANALYSIS_SYSTEM = (
    "You are a story analyst for cinematic adaptation. Read the story and extract a "
    "structured analysis. Return ONLY a JSON object (no markdown, no commentary)."
)


def analyze_story(client: AIClient, text: str, language: str = "English",
                  logger: Optional[Logger] = None) -> dict[str, Any]:
    """Gọi AI để phân tích story. Trả về dict; nếu lỗi nhẹ vẫn trả về dict tối thiểu."""
    log = logger or Logger()
    excerpt = text[:ANALYZE_MAX_CHARS]
    if len(text) > ANALYZE_MAX_CHARS:
        log.warn(f"Truyện dài {len(text)} ký tự, chỉ gửi {ANALYZE_MAX_CHARS} ký tự đầu để phân tích.")

    user = (
        f"Analyze the following story. Write all field values in {language}.\n"
        "Return a JSON object with EXACTLY these keys:\n"
        '{\n'
        '  "characters": [ {"name": "", "age": "", "gender": "", "appearance": "", "clothing": ""} ],\n'
        '  "settings": [ "" ],\n'
        '  "timeline": [ "" ],\n'
        '  "mood": "",\n'
        '  "key_actions": [ "" ],\n'
        '  "climax": "",\n'
        '  "ending": ""\n'
        "}\n\n"
        "STORY:\n" + excerpt
    )

    log.info("Đang phân tích câu chuyện bằng AI…")
    raw = client.generate(_ANALYSIS_SYSTEM, user, max_tokens=ANALYZE_MAX_TOKENS, temperature=0.3)
    try:
        analysis = extract_json_object(raw)
    except ValueError as exc:
        log.warn(f"Không parse được phân tích ({exc}). Dùng phân tích rỗng, vẫn tiếp tục được.")
        analysis = {
            "characters": [], "settings": [], "timeline": [],
            "mood": "", "key_actions": [], "climax": "", "ending": "",
        }
    n_char = len(analysis.get("characters", []) or [])
    log.info(f"Phân tích xong: {n_char} nhân vật, mood = {analysis.get('mood', '')!r}.")
    return analysis


def analysis_to_brief(analysis: dict[str, Any]) -> str:
    """Rút gọn analysis thành đoạn text 'character bible' để chèn vào prompt sinh cảnh."""
    lines: list[str] = []
    chars = analysis.get("characters") or []
    if chars:
        lines.append("CHARACTERS (keep appearance consistent in every scene):")
        for c in chars:
            if not isinstance(c, dict):
                continue
            desc = ", ".join(
                str(c.get(k, "")).strip() for k in ("age", "gender", "appearance", "clothing")
                if str(c.get(k, "")).strip()
            )
            name = str(c.get("name", "")).strip() or "Unnamed"
            lines.append(f"- {name}: {desc}")
    settings = analysis.get("settings") or []
    if settings:
        lines.append("SETTINGS: " + "; ".join(str(s) for s in settings))
    mood = str(analysis.get("mood", "")).strip()
    if mood:
        lines.append("OVERALL MOOD: " + mood)
    return "\n".join(lines)
