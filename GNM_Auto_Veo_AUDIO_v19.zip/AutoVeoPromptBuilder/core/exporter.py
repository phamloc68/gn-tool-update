"""Bước cuối: xuất file TXT prompt + JSON log."""
from __future__ import annotations

import datetime as _dt
import json
import os
from dataclasses import dataclass

from utils.file_utils import ensure_dir, write_text_file


@dataclass
class ExportMeta:
    input_file: str
    ai_provider: str
    model: str
    total_scenes: int
    scene_duration: str
    aspect_ratio: str
    visual_style: str
    language: str


@dataclass
class ExportResult:
    txt_path: str
    json_path: str


def export(output_dir: str, prompts_text: str, meta: ExportMeta) -> ExportResult:
    """Ghi veo_prompts_YYYYMMDD_HHMMSS.txt và .json. Trả về đường dẫn."""
    if not output_dir:
        raise ValueError("Chưa chọn thư mục output.")
    ensure_dir(output_dir)

    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    txt_name = f"veo_prompts_{stamp}.txt"
    json_name = f"veo_prompts_{stamp}.json"
    txt_path = os.path.join(output_dir, txt_name)
    json_path = os.path.join(output_dir, json_name)

    write_text_file(txt_path, prompts_text)

    log_obj = {
        "input_file": meta.input_file,
        "output_file": txt_path,
        "ai_provider": meta.ai_provider,
        "model": meta.model,
        "total_scenes": meta.total_scenes,
        "scene_duration": meta.scene_duration,
        "aspect_ratio": meta.aspect_ratio,
        "visual_style": meta.visual_style,
        "language": meta.language,
        "created_at": _dt.datetime.now().isoformat(timespec="seconds"),
    }
    write_text_file(json_path, json.dumps(log_obj, ensure_ascii=False, indent=2))

    return ExportResult(txt_path=txt_path, json_path=json_path)
