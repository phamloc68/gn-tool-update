"""Bước 3: Cắt câu chuyện thành các phân cảnh 6–8 giây (theo thứ tự, không dùng AI)."""
from __future__ import annotations

import re
from typing import Optional

from config import TOKENS_PER_SECOND
from core.story_reader import word_count
from utils.logger import Logger


def _count(s: str) -> int:
    return word_count(s)


def _segments(text: str) -> list[str]:
    """Tách thành các mệnh đề nhỏ theo dấu câu (kết câu rồi đến phẩy/chấm phẩy)."""
    text = re.sub(r"\s+", " ", text).strip()
    sentences = re.split(r"(?<=[.!?…])\s+", text)
    segs: list[str] = []
    for sent in sentences:
        for clause in re.split(r"(?<=[,;:])\s+", sent):
            clause = clause.strip()
            if clause:
                segs.append(clause)
    return segs


def split_scenes(text: str, duration_sec: int, max_scenes: Optional[int] = None,
                 logger: Optional[Logger] = None) -> list[str]:
    """Trả về danh sách đoạn text theo đúng thứ tự, mỗi đoạn ~ duration_sec giây.

    - duration_sec: 6, 7 hoặc 8.
    - max_scenes: None = Auto; nếu là số, đảm bảo tổng cảnh KHÔNG vượt quá số này
      (bằng cách gộp đoạn cho dài hơn).
    """
    log = logger or Logger()
    total_words = _count(text)
    if total_words == 0:
        return []

    target = max(1, round(duration_sec * TOKENS_PER_SECOND))
    max_syl = round((duration_sec + 0.7) * TOKENS_PER_SECOND)  # nới nhẹ trần

    # Nếu giới hạn số cảnh: tăng target để tổng số cảnh <= max_scenes.
    if max_scenes and max_scenes > 0:
        needed_target = total_words / max_scenes
        if needed_target > target:
            target = round(needed_target)
            max_syl = round(needed_target * 1.25)
            log.info(f"Giới hạn ≤{max_scenes} cảnh → mỗi cảnh ~{target} từ.")

    segs = _segments(text)
    chunks: list[str] = []
    cur = ""
    for seg in segs:
        cand = f"{cur} {seg}".strip() if cur else seg
        if cur and _count(cand) > max_syl:
            chunks.append(cur)
            cur = seg
        else:
            cur = cand
        if _count(cur) >= target:
            chunks.append(cur)
            cur = ""
    if cur.strip():
        chunks.append(cur.strip())

    # Hard-split đoạn quá dài (1 mệnh đề dài hơn trần) theo từ.
    final: list[str] = []
    for ch in chunks:
        if _count(ch) <= max_syl:
            final.append(ch)
            continue
        words = ch.split()
        buf: list[str] = []
        for w in words:
            buf.append(w)
            if len(buf) >= target:
                final.append(" ".join(buf))
                buf = []
        if buf:
            final.append(" ".join(buf))

    # Nếu vẫn vượt max_scenes (hiếm), gộp các cảnh cuối.
    if max_scenes and max_scenes > 0 and len(final) > max_scenes:
        final = _merge_to_limit(final, max_scenes)

    log.info(f"Đã tách {len(final)} phân cảnh (mục tiêu ~{duration_sec}s/cảnh, ~{target} từ/cảnh).")
    return final


def _merge_to_limit(chunks: list[str], limit: int) -> list[str]:
    """Gộp tuần tự cho tới khi số cảnh <= limit."""
    while len(chunks) > limit:
        # tìm cặp liền kề ngắn nhất để gộp
        idx = min(range(len(chunks) - 1), key=lambda i: _count(chunks[i]) + _count(chunks[i + 1]))
        chunks[idx] = f"{chunks[idx]} {chunks[idx + 1]}".strip()
        del chunks[idx + 1]
    return chunks
