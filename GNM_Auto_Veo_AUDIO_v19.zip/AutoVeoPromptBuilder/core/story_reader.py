"""Bước 1: Đọc & chuẩn hóa nội dung file truyện."""
from __future__ import annotations

import re

from utils.file_utils import read_text_file


def read_story(path: str) -> str:
    """Đọc file .txt, chuẩn hóa xuống dòng và khoảng trắng thừa.

    Ném ValueError nếu file rỗng (đã xử lý trong read_text_file).
    """
    raw = read_text_file(path)
    # Chuẩn hóa CRLF -> LF, gộp nhiều dòng trống
    text = raw.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.strip()
    if not text:
        raise ValueError("Nội dung truyện rỗng sau khi chuẩn hóa.")
    return text


def word_count(text: str) -> int:
    """Đếm số 'token' (âm tiết/từ) theo khoảng trắng — phù hợp cả tiếng Việt."""
    return len([w for w in re.split(r"\s+", text.strip()) if w])
