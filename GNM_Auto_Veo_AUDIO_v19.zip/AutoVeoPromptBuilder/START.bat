@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"
title GNM Auto Veo AUDIO

echo ===================================================
echo    GNM AUTO VEO AUDIO - Khoi dong
echo ===================================================
echo.

REM ====== 1) Tim Python ======
set "PYEXE="
for %%P in (py python) do (
  if not defined PYEXE (
    %%P -c "import sys" >nul 2>&1 && set "PYEXE=%%P"
  )
)

REM ====== 2) Neu chua co Python -> tu tai va cai ======
if not defined PYEXE (
  set "PYVER=3.12.7"
  set "PYINST=%TEMP%\python-!PYVER!-amd64.exe"
  echo [1/3] May chua co Python. Dang tai Python !PYVER! ...
  powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -Uri ('https://www.python.org/ftp/python/!PYVER!/python-!PYVER!-amd64.exe') -OutFile '!PYINST!' } catch { exit 1 }"
  if errorlevel 1 ( echo     ^>^> Tai Python that bai. Kiem tra internet roi chay lai. & pause & exit /b 1 )
  echo [1/3] Dang cai Python ^(im lang, 1-2 phut^) ...
  "!PYINST!" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_launcher=1
  for %%D in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%ProgramFiles%\Python312\python.exe"
  ) do ( if not defined PYEXE if exist %%D set "PYEXE=%%~D" )
  if not defined PYEXE ( echo     ^>^> Da cai nhung chua thay python.exe. Mo lai file nay. & pause & exit /b 1 )
)

REM ====== 3) Cai thu vien lan dau ======
if not exist ".installed" (
  echo [2/3] Dang cai thu vien can thiet ^(chi lan dau^) ...
  "!PYEXE!" -m pip install --upgrade pip
  "!PYEXE!" -m pip install -r requirements.txt
  if errorlevel 1 ( echo     ^>^> Cai thu vien that bai. & pause & exit /b 1 )
  echo installed> ".installed"
)

REM ====== 4) Suy ra pythonw (chay KHONG hien cmd) ======
set "PYW=!PYEXE!"
if /I "!PYEXE!"=="py" set "PYW=pyw"
if /I "!PYEXE!"=="python" set "PYW=pythonw"
set "PYW=!PYW:python.exe=pythonw.exe!"

REM ====== 5) Mo phan mem (khong console) roi thoat ======
echo [3/3] Dang mo phan mem ...
start "" "!PYW!" "%~dp0app.py"
exit /b 0
