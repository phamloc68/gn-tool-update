"""Interface chung cho các AI provider + factory."""
from __future__ import annotations

import abc
import time
from typing import Optional

import requests

from config import MAX_RETRIES, RETRY_BACKOFF
from utils.logger import Logger


class AIError(Exception):
    """Lỗi khi gọi AI provider."""


class AIClient(abc.ABC):
    """Lớp cơ sở cho mọi AI client."""

    def __init__(self, api_key: str, model: str, logger: Optional[Logger] = None) -> None:
        if not api_key or not api_key.strip():
            raise AIError("Thiếu API key. Vui lòng nhập API key trên giao diện hoặc trong file .env.")
        self.api_key = api_key.strip()
        self.model = model.strip()
        self.logger = logger or Logger()

    @abc.abstractmethod
    def _do_request(self, system: str, user: str, max_tokens: int, temperature: float) -> str:
        """Gọi API thật, trả về text. Ném AIError nếu lỗi."""

    def generate(self, system: str, user: str, *, max_tokens: int = 8192,
                 temperature: float = 0.7) -> str:
        """Gọi AI với cơ chế retry + backoff."""
        last_err: Optional[Exception] = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                return self._do_request(system, user, max_tokens, temperature)
            except AIError:
                raise  # lỗi cấu hình/khóa: không retry
            except (requests.RequestException, ValueError) as exc:
                last_err = exc
                wait = RETRY_BACKOFF * (2 ** (attempt - 1))
                self.logger.warn(
                    f"Gọi API lỗi (lần {attempt}/{MAX_RETRIES}): {exc}. Thử lại sau {wait:.0f}s…"
                )
                if attempt < MAX_RETRIES:
                    time.sleep(wait)
        raise AIError(f"Gọi API thất bại sau {MAX_RETRIES} lần. Lỗi cuối: {last_err}")


def get_client(provider: str, api_key: str, model: str,
               logger: Optional[Logger] = None, base_url: str = "") -> AIClient:
    """Factory chọn client theo provider. base_url chỉ dùng cho OpenAI-compatible."""
    from services.gemini_client import GeminiClient
    from services.claude_client import ClaudeClient
    from services.openai_client import OpenAICompatClient

    provider_norm = (provider or "").strip().lower()
    if provider_norm == "gemini":
        return GeminiClient(api_key, model, logger)
    if provider_norm == "claude":
        return ClaudeClient(api_key, model, logger)
    if provider_norm in ("openai-compatible", "openai compatible", "openai", "router9", "9router"):
        return OpenAICompatClient(api_key, model, logger, base_url=base_url)
    raise AIError(f"Provider không hỗ trợ: {provider}")
