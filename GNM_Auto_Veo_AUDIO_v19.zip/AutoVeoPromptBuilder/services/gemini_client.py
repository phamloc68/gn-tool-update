"""Client gọi Google Gemini qua REST (Generative Language API)."""
from __future__ import annotations

import requests

from config import REQUEST_TIMEOUT
from services.ai_client import AIClient, AIError

_BASE = "https://generativelanguage.googleapis.com/v1beta/models"


class GeminiClient(AIClient):
    """Gọi Gemini generateContent."""

    def _do_request(self, system: str, user: str, max_tokens: int, temperature: float) -> str:
        url = f"{_BASE}/{self.model}:generateContent"
        payload = {
            "system_instruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": user}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
            },
        }
        resp = requests.post(
            url,
            params={"key": self.api_key},
            json=payload,
            timeout=REQUEST_TIMEOUT,
            headers={"Content-Type": "application/json"},
        )
        if resp.status_code == 401 or resp.status_code == 403:
            raise AIError(f"Gemini từ chối API key (HTTP {resp.status_code}). Kiểm tra lại key.")
        if not resp.ok:
            # 429 / 5xx: ném ValueError để lớp cha retry
            raise ValueError(f"Gemini HTTP {resp.status_code}: {resp.text[:300]}")

        data = resp.json()
        try:
            candidates = data["candidates"]
            parts = candidates[0]["content"]["parts"]
            return "".join(p.get("text", "") for p in parts)
        except (KeyError, IndexError, TypeError) as exc:
            # Có thể bị chặn an toàn nội dung
            block = data.get("promptFeedback", {})
            raise AIError(f"Gemini không trả về nội dung hợp lệ: {exc}. Feedback: {block}")
