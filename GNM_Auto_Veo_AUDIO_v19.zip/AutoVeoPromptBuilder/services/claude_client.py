"""Client gọi Anthropic Claude qua REST (Messages API)."""
from __future__ import annotations

import requests

from config import REQUEST_TIMEOUT
from services.ai_client import AIClient, AIError

_URL = "https://api.anthropic.com/v1/messages"
_VERSION = "2023-06-01"


class ClaudeClient(AIClient):
    """Gọi Claude Messages API."""

    def _do_request(self, system: str, user: str, max_tokens: int, temperature: float) -> str:
        headers = {
            "content-type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": _VERSION,
        }
        payload = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        }
        resp = requests.post(_URL, json=payload, headers=headers, timeout=REQUEST_TIMEOUT)
        if resp.status_code in (401, 403):
            raise AIError(f"Claude từ chối API key (HTTP {resp.status_code}). Kiểm tra lại key.")
        if not resp.ok:
            raise ValueError(f"Claude HTTP {resp.status_code}: {resp.text[:300]}")

        data = resp.json()
        try:
            blocks = data["content"]
            return "".join(b.get("text", "") for b in blocks if b.get("type") == "text")
        except (KeyError, TypeError) as exc:
            raise AIError(f"Claude không trả về nội dung hợp lệ: {exc}. Raw: {str(data)[:300]}")
