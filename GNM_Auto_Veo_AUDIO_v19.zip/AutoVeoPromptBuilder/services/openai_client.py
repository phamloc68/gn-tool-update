"""Client gọi cổng OpenAI-compatible (9Router, proxy nội bộ...) qua /v1/chat/completions."""
from __future__ import annotations

import json
from typing import Optional

import requests

from config import REQUEST_TIMEOUT
from services.ai_client import AIClient, AIError
from utils.logger import Logger


class OpenAICompatClient(AIClient):
    """Gọi endpoint chuẩn OpenAI Chat Completions với Bearer token.

    Phù hợp cho 9Router (https://llm.chiasegpu.vn/v1) và mọi proxy tương thích.
    """

    def __init__(self, api_key: str, model: str, logger: Optional[Logger] = None,
                 base_url: str = "") -> None:
        super().__init__(api_key, model, logger)
        if not base_url or not base_url.strip():
            raise AIError("Thiếu Base URL cho provider OpenAI-compatible "
                          "(ví dụ: https://llm.chiasegpu.vn/v1).")
        self.base_url = base_url.strip().rstrip("/")

    def _do_request(self, system: str, user: str, max_tokens: int, temperature: float) -> str:
        url = f"{self.base_url}/chat/completions"
        headers = {
            "content-type": "application/json",
            "accept": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,  # nhiều cổng mặc định streaming -> phải tắt để nhận JSON
        }
        resp = requests.post(url, json=payload, headers=headers, timeout=REQUEST_TIMEOUT)
        if resp.status_code in (401, 403):
            raise AIError(f"Cổng từ chối API key (HTTP {resp.status_code}). Kiểm tra lại key/Base URL.")
        if not resp.ok:
            raise ValueError(f"OpenAI-compatible HTTP {resp.status_code}: {resp.text[:400]}")

        body = resp.text or ""
        data = _parse_body(body)
        if data is None:
            # Body rỗng hoặc không phải JSON -> hiện nguyên văn để chẩn đoán, không retry vô ích.
            ctype = resp.headers.get("content-type", "?")
            raise AIError(
                "Cổng trả về dữ liệu không phải JSON hợp lệ "
                f"(content-type={ctype}, HTTP {resp.status_code}). "
                f"Nội dung thật: {body[:400]!r}. "
                "Gợi ý: kiểm tra lại Base URL (phải có /v1), tên Model, hoặc cổng có hỗ trợ /chat/completions không."
            )
        try:
            content = data["choices"][0]["message"]["content"]
            if isinstance(content, list):  # một số cổng trả content dạng mảng block
                content = "".join(p.get("text", "") if isinstance(p, dict) else str(p) for p in content)
            return content or ""
        except (KeyError, IndexError, TypeError) as exc:
            raise AIError(f"Cổng không trả về 'choices[].message.content': {exc}. Raw: {body[:400]}")


def _parse_body(body: str):
    """Parse JSON; nếu là stream SSE (data: {...}) thì gộp các mảnh lại."""
    body = body.strip()
    if not body:
        return None
    # Trường hợp JSON bình thường
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        pass
    # Trường hợp Server-Sent Events: nhiều dòng "data: {...}" + "data: [DONE]"
    if "data:" in body:
        text_parts: list[str] = []
        last_obj = None
        for line in body.splitlines():
            line = line.strip()
            if not line.startswith("data:"):
                continue
            chunk = line[len("data:"):].strip()
            if chunk == "[DONE]" or not chunk:
                continue
            try:
                obj = json.loads(chunk)
            except json.JSONDecodeError:
                continue
            last_obj = obj
            try:
                delta = obj["choices"][0].get("delta", {})
                if "content" in delta and delta["content"]:
                    text_parts.append(delta["content"])
            except (KeyError, IndexError, TypeError):
                continue
        if text_parts:
            return {"choices": [{"message": {"content": "".join(text_parts)}}]}
        return last_obj
    return None
