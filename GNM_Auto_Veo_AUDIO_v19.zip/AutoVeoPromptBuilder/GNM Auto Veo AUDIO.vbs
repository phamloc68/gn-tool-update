' ============================================================
'  GNM Auto Veo AUDIO - Mo phan mem (an cua so cmd)
'  Nhan dup file nay de chay. Lan dau se hien cua so cai dat.
' ============================================================
Option Explicit
Dim fso, sh, base, style
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")
base = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = base

' Lan dau (chua cai xong) -> hien cua so de thay tien trinh cai dat.
' Da cai roi -> chay an hoan toan, chi hien cua so phan mem.
If fso.FileExists(base & "\.installed") Then
  style = 0
Else
  style = 1
End If

sh.Run Chr(34) & base & "\START.bat" & Chr(34), style, False
