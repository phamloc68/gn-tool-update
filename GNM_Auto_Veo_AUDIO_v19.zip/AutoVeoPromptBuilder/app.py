"""Auto Veo Prompt Builder — điểm khởi chạy ứng dụng.

Chạy:  python app.py
"""
from __future__ import annotations

import sys


def main() -> None:
    try:
        from ui.main_window import main as run_ui
    except ImportError as exc:
        print("Thiếu thư viện. Hãy chạy: pip install -r requirements.txt")
        print(f"Chi tiết: {exc}")
        sys.exit(1)
    run_ui()


if __name__ == "__main__":
    main()
