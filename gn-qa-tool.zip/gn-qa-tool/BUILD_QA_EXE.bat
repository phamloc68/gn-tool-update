@echo off
cd /d "%~dp0"
echo ============================================
echo   BUILD GN QA TOOL -> file .exe cho nhan vien
echo ============================================
echo [1/2] Cai dependencies (full)...
call npm install
if errorlevel 1 ( echo LOI: npm install that bai. & pause & exit /b 1 )
echo [2/2] Dong goi .exe...
call npx --no-install electron-packager . "GN QA Tool" --platform=win32 --arch=x64 --out=release --overwrite --prune=true --ignore="^/release"
if errorlevel 1 ( echo LOI: dong goi that bai. & pause & exit /b 1 )
echo.
echo XONG! App nam trong thu muc: release\GN QA Tool-win32-x64\
echo Chay bang file: "GN QA Tool.exe"
pause
