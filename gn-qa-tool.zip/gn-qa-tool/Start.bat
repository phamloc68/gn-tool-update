@echo off
cd /d "%~dp0"
echo === GN QA Tool ===
if not exist "node_modules\electron" (
  echo Lan dau chay: dang cai dat... vui long doi.
  call npm install
)
call npx electron .
pause
