// QA routes. /default returns the built-in rubric so the UI can prefill it.
// /run does a two-round QA (fix -> re-check) and returns the cleaned script.
// /export returns the cleaned script as a .docx download.
const express = require('express');
const qa = require('../lib/qa');
const { exportBuffer } = require('../lib/exporter');
const router = express.Router();

router.get('/default', (req, res) => res.json({ rubric: qa.DEFAULT_RUBRIC }));
router.get('/rubrics', (req, res) => res.json({ rubrics: qa.RUBRICS, default: qa.DEFAULT_PRESET }));

router.post('/run', async (req, res) => {
  try {
    const { script, rubric, provider = 'openai', model } = req.body || {};
    const r = await qa.runQA({ script, rubric, provider, model });
    res.json(r);
  } catch (e) { res.status(500).json({ error: e.message || 'QA lỗi' }); }
});

router.post('/export', async (req, res) => {
  try {
    const { script, title } = req.body || {};
    if (!script) return res.status(400).json({ error: 'Thiếu nội dung.' });
    const { buffer, mime, ext } = await exportBuffer('docx', script, title || 'Kich ban QA');
    const name = (String(title || 'kich-ban-qa').replace(/[\\/:*?"<>|]+/g, ' ').trim() || 'kich-ban-qa') + '.' + ext;
    res.setHeader('Content-Type', mime);
    res.setHeader('Content-Disposition', 'attachment; filename="' + encodeURIComponent(name) + '"');
    res.send(buffer);
  } catch (e) { res.status(500).json({ error: e.message || 'Xuất file lỗi' }); }
});

router.post('/step', async (req, res) => {
  try {
    const { stage = 'fix', script, rubric, provider = 'openai', model } = req.body || {};
    const r = await qa.qaStep({ stage, script, rubric, provider, model });
    res.json(r);
  } catch (e) { res.status(500).json({ error: e.message || 'QA lỗi' }); }
});

module.exports = router;
