require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const { start } = require('./app');
const PORT = process.env.PORT || 3021;
start({ port: PORT }).then(({ port }) => {
  console.log('\n  GN QA Tool running on http://localhost:' + port + '\n');
}).catch((err) => { console.error('Failed to start:', err.message); process.exit(1); });
