// GN QA Tool — Electron main. Starts the embedded QA server + opens the window.
const { app, BrowserWindow, Menu, shell, dialog, ipcMain } = require('electron');
const { execFile, spawnSync } = require('child_process');
const path = require('path');
const fs = require('fs');

app.setName('GN QA Tool');
const userData = app.getPath('userData');
process.env.DATA_DIR = path.join(userData, 'data');
process.env.NODE_ENV = process.env.NODE_ENV || 'production';

let mainWindow = null;
let serverInfo = null;

async function startServer() {
  const { start } = require(path.join(__dirname, '..', 'server', 'app.js'));
  serverInfo = await start({ port: process.env.PORT ? Number(process.env.PORT) : 0 });
  return serverInfo.port;
}

function createWindow(port) {
  mainWindow = new BrowserWindow({
    width: 1180, height: 840, minWidth: 900, minHeight: 620,
    backgroundColor: '#0f1115', title: 'GN QA Tool',
    ...(function () { const ico = path.join(__dirname, '..', 'build', 'icon.png'); return fs.existsSync(ico) ? { icon: ico } : {}; })(),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false },
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  mainWindow.loadURL('http://localhost:' + port + '/');
  mainWindow.webContents.on('did-fail-load', (e, code, desc, url, isMainFrame) => {
    if (!isMainFrame) return;
    const html = '<body style="font-family:sans-serif;padding:24px;color:#1f2937"><h2 style="color:#b91c1c">Không tải được giao diện</h2><p>Mã lỗi: ' + code + ' — ' + desc + '</p><button onclick="location.reload()" style="padding:8px 16px;background:#4f46e5;color:#fff;border:none;border-radius:8px">Thử lại</button></body>';
    mainWindow.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
  });
  mainWindow.on('closed', () => (mainWindow = null));
}

function buildMenu() {
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'File', submenu: [{ role: 'reload' }, { role: 'forceReload' }, { type: 'separator' }, { role: 'quit' }] },
    { label: 'Edit', submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }] },
    { label: 'View', submenu: [{ role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' }, { role: 'toggleDevTools' }] },
  ]));
}

function extractZip(zip, dest) {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(dest, { recursive: true });
    execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', `Expand-Archive -LiteralPath '${zip}' -DestinationPath '${dest}' -Force`], (err) => (err ? reject(err) : resolve()));
  });
}
function copyOver(src, dst, skip) {
  for (const name of fs.readdirSync(src)) {
    if (skip.includes(name)) continue;
    const sp = path.join(src, name), dp = path.join(dst, name), st = fs.statSync(sp);
    if (st.isDirectory()) { fs.mkdirSync(dp, { recursive: true }); copyOver(sp, dp, skip); }
    else { try { fs.copyFileSync(sp, dp); } catch (_) {} }
  }
}
function newestZipInDownloads() {
  try {
    const dir = app.getPath('downloads');
    const cands = fs.readdirSync(dir).filter((n) => /gn[-_]?qa[-_]?tool.*\.zip$/i.test(n))
      .map((n) => ({ p: path.join(dir, n), t: fs.statSync(path.join(dir, n)).mtimeMs })).sort((a, b) => b.t - a.t);
    return cands.length ? cands[0].p : null;
  } catch (_) { return null; }
}

ipcMain.handle('app-update', async (_evt, opts) => {
  opts = opts || {};
  try {
    let zip = null;
    if (opts.url && /^https?:\/\//i.test(opts.url)) {
      let res; try { res = await fetch(opts.url); } catch (e) { return { ok: false, error: 'Không tải được bản cập nhật: ' + e.message }; }
      if (!res || !res.ok) return { ok: false, error: 'Link cập nhật lỗi (HTTP ' + (res && res.status) + ').' };
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length < 1000 || buf.slice(0, 2).toString() !== 'PK') return { ok: false, error: 'Link không trả về file zip hợp lệ.' };
      zip = path.join(app.getPath('temp'), 'gn-qa-dl-' + Date.now() + '.zip'); fs.writeFileSync(zip, buf);
    }
    if (!zip) zip = newestZipInDownloads();
    if (!zip) {
      const r = await dialog.showOpenDialog(mainWindow, { title: 'Chọn file cập nhật (.zip)', properties: ['openFile'], filters: [{ name: 'Zip', extensions: ['zip'] }] });
      if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
      zip = r.filePaths[0];
    }
    const appRoot = path.join(__dirname, '..');
    const tmp = path.join(app.getPath('temp'), 'gn-qa-update-' + Date.now());
    await extractZip(zip, tmp);
    let src = tmp;
    if (fs.existsSync(path.join(tmp, 'gn-qa-tool'))) src = path.join(tmp, 'gn-qa-tool');
    else { const dirs = fs.readdirSync(tmp).filter((n) => fs.statSync(path.join(tmp, n)).isDirectory()); if (dirs.length === 1) src = path.join(tmp, dirs[0]); }
    if (!fs.existsSync(path.join(src, 'server', 'app.js'))) return { ok: false, error: 'File zip không đúng (thiếu server/app.js).' };
    let needInstall = false;
    try {
      const oldPkg = JSON.parse(fs.readFileSync(path.join(appRoot, 'package.json'), 'utf8'));
      const newPkg = JSON.parse(fs.readFileSync(path.join(src, 'package.json'), 'utf8'));
      needInstall = JSON.stringify(oldPkg.dependencies || {}) !== JSON.stringify(newPkg.dependencies || {});
    } catch (_) {}
    copyOver(src, appRoot, ['node_modules', 'data', 'release', '.env', '.git']);
    if (needInstall) { try { spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['install', '--omit=dev', '--no-audit', '--no-fund'], { cwd: appRoot, stdio: 'ignore' }); } catch (_) {} }
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (_) {}
    app.relaunch(); app.exit(0); return { ok: true };
  } catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
});

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); }
else {
  app.on('second-instance', () => { if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); } });
  app.whenReady().then(async () => {
    try { const port = await startServer(); buildMenu(); createWindow(port); }
    catch (err) { dialog.showErrorBox('GN QA Tool - startup error', 'The internal server failed to start:\n\n' + (err && err.stack ? err.stack : String(err))); app.quit(); }
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0 && serverInfo) createWindow(serverInfo.port); });
  });
  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
}
