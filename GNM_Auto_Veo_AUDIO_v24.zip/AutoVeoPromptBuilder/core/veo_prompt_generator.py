"""Bước 4: Sinh prompt Veo cho từng phân cảnh.

- KHÔNG dừng giữa chừng: nếu một lô lỗi, đánh dấu cảnh lỗi và làm tiếp các lô khác.
- Tự gọi lại API nhiều VÒNG cho riêng các cảnh còn lỗi.
- Hỗ trợ chạy SONG SONG nhiều API key (mỗi key 1 luồng), vẫn giữ đúng thứ tự cảnh.
- Có hàm regenerate_indices() để nút "Làm lại cảnh lỗi" gọi.
"""
from __future__ import annotations

import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from queue import Queue
from typing import Callable, Optional

from config import (BATCH_SIZE, MAX_OUTPUT_TOKENS, STYLE_ANCHORS, SYSTEM_PROMPT,
                    TEMPERATURE)
from core.formatter import clean_line
from services.ai_client import AIClient
from utils.json_utils import extract_json_array
from utils.logger import Logger

ProgressCallback = Callable[[int, int], None]
DEFAULT_MAX_ROUNDS = 5


def _is_image(mode: str) -> bool:
    return "video" not in (mode or "").lower()


def _compose(description: str, style_key: str, extra_style: str, aspect: str,
             mode: str = "video") -> str:
    # Style/medium dat LEN DAU de AI "khoa" chat lieu (2D/realistic) truoc khi doc canh.
    anchor = STYLE_ANCHORS.get(style_key, style_key)
    parts: list[str] = []
    if anchor:
        parts.append(anchor.rstrip(". "))
    parts.append(clean_line(description).rstrip(". "))
    if extra_style.strip():
        # Bo bot "aspect ratio ...", "4K/8K" neu nguoi dung tu go de tranh lap
        ex = extra_style.strip()
        ex = re.sub(r"(?i),?\s*aspect ratio\s*\d+:\d+", "", ex)
        ex = re.sub(r"(?i),?\s*\b\d?K\b", "", ex)
        ex = re.sub(r"\s*,\s*,", ",", ex).strip(" ,")
        if ex:
            parts.append(ex)
    if _is_image(mode):
        parts.append("single detailed still image, sharp focus, no motion, no motion blur")
    else:
        parts.append("smooth cinematic camera motion, stable clean animation")
    parts.append(f"aspect ratio {aspect}")
    parts.append("4K")
    return ", ".join(p for p in parts if p)


SAFETY_RULES = (
    "\n\nCONTENT SAFETY RULES (mandatory - the video AI rejects unsafe prompts, follow strictly):\n"
    "1. NEVER mention weapons or any object that can be swung or used to strike near a person "
    "(stick, pole, bamboo pole, cane, rod, knife, whip, club). Replace with a hand gesture or body "
    "posture: a firm dismissive hand wave, pointing toward the door, turning away, stepping back.\n"
    "2. NEVER combine anger/fury with a physical action against someone. Use restrained wording "
    "instead: stern, firm, tense, disapproving, resolute, sorrowful, cold.\n"
    "3. NEVER write 'bared teeth' or a 'vacant / creepy / foolish grin'. Use 'faint smile', "
    "'blank gentle smile', 'distant unfocused gaze', 'dazed absent expression', 'confused far-away look'.\n"
    "4. NO blood, gore, wounds, beating, hitting, slapping or graphic harm. Convey sad or tense "
    "moments only through composition, body language and subtle facial expression.\n"
    "5. AVOID distressing/horror vocabulary. Replace: 'gaunt/emaciated/skeletal/starving' -> 'thin' "
    "or 'weary'; 'hunger / hungry eyes / eyes widen with hunger' -> 'longing gaze' or 'tired eyes'; "
    "'dread / creeping dread / horror / ominous / sinister / menacing / eerie / nightmarish' -> "
    "'somber / tense / solemn / quiet / serious / melancholic'.\n"
    "6. Do NOT specify any overall color palette, color grading, film stock, art medium, or a "
    "dark/cold/horror mood-lighting (e.g. 'cold green light', 'creeping dread', 'shadowy horror'). "
    "The GLOBAL VISUAL STYLE is appended afterward and OWNS the palette and tone, so anything you add "
    "must not contradict it. Keep lighting simple and natural (soft daylight, gentle indoor light) and "
    "express emotion only through posture, gesture, framing and facial expression.\n"
    "8. AVOID finance/gambling/crypto words: 'coins, coin, money, cash, currency, crypto, bitcoin, "
    "gambling, casino, bet, wager, gold ingot, silver ingot'. If wealth or greed matters, imply it "
    "subtly: 'a small cloth pouch', 'a modest bundle', or a longing facial expression - never name money.\n"
    "9. AVOID 'vision, mirage, hallucination, illusion, apparition' and any object that suddenly appears "
    "or floats in mid-air. Keep every scene physically plausible and grounded; for memory/imagination "
    "use 'a daydream' or 'he imagines', shown as an ordinary realistic scene.\n"
    "10. AVOID 'poor, poverty, destitute, miserable, wretched, starving beggar'. Use 'modest, humble, "
    "simple, worn'. A person in hardship = 'a tired person in worn simple clothes'.\n"
    "11. Write ALL text in plain ASCII English only. Transliterate Vietnamese names to non-accented "
    "form (e.g. 'Tu Moc', 'Nam Thin'); never output accented characters.\n"
    "12. NEVER show physical restraint of a person: gripping or grabbing someone's arms, marching or "
    "dragging them, holding/grabbing/tearing their collar or clothes. Instead: two people walk on either "
    "side escorting him, or a firm gesture for him to come along.\n"
    "13. NEVER undress a character or show a bared/exposed body, nudity, or a person in only shorts or "
    "underwear. Characters stay fully clothed; messy clothes = 'rumpled, disheveled, dirtied garments'.\n"
    "14. NEVER show alcohol, wine, liquor, drunkenness or intoxication. Use tea and a tired or relaxed look.\n"
    "15. NEVER show extreme panic or self-clutching (hands over the mouth, clutching the head), or "
    "screaming terror. Use a bowed head, a hand resting on the chest, a sorrowful or worried expression.\n"
    "16. NEVER show a person eating garbage/refuse, drowning, suffocating, being half-buried or pressed "
    "down, or being abandoned in danger. Keep every action ordinary and clearly survivable.\n"
    "17. NEVER show a crowd surrounding someone with contempt or disgust to humiliate them. Use onlookers "
    "standing back at a distance with serious, disapproving expressions.\n"
    "18. Keep every scene safe-for-work, non-violent and free of horror while preserving the story's emotion."
)


CONSISTENCY_RULE = (
    "\n\nCHARACTER CONSISTENCY LOCK (mandatory): For EVERY character that appears, restate their FIXED "
    "appearance INLINE inside that same prompt - age, gender, hairstyle and hair color, clothing color and "
    "style, and any distinguishing feature - using the EXACT same wording every single time, taken from the "
    "character list below. Repeat this short fixed description in EVERY prompt where the character appears so "
    "that all images/scenes render the identical, consistent character. Never change, re-word, shorten "
    "differently, or omit these fixed traits. This is critical for still images where each picture is "
    "generated independently."
)


def _build_system(analysis_brief: str, language: str, duration_sec: int,
                  mode: str = "video") -> str:
    if _is_image(mode):
        intro = (
            "You are an expert at turning a long story into a sequence of STILL IMAGE prompts for AI "
            "image generators. For each story beat, in order, write ONE vivid still-image description of "
            "a single frozen moment. Include subject/character, setting, pose, composition, lighting and "
            "mood. Do NOT describe camera movement, motion, video, animation, audio, voiceover, dialogue "
            "or timecode. Keep character and setting consistency."
            + f"\nWrite each description in {language}."
        )
    else:
        intro = (
            SYSTEM_PROMPT
            + f"\nWrite each scene description in {language}."
            + f" Each scene corresponds to a {duration_sec}-second clip with exactly ONE main action."
            + " Do NOT include the words SCENE, voiceover, dialogue, or any timecode."
        )
    return intro + SAFETY_RULES + CONSISTENCY_RULE + (f"\n\n{analysis_brief}" if analysis_brief.strip() else "")


def _build_user(batch: list[str], mode: str = "video") -> str:
    numbered = "\n".join(f"{i + 1}. {seg}" for i, seg in enumerate(batch))
    if _is_image(mode):
        task = (
            "For EACH numbered segment, write ONE vivid STILL IMAGE description capturing its single key "
            "moment as a frozen picture. Include subject/character, specific pose, location, composition "
            "and mood. Do NOT describe camera movement, motion or video. Keep characters consistent. "
            "Keep lighting natural and neutral; do NOT add a color palette or art style (the global style "
            "added later owns palette and tone). No dialogue, no voiceover, no timecode. "
            "Follow all CONTENT SAFETY RULES."
        )
    else:
        task = (
            "For EACH numbered segment, write ONE cinematic Veo video-scene description capturing its "
            "single key moment. Include subject/character, specific action, location, camera movement and "
            "composition. Keep characters consistent. Keep lighting natural and neutral; do NOT add a "
            "color palette, color grading, art style, or any dark/cold/horror mood (the global style "
            "added later owns palette and tone). Do NOT add style or aspect ratio. No dialogue, no "
            "voiceover, no timecode. Always name each character that appears using their exact name. Follow all CONTENT SAFETY RULES."
        )
    return (
        "Below are consecutive story segments in order. " + task + "\n\n"
        f"Return ONLY a JSON array of exactly {len(batch)} strings, in the same order.\n\n"
        f"SEGMENTS:\n{numbered}"
    )


def _parse_batch(raw: str, expected: int, fallback_segments: list[str], log: Logger) -> list[str]:
    try:
        arr = extract_json_array(raw)
        items = [str(x).strip() for x in arr]
    except ValueError as exc:
        log.warn(f"Lô trả về sai JSON ({exc}). Tách theo dòng dự phòng.")
        items = [ln.strip(" -*0123456789.\t") for ln in raw.splitlines() if ln.strip()]
    if len(items) < expected:
        log.warn(f"AI trả {len(items)}/{expected} mô tả. Bù phần thiếu bằng nội dung gốc.")
        for k in range(len(items), expected):
            items.append(fallback_segments[k])
    elif len(items) > expected:
        items = items[:expected]
    return items


def _core(clients: list[AIClient], jobs: list[tuple[int, str]], system: str,
          compose, build_user, prompts: list[str], log: Logger,
          progress_cb: Optional[ProgressCallback], total: int) -> list[int]:
    """Xử lý 1 lượt cho các (index, segment) trong `jobs`.

    Ghi kết quả vào prompts[index]. KHÔNG raise khi lỗi — trả về danh sách index lỗi.
    """
    batches = [jobs[i:i + BATCH_SIZE] for i in range(0, len(jobs), BATCH_SIZE)]
    failed: list[int] = []
    lock = threading.Lock()

    def report() -> None:
        if progress_cb:
            done = sum(1 for p in prompts if p.strip())
            progress_cb(done, total)

    def do(client: AIClient, bjobs: list[tuple[int, str]]) -> None:
        idxs = [i for i, _ in bjobs]
        segs = [s for _, s in bjobs]
        rng = f"{idxs[0] + 1}-{idxs[-1] + 1}"
        try:
            raw = client.generate(system, build_user(segs),
                                  max_tokens=MAX_OUTPUT_TOKENS, temperature=TEMPERATURE)
            descs = _parse_batch(raw, len(segs), segs, log)
            with lock:
                for k, i in enumerate(idxs):
                    prompts[i] = compose(descs[k])
            log.info(f"Xong cảnh {rng}.")
        except Exception as exc:  # bat MOI loi -> khong dung pipeline
            with lock:
                failed.extend(idxs)
            log.warn(f"Cảnh {rng} lỗi (sẽ thử lại sau): {exc}")
        finally:
            report()

    if len(clients) <= 1:
        for b in batches:
            do(clients[0], b)
    else:
        pool: "Queue[AIClient]" = Queue()
        for c in clients:
            pool.put(c)

        def task(b: list[tuple[int, str]]) -> None:
            c = pool.get()
            try:
                do(c, b)
            finally:
                pool.put(c)

        with ThreadPoolExecutor(max_workers=len(clients)) as ex:
            futs = [ex.submit(task, b) for b in batches]
            for f in as_completed(futs):
                f.result()
    return sorted(failed)


def _run_rounds(clients, segments, indices, prompts, system, compose, build_user, log,
                progress_cb, total, max_rounds, label) -> list[int]:
    pending = [i for i in indices if 0 <= i < total]
    rnd = 0
    while pending and rnd < max_rounds:
        rnd += 1
        if rnd > 1 or label:
            log.info(f"== {label} vòng {rnd}: xử lý {len(pending)} cảnh ==")
        jobs = [(i, segments[i]) for i in pending]
        before = len(pending)
        pending = _core(clients, jobs, system, compose, build_user, prompts, log, progress_cb, total)
        if pending and len(pending) == before and rnd < max_rounds:
            log.warn(f"Vòng {rnd} chưa cải thiện, nghỉ 2s rồi thử lại…")
            time.sleep(2)
    return pending


def generate_prompts(clients, segments, analysis_brief, *, visual_style, extra_style,
                     aspect, language, duration_sec, mode: str = "video",
                     max_rounds: int = DEFAULT_MAX_ROUNDS,
                     logger: Optional[Logger] = None,
                     progress_cb: Optional[ProgressCallback] = None) -> tuple[list[str], list[int]]:
    """Sinh prompt cho toàn bộ cảnh. Trả về (prompts, failed_indices)."""
    log = logger or Logger()
    total = len(segments)
    prompts: list[str] = [""] * total
    if total == 0:
        return prompts, []
    if not clients:
        raise ValueError("Khong co AI client nao.")
    if len(clients) > 1:
        log.info(f"Chạy SONG SONG với {len(clients)} API key.")
    system = _build_system(analysis_brief, language, duration_sec, mode)
    compose = lambda d: _compose(d, visual_style, extra_style, aspect, mode)
    build_user = lambda segs: _build_user(segs, mode)
    pending = _run_rounds(clients, segments, list(range(total)), prompts, system,
                          compose, build_user, log, progress_cb, total, max_rounds, label="Sinh prompt")
    if pending:
        log.warn(f"Còn {len(pending)} cảnh chưa tạo được sau {max_rounds} vòng. "
                 f"Bấm nút 'Làm lại cảnh lỗi' để thử thêm.")
    return prompts, pending


def regenerate_indices(clients, segments, indices, prompts, analysis_brief, *, visual_style,
                       extra_style, aspect, language, duration_sec, mode: str = "video",
                       max_rounds: int = DEFAULT_MAX_ROUNDS,
                       logger: Optional[Logger] = None,
                       progress_cb: Optional[ProgressCallback] = None) -> tuple[list[str], list[int]]:
    """Làm lại CHỈ các cảnh trong `indices` (ghi đè vào `prompts`). Trả về (prompts, still_failed)."""
    log = logger or Logger()
    total = len(segments)
    if not clients:
        raise ValueError("Khong co AI client nao.")
    system = _build_system(analysis_brief, language, duration_sec, mode)
    compose = lambda d: _compose(d, visual_style, extra_style, aspect, mode)
    build_user = lambda segs: _build_user(segs, mode)
    pending = _run_rounds(clients, segments, list(indices), prompts, system,
                          compose, build_user, log, progress_cb, total, max_rounds, label="Làm lại")
    if pending:
        log.warn(f"Vẫn còn {len(pending)} cảnh lỗi.")
    return prompts, pending


def _ref_system(language: str, mode: str) -> str:
    medium = "still reference image" if _is_image(mode) else "clean reference shot"
    return (
        "You are an expert at writing " + medium + " prompts for AI generators. For each item write ONE "
        "clean reference prompt showing the subject clearly and fully, centered, in a neutral simple "
        "background, so it can be reused as a consistent reference image. "
        + f"Write in {language}. No dialogue, no timecode."
        + SAFETY_RULES
    )


def generate_references(clients, analysis, *, visual_style, extra_style, aspect, language,
                        mode="video", logger=None) -> dict:
    """Tao prompt tham chieu cho tung nhan vat + tung boi canh. Tra ve dict."""
    log = logger or Logger()
    if not clients:
        raise ValueError("Khong co AI client nao.")
    client = clients[0]
    chars = [c for c in (analysis.get("characters") or [])
             if isinstance(c, dict) and str(c.get("name", "")).strip()]
    settings = [str(s).strip() for s in (analysis.get("settings") or []) if str(s).strip()]
    out = {"characters": [], "settings": []}
    system = _ref_system(language, mode)
    compose = lambda d: _compose(d, visual_style, extra_style, aspect, mode)

    if chars:
        lines = "\n".join(
            f"{i + 1}. {c.get('name')}: " + ", ".join(
                str(c.get(k, "")) for k in ("age", "gender", "appearance", "clothing")
                if str(c.get(k, "")).strip())
            for i, c in enumerate(chars))
        user = ("Write ONE character reference-sheet prompt per character below: full body, neutral "
                "standing pose, plain background, clearly showing their fixed appearance (age, hair, "
                f"clothing). Return ONLY a JSON array of exactly {len(chars)} strings.\n\nCHARACTERS:\n" + lines)
        try:
            raw = client.generate(system, user, max_tokens=MAX_OUTPUT_TOKENS, temperature=TEMPERATURE)
            arr = _parse_batch(raw, len(chars), [str(c.get("name")) for c in chars], log)
            for c, desc in zip(chars, arr):
                out["characters"].append((str(c.get("name")), compose(desc)))
            log.info(f"Da tao {len(chars)} prompt nhan vat.")
        except Exception as exc:
            log.warn(f"Tao prompt nhan vat loi: {exc}")

    if settings:
        lines = "\n".join(f"{i + 1}. {s}" for i, s in enumerate(settings))
        user = ("Write ONE setting reference prompt per location below: a wide establishing view of the "
                f"place with NO people. Return ONLY a JSON array of exactly {len(settings)} strings.\n\n"
                "SETTINGS:\n" + lines)
        try:
            raw = client.generate(system, user, max_tokens=MAX_OUTPUT_TOKENS, temperature=TEMPERATURE)
            arr = _parse_batch(raw, len(settings), settings, log)
            for st, desc in zip(settings, arr):
                out["settings"].append((st, compose(desc)))
            log.info(f"Da tao {len(settings)} prompt boi canh.")
        except Exception as exc:
            log.warn(f"Tao prompt boi canh loi: {exc}")
    return out
