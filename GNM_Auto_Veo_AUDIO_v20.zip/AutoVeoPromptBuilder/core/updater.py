"""Kiểm tra & tải bản cập nhật từ một manifest JSON đặt online.

Manifest (ví dụ version.json) có dạng:
{
  "version": "1.11.0",
  "url": "https://.../GNM_Auto_Veo_AUDIO_v13.zip",
  "notes": "Mo ta thay doi"
}
"""
from __future__ import annotations

import os
import re
import zipfile
from typing import Optional

import requests

import config


def _ver_tuple(v: str) -> tuple[int, ...]:
    nums = re.findall(r"\d+", v or "")
    return tuple(int(n) for n in nums[:4]) if nums else (0,)


def is_newer(remote: str, local: str) -> bool:
    return _ver_tuple(remote) > _ver_tuple(local)


def check_for_update(manifest_url: str, timeout: int = 20) -> Optional[dict]:
    """Trả về {version,url,notes} nếu có bản mới hơn config.VERSION, ngược lại None.

    Ném ValueError/requests error nếu URL trống hoặc mạng lỗi.
    """
    if not manifest_url or not manifest_url.strip():
        raise ValueError("Chưa cấu hình URL cập nhật.")
    resp = requests.get(manifest_url.strip(), timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    remote = str(data.get("version", "")).strip()
    if not remote:
        raise ValueError("Manifest thiếu trường 'version'.")
    if is_newer(remote, config.VERSION):
        return {
            "version": remote,
            "url": str(data.get("url", "")).strip(),
            "notes": str(data.get("notes", "")).strip(),
        }
    return None


def download_update(url: str, dest_dir: str, timeout: int = 180) -> str:
    """Tải file cập nhật về dest_dir, trả về đường dẫn file."""
    if not url or not url.strip():
        raise ValueError("Manifest không có link tải (url).")
    os.makedirs(dest_dir, exist_ok=True)
    name = url.split("?")[0].rstrip("/").split("/")[-1] or "GNM_Auto_Veo_AUDIO_update.zip"
    dest = os.path.join(dest_dir, name)
    with requests.get(url.strip(), stream=True, timeout=timeout) as resp:
        resp.raise_for_status()
        with open(dest, "wb") as fh:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    fh.write(chunk)
    return dest


def default_download_dir() -> str:
    """Thư mục tải về ưu tiên: Downloads -> Desktop -> home."""
    home = os.path.expanduser("~")
    for sub in ("Downloads", "Desktop"):
        d = os.path.join(home, sub)
        if os.path.isdir(d):
            return d
    return home


def apply_update(zip_path: str, install_dir: str) -> bool:
    """Giải nén bản mới và ghi đè lên thư mục cài đặt (chạy được khi đang là mã nguồn).

    Trả về True nếu thành công. File tải bằng Python nên KHÔNG dính Mark-of-the-Web,
    do đó không bị Windows chặn.
    """
    import shutil
    import tempfile

    tmp = tempfile.mkdtemp(prefix="gnm_upd_")
    try:
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(tmp)
        # tìm thư mục chứa app.py + core
        src = None
        for root, dirs, files in os.walk(tmp):
            if "app.py" in files and "core" in dirs:
                src = root
                break
        if not src:
            raise ValueError("Không tìm thấy mã nguồn trong bản cập nhật.")
        # copy đè lên install_dir (bỏ qua __pycache__)
        for item in os.listdir(src):
            if item == "__pycache__":
                continue
            s = os.path.join(src, item)
            d = os.path.join(install_dir, item)
            if os.path.isdir(s):
                shutil.copytree(s, d, dirs_exist_ok=True,
                                ignore=shutil.ignore_patterns("__pycache__"))
            else:
                shutil.copy2(s, d)
        # xoá __pycache__ cũ để biên dịch lại code mới
        for root, dirs, _ in os.walk(install_dir):
            for dn in list(dirs):
                if dn == "__pycache__":
                    shutil.rmtree(os.path.join(root, dn), ignore_errors=True)
        return True
    finally:
        import shutil as _sh
        _sh.rmtree(tmp, ignore_errors=True)


def relaunch(install_dir: str) -> None:
    """Khởi động lại app sau khi cập nhật."""
    import subprocess
    import sys

    vbs = os.path.join(install_dir, "GNM Auto Veo AUDIO.vbs")
    try:
        if os.path.exists(vbs):
            subprocess.Popen(["wscript", vbs], cwd=install_dir, close_fds=True)
            return
    except Exception:
        pass
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    exe = pyw if os.path.exists(pyw) else sys.executable
    subprocess.Popen([exe, os.path.join(install_dir, "app.py")], cwd=install_dir, close_fds=True)


def read_zip_version(zip_path: str) -> str:
    """Đọc VERSION trong config.py của file zip cập nhật."""
    try:
        with zipfile.ZipFile(zip_path) as zf:
            for name in zf.namelist():
                if name.replace("\\", "/").endswith("AutoVeoPromptBuilder/config.py"):
                    txt = zf.read(name).decode("utf-8", "ignore")
                    m = re.search(r'VERSION[^=]*=\s*"([^"]+)"', txt)
                    if m:
                        return m.group(1)
    except Exception:
        pass
    return ""


def find_local_update(download_dir: str) -> Optional[dict]:
    """Tìm file GNM_Auto_Veo_AUDIO*.zip mới nhất trong Downloads.

    Trả về {path, version} hoặc None.
    """
    import glob
    if not download_dir or not os.path.isdir(download_dir):
        return None
    zips = glob.glob(os.path.join(download_dir, "GNM_Auto_Veo_AUDIO*.zip"))
    if not zips:
        return None
    zips.sort(key=lambda p: os.path.getmtime(p), reverse=True)  # mới tải nhất trước
    path = zips[0]
    return {"path": path, "version": read_zip_version(path)}
