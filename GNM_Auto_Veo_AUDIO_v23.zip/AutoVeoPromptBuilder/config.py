"""Cấu hình tập trung cho Auto Veo Prompt Builder."""
from __future__ import annotations

APP_NAME: str = "GNM Auto Veo AUDIO"
VERSION: str = "1.20.0"

# URL tới file version.json để kiểm tra cập nhật (admin điền; có thể đổi trên GUI).
UPDATE_MANIFEST_URL: str = "https://raw.githubusercontent.com/phamloc68/gn-tool-update/main/version.json"

# ----- AI providers & models -----
# "OpenAI-compatible" dùng cho các cổng trung gian (9Router, proxy nội bộ...) nói
# chuẩn OpenAI /v1/chat/completions, ví dụ https://llm.chiasegpu.vn/v1.
MODES: list[str] = ["Video (Veo)", "Anh (Image)"]

PROVIDERS: list[str] = ["Gemini", "Claude", "OpenAI-compatible"]

MODELS: dict[str, list[str]] = {
    # Dropdown có thể nhập tay nếu muốn dùng model mới hơn.
    "Gemini": ["gemini-2.5-pro", "gemini-2.5-flash"],
    "Claude": ["claude-sonnet-4-5", "claude-sonnet-4-6", "claude-opus-4-6",
               "claude-haiku-4-5-20251001"],
    "OpenAI-compatible": ["ant/claude-opus-4-6", "ant/claude-sonnet-4-6",
                          "openai/gpt-4o", "openai/gpt-4o-mini",
                          "deepseek/deepseek-chat", "gemini/gemini-2.5-pro"],
}

# Base URL mặc định cho provider OpenAI-compatible (sửa được trên giao diện).
DEFAULT_BASE_URL: str = "https://llm.chiasegpu.vn/v1"

# ----- Tùy chọn nội dung -----
DURATIONS: list[str] = ["6 seconds", "7 seconds", "8 seconds"]
ASPECT_RATIOS: list[str] = ["16:9", "9:16", "1:1"]
LANGUAGES: list[str] = ["English", "Vietnamese"]
MAX_SCENES_OPTIONS: list[str] = ["Auto", "80", "100", "120", "150"]

VISUAL_STYLES: list[str] = ['VIP 2D VN', 'VN LANG QUE', '2D CHINESE', 'STORYBOOK HISTORY', 'CINEMATIC HISTORY', 'CINEMATIC WESTERN', 'MODERN CEO DRAMA']

# Anchor mô tả kèm theo visual style (gắn vào cuối mỗi prompt).
STYLE_ANCHORS: dict[str, str] = {
    'VIP 2D VN': 'Flat 2D Vietnamese folktale cartoon illustration, hand-drawn animation style, clean bold black ink line-art, smooth flat cel-shaded coloring with solid colors, bright warm harmonious palette of soft golden yellow, light coral, warm beige and gentle sky blue, gentle expressive faces, traditional Vietnamese clothing, soft natural daytime light, wholesome uplifting storytelling tone, fully 2D illustration, NOT photorealistic, no 3D, no realism, no paper texture, no grain, no cross-hatching, no border or frame, artwork fills the entire frame edge to edge, smooth clean stable motion',
    'VN LANG QUE': '2D Vietnamese rural folktale storybook illustration, hand-drawn animation style, gentle clean ink line-art with soft flat shading, warm sepia golden-brown palette, stylized simple characters with calm faces, traditional Vietnamese village setting, soft natural daylight, symbolic reflective wholesome mood, layered depth foreground midground background, fully 2D illustration, NOT photorealistic, no 3D, no realism, no paper texture, no grain, no watercolor bleeding, no border or frame, artwork fills the entire frame edge to edge, smooth clean stable motion, no modern elements',
    '2D CHINESE': '2D digital illustration in the style of traditional Chinese Manhua comics. Chinese Hanfu costumes. Artistic details utilize thick outlines and dark black or brown tones. Classic color palette, primarily earthy and neutral colors such as light brown, light blue, dark terracotta, and neutral red. minimal expression High saturation, flat shadows. Fully 2D illustration, not photorealistic, no 3D. No border or frame, artwork fills the entire frame edge to edge, smooth clean stable motion. 4K resolution, artistic composition.',
    'STORYBOOK HISTORY': '2D digital illustration in the style of warm storybook history comics. Period-accurate Western historical costumes. Artistic details utilize bold outlines and dark brown or black tones. Classic color palette, primarily earthy and neutral colors such as terracotta, cream, dusty blue, mustard, and muted red. Minimal expression, high saturation, flat shadows. Fully 2D illustration, not photorealistic, no 3D. No border or frame, artwork fills the entire frame edge to edge, smooth clean stable motion. 4K resolution, artistic composition.',
    'CINEMATIC HISTORY': 'Cinematic semi-realistic digital painting in the style of atmospheric historical concept art. Period-accurate Western historical costumes, architecture, and interiors. Artistic details utilize rich painterly brushwork, dramatic chiaroscuro lighting, and warm firelight or candlelight glow against deep shadows. Moody color palette of deep navy, warm amber, candle gold, muted crimson, and cold blue. Detailed realistic textures, soft atmospheric haze, volumetric light. No border or frame, fills the entire frame edge to edge, smooth stable motion. 4K resolution, cinematic composition.',
    'CINEMATIC WESTERN': 'Cinematic photorealistic film still, 1880s American Old West frontier, hyper-realistic detail, shot on 35mm cinema camera with prime lens, shallow depth of field with soft natural bokeh, warm golden-hour sunlight, volumetric dusty light rays, filmic color grade with warm amber highlights and cool teal-brown shadows, fine film grain, rich texture on weathered wood leather and cotton fabric, ultra-detailed realistic skin and eyes, emotional romantic storytelling mood, professional cinematic color grading, photorealistic NOT cartoon NOT illustration NOT 3D-render, no border or frame, artwork fills the entire frame edge to edge, smooth stable natural motion, 4K',
    'MODERN CEO DRAMA': 'Ultra-realistic photograph, modern-day American corporate drama, hyper-realistic detail, shot on full-frame DSLR with 50mm lens, sharp crisp focus throughout, bright clean high-key lighting, soft diffused daylight, glossy polished commercial-photography look, vivid saturated color grade, lifelike realistic skin and eyes, cinematic emotional staging, luxurious contemporary setting, professional color grading, photorealistic NOT cartoon NOT illustration NOT 3D-render, no red arrow no thumbnail overlay no text, no border or frame, artwork fills the entire frame edge to edge, smooth stable natural motion, 8K',
}

# ----- Tham số tách cảnh -----
# Số "âm tiết / từ" đọc được trong 1 giây (giọng kể chuyện chậm).
TOKENS_PER_SECOND: float = 3.5

# ----- Tham số AI -----
BATCH_SIZE: int = 10          # số cảnh gửi AI mỗi lần gọi
REQUEST_TIMEOUT: int = 300    # giây (cổng proxy có thể chậm)
MAX_RETRIES: int = 2
RETRY_BACKOFF: float = 2.0    # giây, nhân đôi mỗi lần
MAX_OUTPUT_TOKENS: int = 8192
TEMPERATURE: float = 0.7
ANALYZE_MAX_CHARS: int = 8000   # giới hạn ký tự gửi đi khi phân tích story
ANALYZE_MAX_TOKENS: int = 2048   # output phân tích nhỏ -> phản hồi nhanh hơn

# ----- System prompt nội bộ -----
SYSTEM_PROMPT: str = (
    "You are an expert at converting long stories into short cinematic video prompts "
    "for Google Veo 3 / Veo 3.1. Your job: analyze the story, divide it into ordered "
    "6-8 second scenes, and write a vivid cinematic visual prompt for each scene, in the "
    "exact order of the story. Keep character and setting consistency (age, gender, "
    "clothing, appearance, emotion). Never write dialogue, never write voiceover or "
    "narration, never write timecodes, never explain. Each prompt must be concrete and "
    "picturable with a clear subject, a specific action, location, camera movement, "
    "lighting, mood, composition and visual style. Do not be generic."
)
